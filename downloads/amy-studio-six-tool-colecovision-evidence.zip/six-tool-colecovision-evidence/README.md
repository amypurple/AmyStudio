# ColecoVision six-tool evidence

Three equivalent samples built with Amy Studio, CVBasic, z88dk, ugBASIC, devkitSMS/SGlib_CV, and PVColLib. Each tool folder contains its source, required local assets, and a loadable ColecoVision ROM truncated to the measured occupied bytes.

- `hello-world`: visible text startup
- `bitmap-picture`: complete 256x192 Warrior Graphics II image
- `controller-visual`: visible controller-state monitor
- `graphics-fidelity-corpus`: Cake, Commando, Warrior, and Barbarian sources, compact ROMs, measurements, and framebuffer results for Amy, CVBasic, and ugBASIC

All eighteen compact six-tool ROMs completed 180 NTSC frames in GearColeco while packaging. The six Warrior ROMs were separately verified to differ by 0 of 49,152 framebuffer pixels. devkitSMS uses official aPack payloads and its native direct-to-VRAM decoder with frame IRQ disabled; PVColLib uses native RLE direct to VRAM. `manifest.csv` records six-tool sizes and hashes; `SHA256SUMS.txt` allows ROM verification. Cartridge padding is intentionally excluded.
