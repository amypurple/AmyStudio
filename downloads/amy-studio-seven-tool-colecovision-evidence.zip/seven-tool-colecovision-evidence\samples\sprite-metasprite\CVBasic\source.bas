MODE 2
SPRITE FLICKER OFF
DEFINE SPRITE 0,6,sprite_patterns
x = 120
y = 88
tick = 0
anim = 0

main_loop:
    WAIT
    IF CONT1.LEFT AND x > 1 THEN x = x - 1
    IF CONT1.RIGHT AND x < 239 THEN x = x + 1
    IF CONT1.UP AND y > 1 THEN y = y - 1
    IF CONT1.DOWN AND y < 175 THEN y = y + 1
    tick = tick + 1
    IF tick = 8 THEN
        tick = 0
        IF anim = 0 THEN anim = 12 ELSE anim = 0
    END IF
    SPRITE 0,y,x,anim,15
    SPRITE 1,y,x,anim+4,11
    SPRITE 2,y,x,anim+8,1
    SPRITE 3,$d0,0,0,0
    GOTO main_loop

sprite_patterns:
    DATA BYTE $00,$00,$00,$0c,$1c,$18,$0c,$00,$00,$00,$00,$00,$00,$00,$00,$00
    DATA BYTE $00,$00,$00,$30,$70,$60,$30,$00,$00,$00,$00,$00,$00,$00,$00,$00
    DATA BYTE $00,$03,$0f,$13,$23,$23,$73,$7f,$7f,$3c,$3f,$1f,$0e,$0e,$00,$00
    DATA BYTE $00,$c0,$f0,$c8,$8c,$8c,$ce,$fe,$fe,$3c,$fc,$f8,$70,$70,$00,$00
    DATA BYTE $01,$06,$18,$30,$60,$44,$c0,$c0,$c0,$63,$60,$30,$18,$18,$00,$00
    DATA BYTE $80,$60,$18,$0c,$06,$12,$03,$03,$03,$c6,$06,$0c,$18,$18,$00,$00
    DATA BYTE $00,$00,$00,$0c,$1c,$0c,$0c,$00,$00,$00,$00,$00,$00,$00,$00,$00
    DATA BYTE $00,$00,$00,$30,$70,$30,$30,$00,$00,$00,$00,$00,$00,$00,$00,$00
    DATA BYTE $00,$03,$0f,$13,$23,$23,$73,$7f,$7f,$38,$3f,$1f,$06,$1e,$00,$00
    DATA BYTE $00,$c0,$f0,$c8,$8c,$8c,$ce,$fe,$fe,$1c,$fc,$f8,$60,$78,$00,$00
    DATA BYTE $01,$06,$18,$30,$60,$50,$c0,$c0,$c0,$67,$60,$30,$0c,$30,$00,$00
    DATA BYTE $80,$60,$18,$0c,$06,$42,$03,$03,$03,$e6,$06,$0c,$30,$0c,$00,$00
