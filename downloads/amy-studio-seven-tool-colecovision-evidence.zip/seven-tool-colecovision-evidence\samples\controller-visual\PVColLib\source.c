#include <coleco.h>

void nmi(void) {
}

void main(void) {
    unsigned char color;

    vdp_setmode2txt();
    vdp_setdefaultchar(FNTNORMAL);
    vdp_duplicatevram();
    vdp_fillvram(coltab, 0xF0, 128 * 8);
    vdp_putstring(7, 10, "CONTROLLER VISUAL");
    vdp_enablescr();

    for (;;) {
        vdp_waitvblank(1);
        color = COLDRKBLUE;
        if (keypad_1 <= PAD_KEYSHARP) color = COLMAGENTA;
        else if (joypad_1 & PAD_FIRES) color = COLLITRED;
        else if (joypad_1 & PAD_UP) color = COLLITGREEN;
        else if (joypad_1 & PAD_DOWN) color = COLDRKGREEN;
        else if (joypad_1 & PAD_LEFT) color = COLLITYELLOW;
        else if (joypad_1 & PAD_RIGHT) color = COLCYAN;
        vdp_setreg(7, color);
    }
}
