# ColecoVision seven-tool evidence

Five equivalent samples built with Amy Studio, CVBasic, z88dk, ugBASIC, devkitSMS/SGlib_CV, PVColLib, and Amy's legacy SDCC devkit. Each tool folder contains its source, required local assets, and the complete loadable ColecoVision ROM produced by its toolchain.

- `hello-world`: visible text startup
- `bitmap-picture`: complete 256x192 Warrior Graphics II image
- `controller-visual`: visible controller-state monitor
- `sprite-metasprite`: animated, controller-driven three-color metasprite
- `state-update`: deterministic six-actor gameplay update with state dispatch, timers, collision, score, and checksum
- `graphics-fidelity-corpus`: Cake, Commando, Warrior, and Barbarian sources, compact ROMs, measurements, and framebuffer results for Amy, CVBasic, and ugBASIC
- `graphics-compression-corpus`: exact ratios for the Graphics II corpus, plus Amy decoder and representative first-use sizes

All thirty-five complete seven-tool ROMs completed 180 NTSC frames in GearColeco while packaging. The state-update programs were separately verified against the common oracle: world state 1, 13 collisions, score 425, checksum 1478. The seven Warrior outputs differ by 0 of 49,152 framebuffer pixels, and the metasprite ROMs pass the common VRAM/SAT oracle. PVColLib and NewColeco use white-on-transparent `$F0` text in the controller fixture so the changing VDP R7 backdrop remains visible; controller logic and occupied size are unchanged. `manifest.csv` distinguishes occupied bytes from complete ROM file bytes and records hashes; `SHA256SUMS.txt` allows ROM verification. Comparison figures exclude cartridge padding.
