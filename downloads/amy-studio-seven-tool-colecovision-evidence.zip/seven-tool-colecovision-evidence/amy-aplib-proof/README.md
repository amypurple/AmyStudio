# Amy aPLib proof

This reproducible test compresses deterministic public pattern and color data with Amy's browser aPLib encoder, compiles an Amy ROM, runs it in GearColeco, and compares all 6,144 decompressed VRAM bytes exactly.

Run `node tools/test-aplib-vram-rom.mjs` from an Amy Studio checkout. If the private Warrior fixture is present, it is tested instead; otherwise the deterministic fixture is used.

Included here:

- `aplib.js`: browser encoder and decoder
- `aplib_vram.asm`: 348-byte direct-to-TMS9918 VRAM decoder
- `test-aplib-vram-rom.mjs`: compile and runtime verification

The official aPPack executable and commercial graphics are intentionally not redistributed. Amy's encoder is separately checked for bidirectional stream compatibility against a locally licensed official copy during development.
