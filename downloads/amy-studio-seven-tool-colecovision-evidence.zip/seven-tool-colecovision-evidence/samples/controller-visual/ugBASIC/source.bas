CLS
LOCATE 8,8 : PRINT "CONTROLLER TEST";
LOCATE 5,11 : PRINT "MOVE OR PRESS A BUTTON";
LOCATE 7,14 : PRINT "KEYPAD IS PURPLE";
DO
    WAIT VBL
    p = JOY(0)
    k = SCANCODE
    IF k <> 0 THEN
        borderColor = 13
    ELSEIF p AND 16 THEN
        borderColor = 9
    ELSEIF p AND 8 THEN
        borderColor = 3
    ELSEIF p AND 4 THEN
        borderColor = 12
    ELSEIF p AND 2 THEN
        borderColor = 11
    ELSEIF p AND 1 THEN
        borderColor = 7
    ELSE
        borderColor = 4
    ENDIF
    COLOR BORDER borderColor
LOOP
