#include <games.h>
#include <intrinsic.h>
#include <stdio.h>
#include <video/tms99x8.h>

int main(void)
{
    printf("\x0c\n\n\n\n\n\n\n\n  CONTROLLER TEST\n\n  MOVE OR PRESS A BUTTON\n\n  KEYPAD IS PURPLE");
    for (;;) {
        unsigned int input;
        unsigned char pad;
        unsigned char color = 4;
        intrinsic_halt();
        input = joystick(3);
        pad = (unsigned char)input;
        if ((unsigned char)(input >> 8)) color = 13;
        else if (pad & (MOVE_FIRE1 | MOVE_FIRE2)) color = 9;
        else if (pad & MOVE_UP) color = 3;
        else if (pad & MOVE_DOWN) color = 12;
        else if (pad & MOVE_LEFT) color = 11;
        else if (pad & MOVE_RIGHT) color = 7;
        vdp_set_reg(7, color);
    }
}
