#include <coleco.h>
#include <getput1.h>

static const byte silent_sound[] = { 0xff };
const sound_t snd_table[] = {
    { silent_sound, SOUNDAREA1 }
};

void nmi(void)
{
}

void main(void)
{
    byte color;

    screen_mode_2_text();
    upload_default_ascii(NORMAL);
    fill_color(0, 0xf1, 255);
    center_string(10, "CONTROLLER VISUAL");
    enable_nmi();
    screen_on();

    while (1) {
        delay(1);
        color = 4;
        if (keypad_1 != 0xff) color = 13;
        else if (joypad_1 & (FIRE1 | FIRE2)) color = 9;
        else if (joypad_1 & UP) color = 3;
        else if (joypad_1 & DOWN) color = 12;
        else if (joypad_1 & LEFT) color = 11;
        else if (joypad_1 & RIGHT) color = 7;
        vdp_out(7, color);
    }
}
