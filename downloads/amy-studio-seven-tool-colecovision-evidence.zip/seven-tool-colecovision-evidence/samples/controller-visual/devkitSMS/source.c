#include "SGlib.h"

void main(void)
{
    SG_setBackdropColor(SG_COLOR_DARK_BLUE);
    SG_displayOn();
    for (;;) {
        unsigned int pad;
        unsigned char key;
        unsigned char color = SG_COLOR_DARK_BLUE;
        SG_waitForVBlank();
        pad = SG_getKeysStatus();
        key = SG_readCVNumPad(PORT_A_CV_NUMPAD);
        if (key != CV_NUMPAD_NONE) color = SG_COLOR_MAGENTA;
        else if (pad & (PORT_A_KEY_1 | PORT_A_KEY_2)) color = SG_COLOR_LIGHT_RED;
        else if (pad & PORT_A_KEY_UP) color = SG_COLOR_LIGHT_GREEN;
        else if (pad & PORT_A_KEY_DOWN) color = SG_COLOR_DARK_GREEN;
        else if (pad & PORT_A_KEY_LEFT) color = SG_COLOR_LIGHT_YELLOW;
        else if (pad & PORT_A_KEY_RIGHT) color = SG_COLOR_CYAN;
        SG_setBackdropColor(color);
    }
}
