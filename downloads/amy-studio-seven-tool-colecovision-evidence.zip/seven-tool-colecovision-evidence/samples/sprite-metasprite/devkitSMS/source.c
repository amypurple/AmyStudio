#include "SGlib.h"
#include "sprite-patterns.h"

void main(void)
{
    unsigned char x = 120, y = 88, tick = 0, anim = 0;
    SG_setBackdropColor(SG_COLOR_DARK_BLUE);
    SG_setSpriteMode(SG_SPRITEMODE_LARGE);
    SG_loadSpritePatterns((void *)sprite_patterns, 0, sizeof(sprite_patterns));
    SG_displayOn();

    for (;;) {
        unsigned int input;
        SG_waitForVBlank();
        input = SG_getKeysStatus();
        if ((input & PORT_A_KEY_LEFT) && x > 1) --x;
        if ((input & PORT_A_KEY_RIGHT) && x < 239) ++x;
        if ((input & PORT_A_KEY_UP) && y > 1) --y;
        if ((input & PORT_A_KEY_DOWN) && y < 175) ++y;
        if (++tick == 8) { tick = 0; anim = anim ? 0 : 12; }

        SG_initSprites();
        SG_addSprite(x, y, anim, SG_COLOR_WHITE);
        SG_addSprite(x, y, anim + 4, SG_COLOR_LIGHT_YELLOW);
        SG_addSprite(x, y, anim + 8, SG_COLOR_BLACK);
        SG_finalizeSprites();
        SG_copySpritestoSAT();
    }
}
