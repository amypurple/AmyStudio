BITMAP ENABLE (16)

white0Image := LOAD IMAGE("ugbasic-detailframe0.png")
yellow0Image := LOAD IMAGE("ugbasic-bodyframe0.png")
black0Image := LOAD IMAGE("ugbasic-outlineframe0.png")
white1Image := LOAD IMAGE("ugbasic-detailframe1.png")
yellow1Image := LOAD IMAGE("ugbasic-bodyframe1.png")
black1Image := LOAD IMAGE("ugbasic-outlineframe1.png")

white0 = SPRITE(white0Image)
yellow0 = SPRITE(yellow0Image)
black0 = SPRITE(black0Image)
white1 = SPRITE(white1Image)
yellow1 = SPRITE(yellow1Image)
black1 = SPRITE(black1Image)

VAR spriteX AS BYTE = 120
VAR spriteY AS BYTE = 88
VAR tick AS BYTE = 0
VAR anim AS BYTE = 0

SPRITE white0 AT spriteX,spriteY COLOR WHITE ENABLE
SPRITE yellow0 AT spriteX,spriteY COLOR YELLOW ENABLE
SPRITE black0 AT spriteX,spriteY COLOR BLACK ENABLE

DO
    WAIT VBL
    IF JLEFT(0) AND spriteX > 1 THEN : DEC spriteX : ENDIF
    IF JRIGHT(0) AND spriteX < 239 THEN : INC spriteX : ENDIF
    IF JUP(0) AND spriteY > 1 THEN : DEC spriteY : ENDIF
    IF JDOWN(0) AND spriteY < 175 THEN : INC spriteY : ENDIF
    INC tick
    IF tick = 8 THEN
        tick = 0
        IF anim = 0 THEN
            anim = 1
            SPRITE white0 DISABLE : SPRITE yellow0 DISABLE : SPRITE black0 DISABLE
            SPRITE white1 AT spriteX,spriteY COLOR WHITE ENABLE
            SPRITE yellow1 AT spriteX,spriteY COLOR YELLOW ENABLE
            SPRITE black1 AT spriteX,spriteY COLOR BLACK ENABLE
        ELSE
            anim = 0
            SPRITE white1 DISABLE : SPRITE yellow1 DISABLE : SPRITE black1 DISABLE
            SPRITE white0 AT spriteX,spriteY COLOR WHITE ENABLE
            SPRITE yellow0 AT spriteX,spriteY COLOR YELLOW ENABLE
            SPRITE black0 AT spriteX,spriteY COLOR BLACK ENABLE
        ENDIF
    ELSE
        IF anim = 0 THEN
            SPRITE white0 AT spriteX,spriteY
            SPRITE yellow0 AT spriteX,spriteY
            SPRITE black0 AT spriteX,spriteY
        ELSE
            SPRITE white1 AT spriteX,spriteY
            SPRITE yellow1 AT spriteX,spriteY
            SPRITE black1 AT spriteX,spriteY
        ENDIF
    ENDIF
LOOP
