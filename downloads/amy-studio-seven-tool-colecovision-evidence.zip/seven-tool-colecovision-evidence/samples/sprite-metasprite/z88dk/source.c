#include <games.h>
#include <intrinsic.h>
#include <video/tms99x8.h>
#include "sprite-patterns.h"

int main(void)
{
    unsigned char x = 120, y = 88, tick = 0, anim = 0;
    unsigned char layer;

    vdp_set_sprite_mode(sprite_large);
    for (layer = 0; layer != 6; ++layer) {
        vdp_set_sprite_16(layer, (void *)(sprite_patterns + (layer << 5)));
    }

    for (;;) {
        intrinsic_halt();
        if (joystick(3) & MOVE_LEFT) { if (x > 1) --x; }
        if (joystick(3) & MOVE_RIGHT) { if (x < 239) ++x; }
        if (joystick(3) & MOVE_UP) { if (y > 1) --y; }
        if (joystick(3) & MOVE_DOWN) { if (y < 175) ++y; }
        if (++tick == 8) { tick = 0; anim = anim ? 0 : 3; }
        vdp_put_sprite_16(0, x, y, anim, VDP_INK_WHITE);
        vdp_put_sprite_16(1, x, y, anim + 1, VDP_INK_LIGHT_YELLOW);
        vdp_put_sprite_16(2, x, y, anim + 2, VDP_INK_BLACK);
        vdp_put_sprite_16(3, 0, 209, 0, 0);
    }
}
