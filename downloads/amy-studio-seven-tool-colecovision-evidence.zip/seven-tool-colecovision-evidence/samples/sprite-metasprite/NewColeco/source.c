#include <coleco.h>
#include <getput1.h>
#include "sprite-patterns.h"

static const byte silent_sound[] = { 0xff };
const sound_t snd_table[] = { { silent_sound, SOUNDAREA1 } };

void nmi(void)
{
    updatesprites(0, 3);
}

void main(void)
{
    byte x = 120, y = 88, tick = 0, anim = 0;
    screen_mode_2_text();
    sprites_16x16();
    sprites_simple();
    put_vram(0x3800, (void *)sprite_patterns, sizeof(sprite_patterns));
    clear_sprites(0, 32);
    enable_nmi();
    screen_on();

    for (;;) {
        delay(1);
        if ((joypad_1 & LEFT) && x > 1) --x;
        if ((joypad_1 & RIGHT) && x < 239) ++x;
        if ((joypad_1 & UP) && y > 1) --y;
        if ((joypad_1 & DOWN) && y < 175) ++y;
        if (++tick == 8) { tick = 0; anim = anim ? 0 : 12; }
        sprites[0].y = y; sprites[0].x = x; sprites[0].pattern = anim; sprites[0].colour = 15;
        sprites[1].y = y; sprites[1].x = x; sprites[1].pattern = anim + 4; sprites[1].colour = 11;
        sprites[2].y = y; sprites[2].x = x; sprites[2].pattern = anim + 8; sprites[2].colour = 1;
    }
}
