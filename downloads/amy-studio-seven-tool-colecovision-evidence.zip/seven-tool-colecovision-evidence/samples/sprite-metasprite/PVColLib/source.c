#include <coleco.h>
#include "sprite-patterns.h"

void nmi(void)
{
    if (spr_enable) spr_update();
}

void main(void)
{
    u8 x = 120, y = 88, tick = 0, anim = 0;
    vdp_disablescr();
    vdp_setmode2txt();
    spr_mode16x16();
    spr_clear();
    vdp_putvram(sprtab, sprite_patterns, sizeof(sprite_patterns));
    spr_set(0, x, y, 15, 0);
    spr_set(1, x, y, 11, 4);
    spr_set(2, x, y, 1, 8);
    vdp_enablescr();
    vdp_enablenmi();
    spr_enable = 1;

    for (;;) {
        vdp_waitvblank(1);
        if ((joypad_1 & PAD_LEFT) && x > 1) --x;
        if ((joypad_1 & PAD_RIGHT) && x < 239) ++x;
        if ((joypad_1 & PAD_UP) && y > 1) --y;
        if ((joypad_1 & PAD_DOWN) && y < 175) ++y;
        if (++tick == 8) { tick = 0; anim = anim ? 0 : 12; }
        spr_set(0, x, y, 15, anim);
        spr_set(1, x, y, 11, anim + 4);
        spr_set(2, x, y, 1, anim + 8);
    }
}
