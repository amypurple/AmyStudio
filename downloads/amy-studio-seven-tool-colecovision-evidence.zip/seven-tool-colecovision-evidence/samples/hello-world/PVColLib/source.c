#include <coleco.h>

void nmi(void) {
}

void main(void) {
    vdp_setmode2txt();
    vdp_setdefaultchar(FNTNORMAL);
    vdp_duplicatevram();
    vdp_fillvram(coltab, 0xF1, 128 * 8);
    vdp_putstring(9, 11, "HELLO, WORLD!");
    vdp_enablescr();

    for (;;) vdp_waitvblank(1);
}
