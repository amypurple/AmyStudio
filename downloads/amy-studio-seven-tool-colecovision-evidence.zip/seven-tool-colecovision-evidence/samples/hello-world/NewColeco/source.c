#include <coleco.h>
#include <getput1.h>

static const byte silent_sound[] = { 0xff };
const sound_t snd_table[] = {
    { silent_sound, SOUNDAREA1 }
};

void nmi(void)
{
}

void main(void)
{
    screen_mode_2_text();
    upload_default_ascii(NORMAL);
    fill_color(0, 0xf1, 255);
    center_string(11, "HELLO, WORLD!");
    enable_nmi();
    screen_on();
    while (1) {
    }
}
