#include <stdio.h>

int main(void)
{
    printf("\x0c\n\n\n\n\n\n\n\n\n\n\n  HELLO, WORLD!");
    for (;;) {}
}
