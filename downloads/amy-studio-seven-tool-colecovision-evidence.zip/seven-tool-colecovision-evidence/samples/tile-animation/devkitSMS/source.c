#include "SGlib.h"
#include "tile-animation-data.h"

static void draw_ships(unsigned char frame)
{
    unsigned char i;
    for (i = 0; i != 6; ++i) SG_loadTileMapArea(ship_x[i], ship_y[i], (void *)ship_frames[frame], 3, 2);
}

void main(void)
{
    unsigned char i, tick, star = 0, ship = 0;
    unsigned int cell;
    SG_displayOff();
    SG_setBackdropColor(SG_COLOR_BLACK);
    SG_setNextTileatXY(0, 0);
    for (cell = 0; cell != 768; ++cell) SG_setTile(0x20);
    for (i = 0; i != 3; ++i) {
        unsigned int base = ((unsigned int)i << 8);
        SG_loadTilePatterns((void *)star_patterns[0], base + 0x80, 8);
        SG_loadTilePatterns((void *)ship_patterns, base + 0x90, 96);
        SG_loadTileColours((void *)star_color, base + 0x80, 8);
        SG_loadTileColours((void *)ship_colors, base + 0x90, 96);
    }
    for (i = 0; i != 12; ++i) SG_setTileatXY(star_x[i], star_y[i], 0x80);
    draw_ships(0);
    SG_displayOn();
    for (tick = 0; tick != 64; ++tick) {
        SG_waitForVBlank();
        if ((tick & 3) == 3) {
            unsigned char third;
            star = (star + 1) & 3;
            for (third = 0; third != 3; ++third)
                SG_loadTilePatterns((void *)star_patterns[star], ((unsigned int)third << 8) + 0x80, 8);
        }
        if ((tick & 7) == 7) { ship ^= 1; draw_ships(ship); }
    }
    for (;;) SG_waitForVBlank();
}
