SECTION code_user

PUBLIC zx0_to_vram
PUBLIC _zx0_to_vram

; ZX0 standard decoder adapted from z88dk's official 69-byte RAM decoder.
; HL remains the compressed ROM source while DE is a TMS9918 VRAM address.
zx0_to_vram:
_zx0_to_vram:
    pop af
    pop de
    pop hl
    push hl
    push de
    push af
    ld bc,$ffff
    push bc
    inc bc
    ld a,$80
zx0_literals:
    call zx0_elias
    push af
    call zx0_set_write_de
zx0_literal_loop:
    ld a,(hl)
    out ($be),a
    inc hl
    inc de
    dec bc
    ld a,b
    or c
    jr nz,zx0_literal_loop
    pop af
    add a,a
    jr c,zx0_new_offset
    call zx0_elias
zx0_copy:
    ex (sp),hl
    push hl
    add hl,de
    push af
    call zx0_vram_copy
    pop af
    pop hl
    ex (sp),hl
    add a,a
    jr nc,zx0_literals
zx0_new_offset:
    call zx0_elias
    ex af,af'
    pop af
    xor a
    sub c
    ret z
    ld b,a
    ex af,af'
    ld c,(hl)
    inc hl
    rr b
    rr c
    push bc
    ld bc,1
    call nc,zx0_elias_backtrack
    inc bc
    jr zx0_copy
zx0_elias:
    inc c
zx0_elias_loop:
    add a,a
    jr nz,zx0_elias_skip
    ld a,(hl)
    inc hl
    rla
zx0_elias_skip:
    ret c
zx0_elias_backtrack:
    add a,a
    rl c
    rl b
    jr zx0_elias_loop

; Copy BC bytes inside VRAM. Sequential read/write makes overlap safe.
zx0_vram_copy:
    ld a,b
    or c
    ret z
zx0_vram_copy_loop:
    call zx0_set_read_hl
    in a,($be)
    push af
    call zx0_set_write_de
    pop af
    out ($be),a
    inc hl
    inc de
    dec bc
    ld a,b
    or c
    jr nz,zx0_vram_copy_loop
    ret
zx0_set_write_de:
    ld a,e
    out ($bf),a
    ld a,d
    and $3f
    or $40
    out ($bf),a
    ex (sp),hl
    ex (sp),hl
    ret
zx0_set_read_hl:
    ld a,l
    out ($bf),a
    ld a,h
    and $3f
    out ($bf),a
    ex (sp),hl
    ex (sp),hl
    ret
