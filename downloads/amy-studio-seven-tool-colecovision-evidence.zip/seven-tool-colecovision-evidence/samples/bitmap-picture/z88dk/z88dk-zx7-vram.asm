SECTION code_user

PUBLIC zx7_to_vram
PUBLIC _zx7_to_vram

; void zx7_to_vram(void *src, unsigned int dst)
zx7_to_vram:
_zx7_to_vram:
    pop af
    pop de
    pop hl
    push hl
    push de
    push af

    ld a,$80
    jr zx7_literal

zx7_main:
    call zx7_next_bit
    jr nc,zx7_literal

    push de
    ld bc,0
    ld d,b

zx7_len_size:
    inc d
    call zx7_next_bit
    jr nc,zx7_len_size

zx7_len_value:
    call nc,zx7_next_bit
    rl c
    rl b
    jr c,zx7_exit
    dec d
    jr nz,zx7_len_value
    inc bc

    ld e,(hl)
    inc hl
    sla e
    inc e
    jr nc,zx7_offset_ready
    ld d,$10

zx7_offset_bits:
    call zx7_next_bit
    rl d
    jr nc,zx7_offset_bits
    inc d
    srl d

zx7_offset_ready:
    rr e
    ex (sp),hl
    push hl
    sbc hl,de
    pop de
    push af
    call zx7_vram_copy
    pop af
    pop hl
    jr nc,zx7_main

zx7_exit:
    pop de
    ret

zx7_literal:
    push af
    push hl
    call zx7_set_write_de
    pop hl
    ld a,(hl)
    out ($be),a
    inc hl
    inc de
    pop af
    jr zx7_main

zx7_next_bit:
    add a,a
    ret nz
    ld a,(hl)
    inc hl
    rla
    ret

; Copy BC bytes inside VRAM. This is overlap-safe and uses no RAM buffer.
zx7_vram_copy:
    ld a,b
    or c
    ret z
zx7_vram_copy_loop:
    call zx7_set_read_hl
    in a,($be)
    push af
    call zx7_set_write_de
    pop af
    out ($be),a
    inc hl
    inc de
    dec bc
    ld a,b
    or c
    jr nz,zx7_vram_copy_loop
    ret

zx7_set_write_de:
    ld a,e
    out ($bf),a
    ld a,d
    and $3f
    or $40
    out ($bf),a
    ex (sp),hl
    ex (sp),hl
    ret

zx7_set_read_hl:
    ld a,l
    out ($bf),a
    ld a,h
    and $3f
    out ($bf),a
    ex (sp),hl
    ex (sp),hl
    ret
