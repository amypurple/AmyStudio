#include <coleco.h>
#include "warrior-dan2.h"

static const byte silent_sound[] = { 0xff };
const sound_t snd_table[] = {
    { silent_sound, SOUNDAREA1 }
};

void dan2(unsigned vram_offset, const void *data);

void nmi(void)
{
}

void main(void)
{
    screen_off();
    screen_mode_2_bitmap();
    dan2(0x0000, warrior_pattern);
    dan2(0x2000, warrior_color);
    enable_nmi();
    screen_on();
    while (1) {
    }
}
