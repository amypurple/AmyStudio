#include <coleco.h>
#include "warrior-rle.h"

void nmi(void) {
}

void main(void) {
    vdp_disablescr();
    vdp_setmode2bmp();
    vdp_rle2vram(warrior_pattern, chrgen);
    vdp_rle2vram(warrior_color, coltab);
    vdp_enablescr();

    for (;;) vdp_waitvblank(1);
}
