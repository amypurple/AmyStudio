BITMAP ENABLE(16)
CLS BLACK
warrior := LOAD IMAGE("warrior-ugbasic.bmp") EXACT
PUT IMAGE warrior AT 0,0
DO
  WAIT VBL
LOOP
