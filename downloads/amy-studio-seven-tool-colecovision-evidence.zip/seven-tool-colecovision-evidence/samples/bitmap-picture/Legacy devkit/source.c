#include <coleco.h>
#include <getput1.h>
#include "warrior-mdkrle.h"

static const byte silent_sound[] = { 0xff };
const sound_t snd_table[] = {
    { silent_sound, SOUNDAREA1 }
};

void nmi(void)
{
}

void main(void)
{
    screen_off();
    screen_mode_2_bitmap();
    rle2vram(warrior_pattern, 0x0000);
    rle2vram(warrior_color, 0x2000);
    enable_nmi();
    screen_on();
    while (1) {
    }
}
