# ColecoVision seven-tool evidence

Three equivalent samples built with Amy Studio, CVBasic, z88dk, ugBASIC, devkitSMS/SGlib_CV, PVColLib, and Amy's legacy SDCC devkit. Each tool folder contains its source, required local assets, and a loadable ColecoVision ROM truncated to the measured occupied bytes.

- `hello-world`: visible text startup
- `bitmap-picture`: complete 256x192 Warrior Graphics II image
- `controller-visual`: visible controller-state monitor
- `graphics-fidelity-corpus`: Cake, Commando, Warrior, and Barbarian sources, compact ROMs, measurements, and framebuffer results for Amy, CVBasic, and ugBASIC

All twenty-one compact seven-tool ROMs completed 180 NTSC frames in GearColeco while packaging. The seven Warrior ROMs were separately verified to differ by 0 of 49,152 framebuffer pixels. z88dk uses a small project-level MDKRLE decoder with its VRAM block primitives, devkitSMS uses official aPack payloads, PVColLib uses native RLE, and the legacy devkit links its historical DAN2 direct-to-VRAM routine. `manifest.csv` records sizes and hashes; `SHA256SUMS.txt` allows ROM verification. Cartridge padding is intentionally excluded.
