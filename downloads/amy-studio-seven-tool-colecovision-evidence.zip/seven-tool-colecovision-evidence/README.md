# ColecoVision seven-tool evidence

Four equivalent samples built with Amy Studio, CVBasic, z88dk, ugBASIC, devkitSMS/SGlib_CV, PVColLib, and Amy's legacy SDCC devkit. Each tool folder contains its source, required local assets, and a loadable ColecoVision ROM truncated to the measured occupied bytes.

- `hello-world`: visible text startup
- `bitmap-picture`: complete 256x192 Warrior Graphics II image
- `controller-visual`: visible controller-state monitor
- `sprite-metasprite`: animated, controller-driven three-color metasprite
- `graphics-fidelity-corpus`: Cake, Commando, Warrior, and Barbarian sources, compact ROMs, measurements, and framebuffer results for Amy, CVBasic, and ugBASIC
- `graphics-compression-corpus`: exact byte counts and RAW-payload ratios for eleven Graphics II pictures and thirteen codecs

All twenty-eight compact seven-tool ROMs completed 180 NTSC frames in GearColeco while packaging. The seven Warrior outputs were separately verified to differ by 0 of 49,152 framebuffer pixels, and the metasprite ROMs pass the common VRAM/SAT oracle. Amy uses modern ZX0 v2. z88dk uses ZX0 Classic v1 through a Coleco-safe direct-to-VRAM adaptation written for this benchmark; its similarly adapted ZX7 and MDKRLE source alternatives are included beside it. devkitSMS uses official aPack payloads, PVColLib uses native RLE, and the legacy devkit links its historical DAN2 direct-to-VRAM routine. The ugBASIC folder also includes its accepted `COMPRESSED` source; for Warrior, the compiler deliberately emits the same ROM because MSC1 provides no gain and Coleco RLE is not implemented. `manifest.csv` records sizes and hashes; `SHA256SUMS.txt` allows ROM verification. Cartridge padding is intentionally excluded.
