### Graphics II bitmap compression ratios

Each picture is exactly 12,288 RAW bytes (6,144 Pattern + 6,144 Color). Percentages are compressed payload / RAW payload; lower is better. Decoder code is excluded because it is linked once and may serve several assets. Every measured stream round-trips exactly; DAN3 uses its full-search best-size setting. ZX0 Classic and modern use incompatible streams but produced identical payload sizes throughout this corpus, so one ratio column represents both.

### LZ-family ratios

| Picture | ZX0 Classic / modern | ZX1 | ZX2 | ZX7 | aPLib Compact | Pletter | BitBuster | LZF |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Cake | 24.07% | 25.33% | 25.42% | 25.26% | 24.85% | 25.29% | 25.44% | 29.48% |
| Commando | 43.21% | 45.58% | 45.18% | 44.86% | 44.39% | 44.82% | 45.07% | 49.93% |
| Warrior | 23.19% | 24.12% | 25.38% | 24.28% | 24.19% | 24.32% | 24.43% | 26.00% |
| Barbarian | 34.42% | 36.11% | 36.39% | 35.31% | 35.45% | 35.31% | 35.51% | 39.10% |
| 421 title | 8.59% | 8.97% | 9.08% | 9.02% | 8.94% | 9.03% | 9.16% | 11.01% |
| 421 credits | 22.68% | 23.56% | 23.40% | 24.18% | 23.50% | 24.22% | 24.35% | 26.34% |
| Dacman title | 8.01% | 8.33% | 8.49% | 8.38% | 8.24% | 8.42% | 8.50% | 9.62% |
| Dacman info | 10.25% | 10.47% | 11.34% | 11.06% | 10.38% | 11.08% | 11.19% | 12.51% |
| Dacman 2 title | 9.56% | 10.04% | 10.13% | 9.99% | 9.99% | 10.02% | 10.12% | 11.82% |
| Chateau title | 13.31% | 13.70% | 13.77% | 14.07% | 13.88% | 14.08% | 14.18% | 15.53% |
| Arcade Trio title | 24.41% | 25.82% | 25.53% | 25.19% | 25.06% | 25.20% | 25.33% | 29.26% |

### DAN and RLE-family ratios

| Picture | DAN1 | DAN2 | DAN3 Best | Nibble | MDK-RLE |
|---|---:|---:|---:|---:|---:|
| Cake | 24.46% | 24.41% | 24.45% | 28.92% | 33.11% |
| Commando | 43.33% | 43.23% | 43.29% | 51.23% | 59.29% |
| Warrior | 23.62% | 23.58% | 23.53% | 27.22% | 30.00% |
| Barbarian | 35.34% | 35.29% | 34.88% | 41.32% | 44.78% |
| 421 title | 8.76% | 8.68% | 9.05% | 11.95% | 13.96% |
| 421 credits | 22.96% | 22.94% | 22.93% | 25.75% | 28.91% |
| Dacman title | 7.89% | 7.91% | 8.41% | 9.63% | 11.31% |
| Dacman info | 10.38% | 10.36% | 10.51% | 13.31% | 14.59% |
| Dacman 2 title | 9.53% | 9.51% | 9.71% | 13.54% | 16.42% |
| Chateau title | 13.44% | 13.44% | 13.49% | 17.01% | 18.95% |
| Arcade Trio title | 24.58% | 24.36% | 24.63% | 30.24% | 35.71% |

### Amy direct-to-VRAM decompressor sizes

These are assembled routine bytes, excluding compressed data and common program startup code. A routine is linked once and can decode any number of assets using that codec.

| Codec | Routine bytes |
|---|---:|
| ZX0 modern | 133 |
| ZX1 | 127 |
| ZX2 | 115 |
| ZX7 | 136 |
| aPLib Compact | 244 |
| Pletter | 212 |
| BitBuster | 166 |
| LZF | 117 |
| DAN1 | 205 |
| DAN2 | 212 |
| DAN3 Best | 205 |
| Nibble | 115 |
| MDK-RLE | 46 |

### Representative first-use totals

Each value is the complete compressed Pattern + Color payload plus one Amy direct-to-VRAM decompressor. It is not the full ROM size. Commando, Warrior, and Dacman title represent a difficult, middle, and highly compressible case in this corpus.

### LZ-family first-use bytes

| Codec | Commando | Warrior | Dacman title |
|---|---:|---:|---:|
| ZX0 modern | 5443 | 2982 | 1117 |
| ZX1 | 5728 | 3091 | 1151 |
| ZX2 | 5667 | 3234 | 1158 |
| ZX7 | 5649 | 3120 | 1166 |
| aPLib Compact | 5699 | 3217 | 1256 |
| Pletter | 5720 | 3200 | 1247 |
| BitBuster | 5704 | 3168 | 1211 |
| LZF | 6253 | 3312 | 1299 |

### DAN and RLE-family first-use bytes

| Codec | Commando | Warrior | Dacman title |
|---|---:|---:|---:|
| DAN1 | 5529 | 3108 | 1174 |
| DAN2 | 5524 | 3109 | 1184 |
| DAN3 Best | 5525 | 3096 | 1238 |
| Nibble | 6410 | 3460 | 1298 |
| MDK-RLE | 7331 | 3733 | 1436 |

Amy Studio's aPLib Compact routine is 244 bytes under every optimization profile, replacing the previous 348-byte unrolled routine. It preserves IX and IY, writes directly to VRAM, and keeps the same stream format and compressed payloads. MDK-RLE remains the smallest decoder at 46 bytes, but its payloads are much larger on these pictures.

The complete payload counts and ratios are preserved in `bitmap-codec-ratios.csv`; decoder and representative first-use totals are in `bitmap-codec-first-use.csv`.
