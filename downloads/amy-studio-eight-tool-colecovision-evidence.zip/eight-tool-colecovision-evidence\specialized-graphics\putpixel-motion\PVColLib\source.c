#include <coleco.h>

static const u8 colors[6] = { 3,4,7,8,10,15 };
static u8 x[6] = { 3,37,240,45,87,100 };
static u8 y[6] = { 123,99,3,15,200,22 };
static u8 direction[6] = { 0,1,3,2,0,1 };

static void put_pixel(u8 px, u8 py, u8 color)
{
    u16 address = ((u16)(py & 0xf8) << 5) + (px & 0xf8) + (py & 7);
    u8 value;
    vdp_getvram(address, &value, 1);
    value |= 0x80 >> (px & 7);
    vdp_putvram(address, &value, 1);
    value = (color << 4) | 1;
    vdp_putvram(address + 0x2000, &value, 1);
}

void nmi(void) {}

void main(void)
{
    u8 i, previous = 0;
    vdp_disablescr();
    vdp_setmode2txt();
    for (i = 0; i != 3; ++i) {
        u16 address = 0x1800 + ((u16)i << 8);
        u16 tile;
        for (tile = 0; tile != 256; ++tile) {
            u8 value = tile;
            vdp_putvram(address + tile, &value, 1);
        }
    }
    vdp_enablescr();
    vdp_enablenmi();
    for (;;) {
        u8 buttons;
        vdp_waitvblank(1);
        buttons = (joypad_1 | joypad_2) & PAD_FIRES;
        if (buttons && !previous) {
            for (i = 0; i != 6; ++i) direction[i] = (direction[i] + 1) & 3;
        } else if (!buttons) {
            for (i = 0; i != 6; ++i) {
                switch (direction[i]) {
                case 0: ++x[i]; if (++y[i] >= 192) y[i] -= 192; break;
                case 1: ++x[i]; if (--y[i] >= 192) y[i] += 192; break;
                case 2: --x[i]; if (--y[i] >= 192) y[i] += 192; break;
                default: --x[i]; if (++y[i] >= 192) y[i] -= 192; break;
                }
                put_pixel(x[i], y[i], colors[i]);
            }
        }
        previous = buttons;
    }
}

