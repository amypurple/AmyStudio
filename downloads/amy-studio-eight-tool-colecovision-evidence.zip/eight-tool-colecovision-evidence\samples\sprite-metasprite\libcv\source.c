#include <stdint.h>

#include "cv.h"
#include "cvu.h"
#include "sprite-patterns.h"

#define SPRITE_PATTERNS ((const cv_vmemp)0x3800)
#define SPRITES ((const cv_vmemp)0x1b00)

static volatile uint8_t frame_ready;

static void on_vblank(void)
{
    frame_ready = 1;
}

static void draw_actor(uint8_t x, uint8_t y, uint8_t frame)
{
    struct cvu_sprite sprites[4] = {
        { y, x, frame, CV_COLOR_WHITE },
        { y, x, frame + 4, CV_COLOR_LIGHT_YELLOW },
        { y, x, frame + 8, CV_COLOR_BLACK },
        { 0xd0, 0, 0, 0 },
    };
    cvu_memtovmemcpy(SPRITES, sprites, sizeof(sprites));
}

void main(void)
{
    struct cv_controller_state controller;
    uint8_t x = 120, y = 88, tick = 0, animation = 0;

    cv_set_screen_active(false);
    cv_set_sprite_pattern_table(SPRITE_PATTERNS);
    cv_set_sprite_attribute_table(SPRITES);
    cv_set_screen_mode(CV_SCREENMODE_BITMAP);
    cv_set_sprite_magnification(false);
    cv_set_sprite_big(true);
    cvu_memtovmemcpy(SPRITE_PATTERNS, sprite_patterns, sizeof(sprite_patterns));
    draw_actor(x, y, animation);
    cv_set_vint_handler(on_vblank);
    cv_set_screen_active(true);

    for (;;) {
        while (!frame_ready);
        frame_ready = 0;
        cv_get_controller_state(&controller, 0);
        if ((controller.joystick & CV_LEFT) && x > 1) --x;
        if ((controller.joystick & CV_RIGHT) && x < 239) ++x;
        if ((controller.joystick & CV_UP) && y > 1) --y;
        if ((controller.joystick & CV_DOWN) && y < 175) ++y;
        if (++tick == 8) {
            tick = 0;
            animation = animation ? 0 : 12;
        }
        draw_actor(x, y, animation);
    }
}
