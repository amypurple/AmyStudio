#include <stdint.h>

#include "cv.h"
#include "cvu.h"
#include "tile-animation-data.h"

#define PATTERN ((const cv_vmemp)0x0000)
#define IMAGE ((const cv_vmemp)0x1800)
#define COLOR ((const cv_vmemp)0x2000)

static volatile uint8_t frame_ready;

static void on_vblank(void)
{
    frame_ready = 1;
}

static void draw_ships(uint8_t frame)
{
    uint8_t index;
    for (index = 0; index != 6; ++index) {
        cvu_memtovmemcpy(IMAGE + ship_y[index] * 32 + ship_x[index], &ship_frames[frame][0], 3);
        cvu_memtovmemcpy(IMAGE + (ship_y[index] + 1) * 32 + ship_x[index], &ship_frames[frame][3], 3);
    }
}

void main(void)
{
    uint8_t index, tick = 0, star = 0, ship = 0, tile = 0x80;

    cv_set_screen_active(false);
    cv_set_image_table(IMAGE);
    cv_set_color_table(0x3fff);
    cv_set_character_pattern_t(0x1fff);
    cv_set_colors(CV_COLOR_BLACK, CV_COLOR_BLACK);
    cv_set_screen_mode(CV_SCREENMODE_BITMAP);
    cvu_vmemset(IMAGE, 0x20, 768);
    for (index = 0; index != 3; ++index) {
        uint16_t third = (uint16_t)index << 11;
        cvu_memtovmemcpy(PATTERN + third + 0x400, star_patterns[0], 8);
        cvu_memtovmemcpy(PATTERN + third + 0x480, ship_patterns, 96);
        cvu_memtovmemcpy(COLOR + third + 0x400, star_color, 8);
        cvu_memtovmemcpy(COLOR + third + 0x480, ship_colors, 96);
    }
    for (index = 0; index != 12; ++index)
        cvu_memtovmemcpy(IMAGE + star_y[index] * 32 + star_x[index], &tile, 1);
    draw_ships(0);
    cv_set_vint_handler(on_vblank);
    cv_set_screen_active(true);

    for (;;) {
        while (!frame_ready);
        frame_ready = 0;
        ++tick;
        if ((tick & 3) == 0) {
            uint8_t third;
            star = (star + 1) & 3;
            for (third = 0; third != 3; ++third)
                cvu_memtovmemcpy(PATTERN + ((uint16_t)third << 11) + 0x400, star_patterns[star], 8);
        }
        if ((tick & 7) == 0) {
            ship ^= 1;
            draw_ships(ship);
        }
    }
}
