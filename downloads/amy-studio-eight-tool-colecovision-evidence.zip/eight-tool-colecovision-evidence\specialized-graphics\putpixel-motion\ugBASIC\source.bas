DEFINE JOYSTICK SYNC

BITMAP ENABLE(256,192,16)
CLS

DIM colors AS BYTE(6) = #{ 3,4,7,8,10,15 }
DIM xpos AS BYTE(6) = #{ 3,37,240,45,87,100 }
DIM ypos AS BYTE(6) = #{ 123,99,3,15,200,22 }
DIM direction AS BYTE(6) = #{ 0,1,3,2,0,1 }

DO
  WAIT VBL
  buttons = (JOY(0) OR JOY(1)) AND 64
  IF buttons <> 0 AND previousButtons = 0 THEN
    FOR pixel = 0 TO 5
      direction(pixel) = (direction(pixel) + 1) AND 3
    NEXT
  ELSE
    FOR pixel = 0 TO 5
      SELECT CASE direction(pixel)
        CASE 0
          INC xpos(pixel) : INC ypos(pixel)
          IF ypos(pixel) >= 192 THEN ypos(pixel) = ypos(pixel) - 192
        CASE 1
          INC xpos(pixel) : DEC ypos(pixel)
          IF ypos(pixel) >= 192 THEN ypos(pixel) = ypos(pixel) + 192
        CASE 2
          DEC xpos(pixel) : DEC ypos(pixel)
          IF ypos(pixel) >= 192 THEN ypos(pixel) = ypos(pixel) + 192
        CASE ELSE
          DEC xpos(pixel) : INC ypos(pixel)
          IF ypos(pixel) >= 192 THEN ypos(pixel) = ypos(pixel) - 192
      ENDSELECT
      PLOT xpos(pixel),ypos(pixel),colors(pixel)
    NEXT
  ENDIF
  previousButtons = buttons
LOOP
