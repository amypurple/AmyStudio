#include <coleco.h>
#include "tile-animation-data.h"

static void draw_ships(u8 frame)
{
    u8 i;
    for (i = 0; i != 6; ++i) {
        vdp_putvram(chrtab + ship_y[i] * 32 + ship_x[i], (void *)&ship_frames[frame][0], 3);
        vdp_putvram(chrtab + (ship_y[i] + 1) * 32 + ship_x[i], (void *)&ship_frames[frame][3], 3);
    }
}

void nmi(void) {}

void main(void)
{
    u8 i, tick = 0, star = 0, ship = 0, tile = 0x80;
    vdp_disablescr();
    vdp_setmode2txt();
    vdp_fillvram(chrtab, 0x20, 768);
    for (i = 0; i != 3; ++i) {
        u16 third = (u16)i << 11;
        vdp_putvram(chrgen + third + 0x400, (void *)star_patterns[0], 8);
        vdp_putvram(chrgen + third + 0x480, (void *)ship_patterns, 96);
        vdp_putvram(coltab + third + 0x400, (void *)star_color, 8);
        vdp_putvram(coltab + third + 0x480, (void *)ship_colors, 96);
    }
    for (i = 0; i != 12; ++i) vdp_putvram(chrtab + star_y[i] * 32 + star_x[i], &tile, 1);
    draw_ships(0);
    vdp_enablescr();
    vdp_enablenmi();
    for (;;) {
        vdp_waitvblank(1);
        ++tick;
        if ((tick & 3) == 0) {
            u8 third;
            star = (star + 1) & 3;
            for (third = 0; third != 3; ++third)
                vdp_putvram(chrgen + ((u16)third << 11) + 0x400, (void *)star_patterns[star], 8);
        }
        if ((tick & 7) == 0) { ship ^= 1; draw_ships(ship); }
    }
}
