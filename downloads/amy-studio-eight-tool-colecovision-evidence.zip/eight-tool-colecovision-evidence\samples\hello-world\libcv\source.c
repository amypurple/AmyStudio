#include <stdint.h>

#include "cv.h"
#include "cvu.h"

#define PATTERN ((const cv_vmemp)0x0000)
#define IMAGE ((const cv_vmemp)0x1800)
#define COLOR ((const cv_vmemp)0x2000)

static const char message[] = "HELLO, WORLD!";

void main(void)
{
    uintptr_t font = *(int *)(0x006c) - 0x30 * 8;

    cv_set_screen_active(false);
    cv_set_image_table(IMAGE);
    cv_set_color_table(0x3fff);
    cv_set_character_pattern_t(0x1fff);
    cv_set_colors(CV_COLOR_LIGHT_BLUE, CV_COLOR_LIGHT_BLUE);
    cv_set_screen_mode(CV_SCREENMODE_BITMAP);

    cvu_memtovmemcpy(PATTERN, (const void *)font, 2048);
    cvu_memtovmemcpy(PATTERN + 2048, (const void *)font, 2048);
    cvu_memtovmemcpy(PATTERN + 4096, (const void *)font, 2048);
    cvu_vmemset(COLOR, (CV_COLOR_WHITE << 4) | CV_COLOR_LIGHT_BLUE, 6144);
    cvu_vmemset(IMAGE, ' ', 32 * 24);
    cvu_memtovmemcpy(IMAGE + 11 * 32 + 9, message, sizeof(message) - 1);
    cv_set_screen_active(true);

    for (;;);
}
