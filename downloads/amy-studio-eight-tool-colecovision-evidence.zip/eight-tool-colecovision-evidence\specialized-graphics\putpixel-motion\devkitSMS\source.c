#include "SGlib.h"

#define SCREEN_HEIGHT 192
#define NUM_PIXELS 6

static const unsigned char colors[NUM_PIXELS] = {
    SG_COLOR_LIGHT_GREEN, SG_COLOR_DARK_BLUE, SG_COLOR_CYAN,
    SG_COLOR_MEDIUM_RED, SG_COLOR_DARK_YELLOW, SG_COLOR_WHITE
};
static unsigned char x[NUM_PIXELS] = { 3,37,240,45,87,100 };
static unsigned char y[NUM_PIXELS] = { 123,99,3,15,200,22 };
static unsigned char direction[NUM_PIXELS] = { 0,1,3,2,0,1 };

void main(void)
{
    unsigned char pixel;
    SG_initBitmapMode(SG_COLOR_LIGHT_GREEN, SG_COLOR_TRANSPARENT);
    SG_displayOn();
    for (;;) {
        SG_waitForVBlank();
        if (SG_getKeysPressed() & (PORT_A_KEY_1 | PORT_A_KEY_2 | PORT_B_KEY_1 | PORT_B_KEY_2)) {
            for (pixel = 0; pixel != NUM_PIXELS; ++pixel)
                direction[pixel] = (direction[pixel] + 1) & 3;
        } else {
            for (pixel = 0; pixel != NUM_PIXELS; ++pixel) {
                switch (direction[pixel]) {
                case 0: ++x[pixel]; if (++y[pixel] >= SCREEN_HEIGHT) y[pixel] -= SCREEN_HEIGHT; break;
                case 1: ++x[pixel]; if (--y[pixel] >= SCREEN_HEIGHT) y[pixel] += SCREEN_HEIGHT; break;
                case 2: --x[pixel]; if (--y[pixel] >= SCREEN_HEIGHT) y[pixel] += SCREEN_HEIGHT; break;
                default: --x[pixel]; if (++y[pixel] >= SCREEN_HEIGHT) y[pixel] -= SCREEN_HEIGHT; break;
                }
                SG_putPixel(x[pixel], y[pixel], colors[pixel]);
            }
        }
    }
}

