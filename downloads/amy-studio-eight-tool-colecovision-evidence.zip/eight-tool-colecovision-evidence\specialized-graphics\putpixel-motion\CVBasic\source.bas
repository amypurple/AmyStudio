CONST PIXEL_COUNT = 6
CONST SCREEN_HEIGHT = 192

DIM colors(6)
DIM x(6)
DIM y(6)
DIM direction(6)

FOR pixel = 0 TO 5
  READ colors(pixel)
NEXT pixel
FOR pixel = 0 TO 5
  READ x(pixel)
NEXT pixel
FOR pixel = 0 TO 5
  READ y(pixel)
NEXT pixel
FOR pixel = 0 TO 5
  READ direction(pixel)
NEXT pixel

MODE 2
CLS
SCREEN DISABLE
FOR #third = 0 TO 2
  FOR #tile = 0 TO 255
    VPOKE $1800 + #third * 256 + #tile,#tile
  NEXT #tile
NEXT #third
SCREEN ENABLE

main_loop:
WAIT
buttons = CONT1.BUTTON OR CONT1.BUTTON2 OR CONT2.BUTTON OR CONT2.BUTTON2
IF buttons <> 0 AND previous_buttons = 0 THEN
  FOR pixel = 0 TO 5
    direction(pixel) = (direction(pixel) + 1) AND 3
  NEXT pixel
ELSE
  FOR pixel = 0 TO 5
    IF direction(pixel) = 0 THEN
      x(pixel) = x(pixel) + 1 : y(pixel) = y(pixel) + 1
      IF y(pixel) >= SCREEN_HEIGHT THEN y(pixel) = y(pixel) - SCREEN_HEIGHT
    ELSEIF direction(pixel) = 1 THEN
      x(pixel) = x(pixel) + 1 : y(pixel) = y(pixel) - 1
      IF y(pixel) >= SCREEN_HEIGHT THEN y(pixel) = y(pixel) + SCREEN_HEIGHT
    ELSEIF direction(pixel) = 2 THEN
      x(pixel) = x(pixel) - 1 : y(pixel) = y(pixel) - 1
      IF y(pixel) >= SCREEN_HEIGHT THEN y(pixel) = y(pixel) + SCREEN_HEIGHT
    ELSE
      x(pixel) = x(pixel) - 1 : y(pixel) = y(pixel) + 1
      IF y(pixel) >= SCREEN_HEIGHT THEN y(pixel) = y(pixel) - SCREEN_HEIGHT
    END IF
    px = x(pixel) : py = y(pixel) : ink = colors(pixel)
    GOSUB put_pixel
  NEXT pixel
END IF
previous_buttons = buttons
GOTO main_loop

put_pixel: PROCEDURE
#address = ((py AND $F8) * 32) + (px AND $F8) + (py AND 7)
mask = BIT_TABLE(px AND 7)
VPOKE #address,VPEEK(#address) OR mask
VPOKE #address+$2000,(ink * 16) OR 1
RETURN
END

DATA BYTE 3,4,7,8,10,15
DATA BYTE 3,37,240,45,87,100
DATA BYTE 123,99,3,15,200,22
DATA BYTE 0,1,3,2,0,1
BIT_TABLE: DATA BYTE $80,$40,$20,$10,$08,$04,$02,$01
