#include <intrinsic.h>
#include <video/tms99x8.h>
#include "tile-animation-data.h"

static void draw_ships(unsigned char frame)
{
    unsigned char i;
    for (i = 0; i != 6; ++i) {
        unsigned int address = 0x1800 + ship_y[i] * 32 + ship_x[i];
        unsigned char tile;
        for (tile = 0; tile != 3; ++tile) {
            vdp_vpoke(address + tile, ship_frames[frame][tile]);
            vdp_vpoke(address + 32 + tile, ship_frames[frame][tile + 3]);
        }
    }
}

int main(void)
{
    unsigned char i, tick = 0, star = 0, ship = 0;
    vdp_set_mode(mode_2);
    vdp_vfill(0x1800, 0x20, 768);
    for (i = 0; i != 3; ++i) {
        unsigned int third = (unsigned int)i << 11;
        vdp_vwrite((void *)star_patterns[0], third + 0x0400, 8);
        vdp_vwrite((void *)ship_patterns, third + 0x0480, 96);
        vdp_vwrite((void *)star_color, 0x2400 + third, 8);
        vdp_vwrite((void *)ship_colors, 0x2480 + third, 96);
    }
    for (i = 0; i != 12; ++i) vdp_vpoke(0x1800 + star_y[i] * 32 + star_x[i], 0x80);
    draw_ships(0);
    for (;;) {
        intrinsic_halt();
        ++tick;
        if ((tick & 3) == 0) {
            unsigned char third;
            star = (star + 1) & 3;
            for (third = 0; third != 3; ++third)
                vdp_vwrite((void *)star_patterns[star], 0x0400 + ((unsigned int)third << 11), 8);
        }
        if ((tick & 7) == 0) { ship ^= 1; draw_ships(ship); }
    }
}
