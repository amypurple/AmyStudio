#include <stdint.h>
#include "cv.h"
#include "cvu.h"

static volatile uint8_t frame_ready;
static const uint8_t colors[6] = { 3,4,7,8,10,15 };
static uint8_t x[6] = { 3,37,240,45,87,100 };
static uint8_t y[6] = { 123,99,3,15,200,22 };
static uint8_t direction[6] = { 0,1,3,2,0,1 };

static void on_vblank(void) { frame_ready = 1; }

static void put_pixel(uint8_t px, uint8_t py, uint8_t color)
{
    cv_vmemp address = (cv_vmemp)(((uint16_t)(py & 0xf8) << 5) + (px & 0xf8) + (py & 7));
    cvu_voutb(cvu_vinb(address) | (0x80 >> (px & 7)), address);
    cvu_voutb((color << 4) | 1, address + 0x2000);
}

void main(void)
{
    uint8_t i, previous = 0;
    struct cv_controller_state first, second;
    cv_set_screen_active(false);
    cv_set_image_table((cv_vmemp)0x1800);
    cv_set_color_table((cv_vmemp)0x3fff);
    cv_set_character_pattern_t((cv_vmemp)0x1fff);
    cv_set_screen_mode(CV_SCREENMODE_BITMAP);
    for (i = 0; i != 3; ++i) {
        uint16_t address = 0x1800 + ((uint16_t)i << 8);
        uint16_t tile;
        for (tile = 0; tile != 256; ++tile) cvu_voutb(tile, (cv_vmemp)(address + tile));
    }
    cv_set_vint_handler(on_vblank);
    cv_set_screen_active(true);
    for (;;) {
        uint8_t buttons;
        while (!frame_ready);
        frame_ready = 0;
        cv_get_controller_state(&first, 0);
        cv_get_controller_state(&second, 1);
        buttons = (first.joystick | second.joystick) & (CV_FIRE_0 | CV_FIRE_1);
        if (buttons && !previous) {
            for (i = 0; i != 6; ++i) direction[i] = (direction[i] + 1) & 3;
        } else if (!buttons) {
            for (i = 0; i != 6; ++i) {
                switch (direction[i]) {
                case 0: ++x[i]; if (++y[i] >= 192) y[i] -= 192; break;
                case 1: ++x[i]; if (--y[i] >= 192) y[i] += 192; break;
                case 2: --x[i]; if (--y[i] >= 192) y[i] += 192; break;
                default: --x[i]; if (++y[i] >= 192) y[i] -= 192; break;
                }
                put_pixel(x[i], y[i], colors[i]);
            }
        }
        previous = buttons;
    }
}
