# ColecoVision eight-tool evidence

Six principal samples compare common game-development work across Amy Studio, CVBasic, z88dk, ugBASIC, devkitSMS/SGlib_CV, PVColLib, libcv, and NewColeco. Specialized experiments are preserved separately and do not alter the principal rankings. Each tool folder contains its source and complete loadable ColecoVision ROM.

- `samples/hello-world`: visible text startup
- `samples/bitmap-picture`: complete 256x192 Warrior Graphics II image
- `samples/controller-visual`: visible controller-state monitor
- `samples/sprite-metasprite`: animated, controller-driven three-color metasprite
- `samples/state-update`: deterministic six-actor gameplay update
- `samples/tile-animation`: shared-pattern stars and six animated 3x2 tile ships
- `specialized-graphics/putpixel-motion`: per-pixel motion and controller experiment; seven PASS results and one documented ugBASIC PARTIAL result
- `specialized-graphics/vector-drawing-wip`: source-only pixel, line, and circle study; deliberately unranked until all ports have runtime proof
- `graphics-fidelity-corpus`: converter fidelity evidence
- `graphics-compression-corpus`: Graphics II compression evidence

`BootSmoke` means only that GearColeco ran the ROM for 180 NTSC frames without an emulator failure. It is not a behavioral PASS. `FunctionalStatus` records the dedicated verdict where one exists; fixture READMEs describe the actual oracle. `manifest.csv` distinguishes occupied bytes from ROM file bytes and records hashes; `SHA256SUMS.txt` allows ROM verification. Comparison figures exclude cartridge padding.
