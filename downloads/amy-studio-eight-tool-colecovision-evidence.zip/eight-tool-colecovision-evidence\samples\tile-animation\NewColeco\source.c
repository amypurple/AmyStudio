#include <coleco.h>
#include <getput1.h>
#include "tile-animation-data.h"

static const byte silent_sound[] = { 0xff };
const sound_t snd_table[] = { { silent_sound, SOUNDAREA1 } };

static void draw_ships(byte frame)
{
    byte i;
    for (i = 0; i != 6; ++i) {
        put_vram(0x1800 + ship_y[i] * 32 + ship_x[i], (void *)&ship_frames[frame][0], 3);
        put_vram(0x1800 + (ship_y[i] + 1) * 32 + ship_x[i], (void *)&ship_frames[frame][3], 3);
    }
}

void nmi(void) {}

void main(void)
{
    byte i, tick = 0, star = 0, ship = 0, tile = 0x80, section;
    screen_mode_2_text();
    fill_vram(0x1800, 0x20, 768);
    for (i = 0; i != 3; ++i) {
        put_vram(((unsigned)i << 11) + 0x0400, (void *)star_patterns[0], 8);
        put_vram(((unsigned)i << 11) + 0x0480, (void *)ship_patterns, 96);
        put_vram(((unsigned)i << 11) + 0x2400, (void *)star_color, 8);
        put_vram(((unsigned)i << 11) + 0x2480, (void *)ship_colors, 96);
    }
    for (i = 0; i != 12; ++i) put_vram(0x1800 + star_y[i] * 32 + star_x[i], &tile, 1);
    draw_ships(0);
    enable_nmi();
    screen_on();
    for (;;) {
        delay(1);
        ++tick;
        if ((tick & 3) == 0) {
            star = (star + 1) & 3;
            for (section = 0; section != 3; ++section)
                put_vram(((unsigned)section << 11) + 0x0400, (void *)star_patterns[star], 8);
        }
        if ((tick & 7) == 0) { ship ^= 1; draw_ships(ship); }
    }
}
