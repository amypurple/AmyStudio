# Vector drawing benchmark (work in progress)

This specialized fixture is based on Oscar Toledo's CVBasic `plot.bas` example.
It draws pixels, colored pixels, Bresenham lines, and circles in Graphics II mode.

The Amy Studio port already runs as `cvbasic-plot-port.alexis`. The original
CVBasic source is retained in `competition/CVBasic/examples/plot.bas`.

This fixture is not ranked yet. Each remaining toolchain needs an equivalent
source, a loadable ROM, and a GearColeco framebuffer oracle before any size or
capability comparison is published. Missing high-level primitives may be
implemented with a clearly identified minimal VRAM bridge; that is evidence of
workability, not evidence of native language support.
