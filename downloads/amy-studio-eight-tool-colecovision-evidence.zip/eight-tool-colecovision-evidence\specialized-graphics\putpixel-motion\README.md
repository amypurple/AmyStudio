# PutPixel motion benchmark

This fixture is based on sverx's 2025 SGlib `putPixel` demonstration. It compares
the same visible workload across the ColecoVision toolchains:

- six independently colored pixels start at the same coordinates;
- every visible frame advances each pixel diagonally by one pixel;
- horizontal coordinates wrap as unsigned bytes;
- vertical coordinates wrap within 0..191;
- a newly pressed fire button 1 or 2 on either controller rotates all six
  directions instead of moving them during that frame;
- drawing is synchronized to VBlank and must not corrupt Graphics II VRAM.

Each implementation uses its native bitmap/pixel/controller API when one exists.
A toolchain without a pixel primitive uses a documented minimal VRAM bridge. The
results must identify that distinction; a bridge is not a native language feature.

## Verified result

`results.csv` records occupied bytes without cartridge padding. Amy Studio,
CVBasic, z88dk, devkitSMS, PVColLib, libcv, and NewColeco pass the deterministic
GearColeco test for bitmap motion, both controller ports, and unchanged Name
Table data. NewColeco is intentionally built with SDCC 2.9.0 because its
archived libraries use that compiler's stack ABI.

The exact compiler, checksum, object convention, link order, failure symptoms,
and publication rules are preserved in
`docs/newcoleco-sdcc-toolchain-compatibility.md`. A ROM that merely builds or
boots does not qualify as a benchmark result.

ugBASIC's native `PLOT` output and continuous motion work, but both FIRE tests
remain neutral, including with `DEFINE JOYSTICK SYNC`. Its Coleco backend places
four `NOP` instructions (16 cycles) between controller-mode selection and the
input read. This is shorter than the settling delay used by the official Coleco
BIOS and required for ADAM compatibility, so the benchmark reports `PARTIAL`
rather than hiding the ROM or treating its graphics support as a failure.
