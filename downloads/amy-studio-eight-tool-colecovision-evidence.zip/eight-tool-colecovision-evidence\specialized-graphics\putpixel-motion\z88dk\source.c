#include <games.h>
#include <intrinsic.h>
#include <stdint.h>
#include <video/tms99x8.h>

static const uint8_t colors[6] = { 3,4,7,8,10,15 };
static uint8_t x[6] = { 3,37,240,45,87,100 };
static uint8_t y[6] = { 123,99,3,15,200,22 };
static uint8_t direction[6] = { 0,1,3,2,0,1 };

static void put_pixel(uint8_t px, uint8_t py, uint8_t color)
{
    uint16_t address = ((uint16_t)(py & 0xf8) << 5) + (px & 0xf8) + (py & 7);
    vdp_vpoke(address, vdp_vpeek(address) | (0x80 >> (px & 7)));
    vdp_vpoke(address + 0x2000, (color << 4) | 1);
}

int main(void)
{
    uint8_t i, previous = 0;
    vdp_set_mode(mode_2);
    for (i = 0; i != 3; ++i) {
        uint16_t address = 0x1800 + ((uint16_t)i << 8);
        uint16_t tile;
        for (tile = 0; tile != 256; ++tile) vdp_vpoke(address + tile, tile);
    }
    for (;;) {
        uint8_t buttons;
        intrinsic_halt();
        buttons = (joystick(3) | joystick(4)) & (MOVE_FIRE1 | MOVE_FIRE2);
        if (buttons && !previous) {
            for (i = 0; i != 6; ++i) direction[i] = (direction[i] + 1) & 3;
        } else if (!buttons) {
            for (i = 0; i != 6; ++i) {
                switch (direction[i]) {
                case 0: ++x[i]; if (++y[i] >= 192) y[i] -= 192; break;
                case 1: ++x[i]; if (--y[i] >= 192) y[i] += 192; break;
                case 2: --x[i]; if (--y[i] >= 192) y[i] += 192; break;
                default: --x[i]; if (++y[i] >= 192) y[i] -= 192; break;
                }
                put_pixel(x[i], y[i], colors[i]);
            }
        }
        previous = buttons;
    }
}

