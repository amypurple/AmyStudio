#include <stdint.h>

#include "cv.h"

static volatile uint8_t frame_ready;

static void on_vblank(void)
{
    frame_ready = 1;
}

void main(void)
{
    struct cv_controller_state state;
    enum cv_color color;

    cv_set_colors(CV_COLOR_LIGHT_BLUE, CV_COLOR_BLUE);
    cv_set_vint_handler(on_vblank);
    cv_set_screen_active(true);

    for (;;) {
        while (!frame_ready);
        frame_ready = 0;
        cv_get_controller_state(&state, 0);
        color = CV_COLOR_BLUE;
        if (state.keypad <= 0x0b) color = CV_COLOR_MAGENTA;
        else if (state.joystick & (CV_FIRE_0 | CV_FIRE_1 | CV_FIRE_2 | CV_FIRE_3)) color = CV_COLOR_LIGHT_RED;
        else if (state.joystick & CV_UP) color = CV_COLOR_LIGHT_GREEN;
        else if (state.joystick & CV_DOWN) color = CV_COLOR_DARK_GREEN;
        else if (state.joystick & CV_LEFT) color = CV_COLOR_LIGHT_YELLOW;
        else if (state.joystick & CV_RIGHT) color = CV_COLOR_CYAN;
        cv_set_colors(CV_COLOR_LIGHT_BLUE, color);
    }
}
