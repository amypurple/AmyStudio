#include <coleco.h>
#include <getput1.h>

static const byte silent_sound[] = { 0xff };
const sound_t snd_table[] = { { silent_sound, SOUNDAREA1 } };

static const byte colors[6] = { 3,4,7,8,10,15 };
static byte x[6] = { 3,37,240,45,87,100 };
static byte y[6] = { 123,99,3,15,200,22 };
static byte direction[6] = { 0,1,3,2,0,1 };

void nmi(void) {}

void main(void)
{
    byte i, previous = 0;
    screen_mode_2_text();
    for (i = 0; i != 3; ++i) {
        unsigned address = 0x1800 + ((unsigned)i << 8);
        unsigned tile;
        for (tile = 0; tile != 256; ++tile) {
            byte value = tile;
            put_vram(address + tile, &value, 1);
        }
    }
    enable_nmi();
    screen_on();
    for (;;) {
        byte buttons;
        delay(1);
        buttons = (joypad_1 | joypad_2) & (FIRE1 | FIRE2);
        if (buttons && !previous) {
            for (i = 0; i != 6; ++i) direction[i] = (direction[i] + 1) & 3;
        } else if (!buttons) {
            for (i = 0; i != 6; ++i) {
                switch (direction[i]) {
                case 0: ++x[i]; if (++y[i] >= 192) y[i] -= 192; break;
                case 1: ++x[i]; if (--y[i] >= 192) y[i] += 192; break;
                case 2: --x[i]; if (--y[i] >= 192) y[i] += 192; break;
                default: --x[i]; if (++y[i] >= 192) y[i] -= 192; break;
                }
                pset(x[i], y[i], colors[i]);
            }
        }
        previous = buttons;
    }
}
