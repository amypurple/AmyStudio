# Four-picture Graphics II fidelity corpus

Cake and Commando are native Graphics II pictures. Warrior and Barbarian are previously converted ZX Spectrum pictures. Amy, CVBasic, and ugBASIC each render all four at 0 of 49,152 pixels different from the target. This corpus tests converter fidelity and image origin; the eight-tool suite uses Warrior for the common ROM-size row.
