#include <stdint.h>

#include "cv.h"
#include "cvu.h"
#include "cvu_compression.h"
#include "rle_escape.h"

#define PATTERN ((const cv_vmemp)0x0000)
#define IMAGE ((const cv_vmemp)0x1800)
#define COLOR ((const cv_vmemp)0x2000)

extern const uint8_t warrior_pattern[];
extern const uint8_t warrior_color[];
extern const uint8_t HUFFMAN_ROOT;
extern const uint8_t HUFFMAN_LS;
extern const uint8_t HUFFMAN_BS;
extern const uint8_t HUFFMAN_RS;
extern const struct cvu_huffman_node huffman_tree[255];

void main(void)
{
    struct cvu_compression_state state;
    uint16_t cell;

    cv_set_screen_active(false);
    cv_set_image_table(IMAGE);
    cv_set_color_table(0x3fff);
    cv_set_character_pattern_t(0x1fff);
    cv_set_screen_mode(CV_SCREENMODE_BITMAP);
    cvu_init_compression(warrior_pattern, &state, huffman_tree,
        HUFFMAN_ROOT, HUFFMAN_LS, HUFFMAN_BS, HUFFMAN_RS, RLE_ESCAPE);
    cvu_memtovmemcpy_compression(PATTERN, &state, 6144);
    cvu_init_compression(warrior_color, &state, huffman_tree,
        HUFFMAN_ROOT, HUFFMAN_LS, HUFFMAN_BS, HUFFMAN_RS, RLE_ESCAPE);
    cvu_memtovmemcpy_compression(COLOR, &state, 6144);
    for (cell = 0; cell != 768; ++cell)
        cvu_voutb((uint8_t)cell, IMAGE + cell);
    cv_set_screen_active(true);
    for (;;);
}
