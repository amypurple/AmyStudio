# ColecoVision five-tool evidence

Three equivalent samples built with Amy Studio, CVBasic, z88dk, ugBASIC, and devkitSMS/SGlib_CV. Each tool folder contains its source, required local assets, and a loadable ColecoVision ROM truncated to the measured occupied bytes.

- `hello-world`: visible text startup
- `bitmap-picture`: complete 256x192 Warrior Graphics II image
- `controller-visual`: visible controller-state monitor

All fifteen compact ROMs completed 180 NTSC frames in GearColeco while packaging. The five bitmap ROMs were separately verified to differ by 0 of 49,152 framebuffer pixels. `manifest.csv` records sizes and hashes; `SHA256SUMS.txt` allows file verification. Cartridge padding is intentionally excluded.
