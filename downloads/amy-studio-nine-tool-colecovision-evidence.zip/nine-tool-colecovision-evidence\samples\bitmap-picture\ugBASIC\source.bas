DEFINE SCREEN MODE UNIQUE OFF
BITMAP ENABLE(16)
warrior := LOAD IMAGE("warrior-ugbasic.bmp") EXACT
' ugBASIC 1.18.1 truncates CURRENTTILESWIDTHX8 and does not initialize the
' Graphics II Name Table on this full-screen PUT IMAGE path. Keep its native
' image converter, then transfer the converted Pattern/Color payload directly.
ON CPUZ80 BEGIN ASM
    LD HL, _warrior+3
    LD DE, $0000
    LD BC, $1800
    CALL VDPWRITE
    LD HL, _warrior+$1803
    LD DE, $2000
    LD BC, $1800
    CALL VDPWRITE
    CALL VDPLOCK
    LD DE, $3800
    CALL VDPWRITEADDR
    LD BC, (VDPDATAPORTWRITE)
    LD D, $03
    XOR A
WARRIOR_NAME_PAGE:
    LD E, $00
WARRIOR_NAME_BYTE:
    OUT (C), A
    INC A
    DEC E
    JR NZ, WARRIOR_NAME_BYTE
    DEC D
    JR NZ, WARRIOR_NAME_PAGE
    CALL VDPUNLOCK
END ASM
DO
  WAIT VBL
LOOP

