# BIOS-assisted pure Z80 ASM baseline

The pure-ASM fixtures use the same ColecoVision BIOS services, assets, codecs, and observable
behavior allowed to Amy Studio. Occupied size excludes cartridge padding. A result counts only
after its existing GearColeco oracle passes.

The source is hand-maintained assembly, not Amy-generated assembly. Amy output may be inspected to
understand the runtime contract, but copying generated routines would make the comparison circular.

## Current results

| Sample | Pure ASM | Amy Studio | ASM difference | Verification |
|---|---:|---:|---:|---|
| Hello World | 184 | 238 | -54 | exact Name Table text after BIOS startup |
| Warrior bitmap | 3,066 | 3,262 | -196 | exact 6,144-byte Pattern and Color tables |
| Controller Visual | 264 | 595 | -331 | neutral, keypad, held UP, FIRE, and releases |
| Sprite Metasprite | 343 | 983 | -640 | exact patterns, SAT layers, colors, priority, and frame |
| Tile Animation | 761 | 1,375 | -614 | exact three pattern thirds and six animated 3x2 Name Table frames |
| Gameplay State Update | 508 | 1,430 | -922 | world state 1, 13 collisions, score 425, checksum 1478 |
| **Six-sample total** | **5,126** | **7,883** | **-2,757** | all six GearColeco oracles pass |

Warrior uses the same two ZX0 payloads as Amy and the repository's direct-to-VRAM ZX0 decoder.
Therefore the 196-byte difference measures startup and integration code rather than a different
picture or compression advantage.

## Remaining matched fixtures

Gameplay State Update executes all 48 ticks over six mutable actor records; its test reads the live
RAM result rather than accepting precomputed constants. The Tile Animation ROM continues beyond
its first 64-tick cycle. Its test reads the live frame and
update counters, all three Graphics II pattern thirds, and every animated ship Name Table cell.

## Controller BIOS opportunity

The production BIOS exposes three distinct layers: raw `CONT_SCAN` at `$1F76`, immediate decoded
`DECODER` at `$1F79`, and debounced table-driven `POLLER` at `$1FEB`. The original 297-byte ASM
fixture used one `CONT_SCAN` plus cartridge decoding and a 16-byte keypad table. The measured
replacement uses two `DECODER` calls and stores only the final display color. It passes the same
neutral, keypad, direction, FIRE, and release oracle in 264 bytes, saving 33 bytes. `POLLER` remains
the deliberate choice when two-sample debounce is part of the required behavior, not a free size
optimization: it requires the 12-byte result contract and costs 83-91 BIOS instructions per call,
versus 29 for one `DECODER` segment.
