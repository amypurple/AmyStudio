#include "SGlib.h"
#include "SGlib_common.h"
#include "tile-animation-data.h"

static void draw_ships(unsigned char frame)
{
    unsigned char i;
    for (i = 0; i != 6; ++i) SG_loadTileMapArea(ship_x[i], ship_y[i], (void *)ship_frames[frame], 3, 2);
}

void main(void)
{
    unsigned char i, tick = 0, star = 0, ship = 0;
    SG_VRAMmemset(PNTADDRESS, 0x20, 768);
    for (i = 0; i != 3; ++i) {
        unsigned int base = ((unsigned int)i << 8);
        SG_loadTilePatterns((void *)star_patterns[0], base + 0x80, 8);
        SG_loadTilePatterns((void *)ship_patterns, base + 0x90, 96);
        SG_loadTileColours((void *)star_color, base + 0x80, 8);
        SG_loadTileColours((void *)ship_colors, base + 0x90, 96);
    }
    for (i = 0; i != 12; ++i) SG_setTileatXY(star_x[i], star_y[i], 0x80);
    draw_ships(0);
    SG_displayOn();
    for (;;) {
        SG_waitForVBlank();
        ++tick;
        if ((tick & 3) == 0) {
            unsigned char third;
            star = (star + 1) & 3;
            for (third = 0; third != 3; ++third)
                SG_loadTilePatterns((void *)star_patterns[star], ((unsigned int)third << 8) + 0x80, 8);
        }
        if ((tick & 7) == 0) { ship ^= 1; draw_ships(ship); }
    }
}
