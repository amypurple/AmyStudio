DEFINE DEFAULT TYPE BYTE

TYPE stateType
    x AS BYTE
    y AS BYTE
    direction AS BYTE
    timer AS BYTE
    mode AS BYTE
    hits AS BYTE
END TYPE

DIM units(6) AS stateType
DIM worldMode AS BYTE
DIM playerX AS BYTE
DIM playerY AS BYTE
DIM tick AS BYTE
DIM actorIndex AS BYTE
DIM collisionCount AS BYTE
DIM score AS WORD
DIM checksum AS WORD
DIM initialX AS BYTE
DIM initialY AS BYTE
DIM initialDirection AS BYTE
DIM actorX AS BYTE
DIM actorY AS BYTE
DIM actorDirection AS BYTE
DIM actorTimer AS BYTE
DIM actorMode AS BYTE
DIM actorHits AS BYTE

GLOBAL units, worldMode, playerX, playerY, tick, actorIndex, collisionCount, score, checksum, actorX, actorY, actorDirection, actorTimer, actorMode, actorHits

PROCEDURE updateActors
    FOR actorIndex = 0 TO 5
        actorX = units(actorIndex).x
        actorY = units(actorIndex).y
        actorDirection = units(actorIndex).direction
        actorTimer = units(actorIndex).timer
        actorMode = units(actorIndex).mode
        actorHits = units(actorIndex).hits

        IF actorMode = 0 THEN
            IF actorDirection = 0 THEN
                INC actorX
                IF actorX >= 208 THEN actorDirection = 1
            ELSE
                DEC actorX
                IF actorX <= 16 THEN actorDirection = 0
            ENDIF
        ELSEIF actorMode = 1 THEN
            IF actorX < playerX THEN
                ADD actorX, 2
            ELSEIF actorX > playerX THEN
                actorX = actorX - 2
            ENDIF
            IF actorY < playerY THEN INC actorY
            IF actorY > playerY THEN DEC actorY
        ELSEIF actorTimer = 0 THEN
            actorMode = 0
            actorTimer = 5 + actorIndex
        ENDIF

        IF actorTimer THEN DEC actorTimer
        IF actorTimer = 0 THEN
            IF actorMode = 0 THEN
                actorMode = 1
                actorTimer = 8
            ELSEIF actorMode = 1 THEN
                actorMode = 2
                actorTimer = 4
            ENDIF
        ENDIF

        IF actorMode <> 2 THEN
            IF playerX < actorX + 8 THEN
                IF actorX < playerX + 12 THEN
                    IF playerY < actorY + 8 THEN
                        IF actorY < playerY + 12 THEN
                            INC actorHits
                            INC collisionCount
                            ADD score, 25
                            actorMode = 2
                            actorTimer = 6
                        ENDIF
                    ENDIF
                ENDIF
            ENDIF
        ENDIF

        units(actorIndex).x = actorX
        units(actorIndex).y = actorY
        units(actorIndex).direction = actorDirection
        units(actorIndex).timer = actorTimer
        units(actorIndex).mode = actorMode
        units(actorIndex).hits = actorHits
    NEXT
    IF tick = 23 THEN worldMode = 2
END PROC

PROCEDURE updateBonus
    ADD score, 100
    ADD playerX, 4
    worldMode = 1
END PROC

worldMode = 1
playerX = 88
playerY = 80
collisionCount = 0
score = 0
checksum = 0
initialX = 24
initialY = 48
initialDirection = 0

FOR actorIndex = 0 TO 5
    units(actorIndex).x = initialX
    units(actorIndex).y = initialY
    units(actorIndex).direction = initialDirection
    units(actorIndex).timer = 3 + actorIndex
    units(actorIndex).mode = 0
    units(actorIndex).hits = 0
    ADD initialX, 24
    ADD initialY, 8
    initialDirection = initialDirection XOR 1
NEXT

FOR tick = 0 TO 47
    ON CPUZ80 BEGIN ASM
        PUSH AF
        LD A, $CA
        XOR $FE
        XOR $FE
        CP $CA
        POP AF
    END ASM
    IF worldMode = 1 THEN
        updateActors[]
    ELSE
        updateBonus[]
    ENDIF
    ON CPUZ80 BEGIN ASM
        PUSH AF
        LD A, $BE
        XOR $EF
        XOR $EF
        CP $BE
        POP AF
    END ASM
NEXT

FOR actorIndex = 0 TO 5
    ADD checksum, units(actorIndex).x
    ADD checksum, units(actorIndex).y
    ADD checksum, units(actorIndex).timer
    ADD checksum, units(actorIndex).mode
    ADD checksum, units(actorIndex).hits
NEXT
ADD checksum, score
ADD checksum, collisionCount

DO
LOOP
