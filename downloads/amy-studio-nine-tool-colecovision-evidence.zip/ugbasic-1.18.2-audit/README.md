# ugBASIC DEFINE BIOS ALLOWED audit

## Verdict

The directive is a legitimate ColecoVision size-optimization candidate and should
be measured for the six-sample comparison. Published values must not change until
the same compiler revision builds both variants and all runtime/display oracles
pass.

## Confirmed implementation

- Official commit: ugBASIC `main` `2db87eb`.
- Parser: `ugbc/src/ugbc.y` enables `vestigialConfig.biosAllowed`.
- Coleco/TMS9918 branches occur in startup, text, screen-mode, VDP and target
  variable code. The directive therefore changes linked implementation, not only
  syntax or metadata.
- The currently installed older executables reject the directive. They cannot be
  used to estimate its effect.

## Meaning of isomorphic

ugBASIC normally supplies a common BASIC vocabulary and its own target backends so
the same program has comparable behavior without depending on a machine ROM.
Allowing ColecoVision BIOS calls deliberately weakens that self-contained,
cross-target implementation model in exchange for reusing OS7 code already in the
console. This is conceptually similar to Amy Studio's explicit OS7 integration.

## Reproducible measurement

`tools/rebuild-ugbasic-six-samples.ps1 -BiosAllowed` now generates temporary
sources with the directive prepended and writes results to a separate build tree.
Run both portable and BIOS-enabled variants from one compiler identity. Compare
occupied `code_user` bytes, not padded 16K ROM length.

Required gates:

1. Hello output.
2. Pixel-exact bitmap framebuffer.
3. Injected controller states.
4. Exact metasprite patterns and placement.
5. State-update RAM/display result.
6. Tile-animation frames and timing.

Only a smaller fully passing BIOS-enabled set may replace the ranked ugBASIC row.
Keep both result sets in evidence because the portable mode remains meaningful.

## Build-environment status

The official source and submodules were obtained, but this Windows environment has
no native GNU make and the available WSL service did not start. This agrees with
the upstream warning that Makefile/build-environment handling can be the blocker.
No new size claim is made by this audit.

## 1.18.2 refresh (2026-11-22)

The official Windows ColecoVision compiler identifies itself as ugBASIC 1.18.2
(SHA-256 `ce56da01f989c1c336889808bd7b914e5c8357ee91146238223c9017008ab325`).
The same six published sources were rebuilt with the compiler's default 16
peephole passes, first in portable mode and then with `DEFINE BIOS ALLOWED`.
Occupied size is the generated `code_user` section, excluding 16K cartridge
padding.

| Sample | Ranked 2db87ebd | 1.18.2 portable | 1.18.2 BIOS allowed |
|---|---:|---:|---:|
| Hello World | 1,340 | 1,400 | 1,279 |
| Warrior bitmap | 7,580 | 9,380 | 9,262 |
| Controller Visual | 1,917 | 1,905 | 1,619 |
| Sprite Metasprite | 2,883 | 4,625 | 4,388 |
| Gameplay State Update | 3,931 | 3,796 | 3,681 |
| Tile Animation | 1,959 | 1,891 | 1,771 |
| **Total** | **19,610** | **22,997** | **22,000** |

The portable bitmap is pixel-exact and the portable metasprite passes movement,
bounds, animation, layer, color, and priority checks. The portable tile test
reached its validated final state; only optional PNG capture was unavailable in
this shell. The BIOS-assisted bitmap is pixel-exact, but the BIOS-assisted
metasprite missed its animation deadline and Tile Animation exposed mixed ship
frames. It is therefore ineligible regardless of size.

The upstream author separately reported an 18,966-byte total (779, 7,038,
1,146, 2,943, 5,511, and 1,549 bytes). Those values clearly use different source
formulations: notably, their State Update is 1,580 bytes larger than this
repository's 1.18.2 BIOS build while several graphical samples are much smaller.
Until those exact sources and runtime evidence are available, the upstream total
is recorded as a non-ranked claim rather than substituted into this behavior-
equivalent table. The validated 19,610-byte row remains the ranking.
