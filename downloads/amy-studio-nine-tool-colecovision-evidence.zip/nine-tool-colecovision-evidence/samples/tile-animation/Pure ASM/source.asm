; Pure Z80 ASM Graphics II shared-pattern and Name Table animation.
WRITE_VRAM equ $1fdf
WRITE_REGISTER equ $1fd9
READ_REGISTER equ $1fdc
TURN_OFF_SOUND equ $1fd6
VDP_CTRL equ $bf
VRAM_NAME equ $1800
TICK equ $7020
STAR_FRAME equ $7021
SHIP_FRAME equ $7022
PATTERN_UPDATES equ $7023
NAME_UPDATES equ $7024
FRAME_TEMP equ $7025
cpu Z80
org $8000
db $55,$aa
dw 0,0,$7000,0
dw Start
db $c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0
jp Nmi
Nmi:
 push af
 push bc
 push de
 push hl
 in a,(VDP_CTRL)
 ld a,(TICK)
 inc a
 ld (TICK),a
 and 3
 call z,AnimateStar
 ld a,(TICK)
 and 7
 call z,AnimateShips
 pop hl
 pop de
 pop bc
 pop af
 retn
Start:
 im 1
 call TURN_OFF_SOUND
 ld bc,$0002
 call WRITE_REGISTER
 ld bc,$0182
 call WRITE_REGISTER
 ld bc,$0206
 call WRITE_REGISTER
 ld bc,$03ff
 call WRITE_REGISTER
 ld bc,$0403
 call WRITE_REGISTER
 ld bc,$0536
 call WRITE_REGISTER
 ld bc,$0607
 call WRITE_REGISTER
 ld bc,$0701
 call WRITE_REGISTER
 xor a
 ld hl,TICK
 ld (hl),a
 ld de,TICK+1
 ld bc,4
 ldir
 call InstallGraphics
 call DrawStars
 xor a
 call DrawShips
 ld bc,$01e2
 call WRITE_REGISTER
 ei
Forever: jr Forever
InstallGraphics:
 ld hl,StarPatterns
 ld de,$0400
 ld bc,8
 call WRITE_VRAM
 ld hl,StarPatterns
 ld de,$0c00
 ld bc,8
 call WRITE_VRAM
 ld hl,StarPatterns
 ld de,$1400
 ld bc,8
 call WRITE_VRAM
 ld hl,StarColor
 ld de,$2400
 ld bc,8
 call WRITE_VRAM
 ld hl,StarColor
 ld de,$2c00
 ld bc,8
 call WRITE_VRAM
 ld hl,StarColor
 ld de,$3400
 ld bc,8
 call WRITE_VRAM
 ld hl,ShipPatterns
 ld de,$0480
 ld bc,96
 call WRITE_VRAM
 ld hl,ShipPatterns
 ld de,$0c80
 ld bc,96
 call WRITE_VRAM
 ld hl,ShipPatterns
 ld de,$1480
 ld bc,96
 call WRITE_VRAM
 ld hl,ShipColors
 ld de,$2480
 ld bc,96
 call WRITE_VRAM
 ld hl,ShipColors
 ld de,$2c80
 ld bc,96
 call WRITE_VRAM
 ld hl,ShipColors
 ld de,$3480
 ld bc,96
 jp WRITE_VRAM
AnimateStar:
 ld a,(STAR_FRAME)
 inc a
 and 3
 ld (STAR_FRAME),a
 add a,a
 add a,a
 add a,a
 ld e,a
 ld d,0
 ld hl,StarPatterns
 add hl,de
 push hl
 ld de,$0400
 ld bc,8
 call WRITE_VRAM
 pop hl
 push hl
 ld de,$0c00
 ld bc,8
 call WRITE_VRAM
 pop hl
 ld de,$1400
 ld bc,8
 call WRITE_VRAM
 ld hl,PATTERN_UPDATES
 inc (hl)
 ret
AnimateShips:
 ld a,(SHIP_FRAME)
 xor 1
 ld (SHIP_FRAME),a
 call DrawShips
 ld hl,NAME_UPDATES
 inc (hl)
 ret
DrawStars:
 ld hl,StarPositions
 ld b,12
StarLoop:
 ld e,(hl)
 inc hl
 ld d,(hl)
 inc hl
 push hl
 push bc
 call NameAddress
 ld hl,StarChar
 ld bc,1
 call WRITE_VRAM
 pop bc
 pop hl
 djnz StarLoop
 ret
DrawShips:
 ld (FRAME_TEMP),a
 ld hl,ShipPositions
 ld b,6
ShipLoop:
 ld e,(hl)
 inc hl
 ld d,(hl)
 inc hl
 push hl
 push bc
 call NameAddress
 ld a,(FRAME_TEMP)
 or a
 ld hl,ShipFrame0
 jr z,FrameReady
 ld hl,ShipFrame1
FrameReady:
 push de
 ld bc,3
 call WRITE_VRAM
 pop de
 ld hl,32
 add hl,de
 ex de,hl
 ld a,(FRAME_TEMP)
 or a
 ld hl,ShipFrame0+3
 jr z,FrameRow2
 ld hl,ShipFrame1+3
FrameRow2:
 ld bc,3
 call WRITE_VRAM
 pop bc
 pop hl
 djnz ShipLoop
 ret
NameAddress:
 ; D=row, E=column -> DE=$1800+row*32+column
 ld a,e
 ld l,d
 ld h,0
 add hl,hl
 add hl,hl
 add hl,hl
 add hl,hl
 add hl,hl
 ld e,a
 ld d,0
 add hl,de
 ld de,VRAM_NAME
 add hl,de
 ex de,hl
 ret
StarChar: db $80
ShipFrame0: db $90,$91,$92,$93,$94,$95
ShipFrame1: db $96,$97,$98,$99,$9a,$9b
StarPositions: db 2,4,9,5,22,4,29,7,1,10,12,11,18,9,27,12,5,17,24,18,3,21,28,20
ShipPositions: db 4,6,15,6,25,6,8,14,20,14,14,19
StarPatterns:
 incbin "star-patterns.bin"
StarColor:
 incbin "star-color.bin"
ShipPatterns:
 incbin "ship-patterns.bin"
ShipColors:
 incbin "ship-colors.bin"
