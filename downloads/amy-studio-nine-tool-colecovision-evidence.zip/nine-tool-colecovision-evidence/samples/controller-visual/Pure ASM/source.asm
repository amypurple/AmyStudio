; Pure Z80 ASM controller visual benchmark, BIOS-assisted.
MODE_1 equ $1f85
LOAD_ASCII equ $1f7f
FILL_VRAM equ $1f82
WRITE_VRAM equ $1fdf
WRITE_REGISTER equ $1fd9
READ_REGISTER equ $1fdc
TURN_OFF_SOUND equ $1fd6
DECODE_CONTROLLER equ $1f79
VRAM_NAME equ $1800
VRAM_COLOR equ $2000
VDP_CTRL equ $bf
COLOR equ $7024
VBLANK equ $7025

cpu Z80
org $8000
db $55,$aa
dw 0,0,$7000,0
dw Start
db $c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0
jp Nmi

Nmi:
    push af
    push bc
    push de
    push hl
    in a,(VDP_CTRL)
    ; DECODER returns an already decoded direction/keypad value. Calling it
    ; twice is smaller than retaining a cartridge-side keypad lookup table.
    xor a
    out ($c0),a
    ld h,a
    ld l,a
    call DECODE_CONTROLLER
    ld a,h
    rlca
    or l
    push af
    ld h,0
    ld l,1
    call DECODE_CONTROLLER
    ld b,h
    ld c,l
    pop af
    ld d,a
    ld a,c
    cp $0f
    ld a,13
    jr nz,StoreColor
    ld a,b
    or a
    ld a,9
    jr nz,StoreColor
    ld a,d
    bit 7,a
    ld a,9
    jr nz,StoreColor
    bit 0,d
    ld a,3
    jr nz,StoreColor
    bit 2,d
    ld a,12
    jr nz,StoreColor
    bit 3,d
    ld a,11
    jr nz,StoreColor
    bit 1,d
    ld a,7
    jr nz,StoreColor
    ld a,4
StoreColor:
    ld (COLOR),a
    ld a,1
    ld (VBLANK),a
    pop hl
    pop de
    pop bc
    pop af
    retn

Start:
    im 1
    call TURN_OFF_SOUND
    call MODE_1
    call LOAD_ASCII
    ld hl,VRAM_COLOR
    ld de,32
    ld a,$f0
    call FILL_VRAM
    ld de,VRAM_NAME+8*32+9
    ld hl,Title
    ld bc,15
    call WRITE_VRAM
    ld de,VRAM_NAME+11*32+5
    ld hl,Prompt
    ld bc,22
    call WRITE_VRAM
    ld de,VRAM_NAME+14*32+8
    ld hl,KeyText
    ld bc,16
    call WRITE_VRAM
    ld bc,$01e2
    call WRITE_REGISTER
    ei
Loop:
    xor a
    ld (VBLANK),a
WaitFrame:
    ld a,(VBLANK)
    or a
    jr z,WaitFrame
    ld a,(COLOR)
    ld c,a
    ld b,7
    call WRITE_REGISTER
    jr Loop

Title: db "CONTROLLER TEST"
Prompt: db "MOVE OR PRESS A BUTTON"
KeyText: db "KEYPAD IS PURPLE"
