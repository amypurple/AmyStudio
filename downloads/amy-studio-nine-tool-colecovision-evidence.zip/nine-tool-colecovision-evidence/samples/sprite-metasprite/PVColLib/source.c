#include <coleco.h>
#include "sprite-patterns.h"

static u8 sat[13] = {
    88, 120, 0, 15,
    88, 120, 4, 11,
    88, 120, 8, 1,
    0xd0
};

void nmi(void)
{
}

void main(void)
{
    u8 x = 120, y = 88, tick = 0, anim = 0;
    vdp_disablescr();
    vdp_setmode2txt();
    spr_mode16x16();
    vdp_putvram(sprtab, sprite_patterns, sizeof(sprite_patterns));
    vdp_putvram(sprgen, sat, sizeof(sat));
    vdp_enablescr();
    vdp_enablenmi();

    for (;;) {
        vdp_waitvblank(1);
        if ((joypad_1 & PAD_LEFT) && x > 1) --x;
        if ((joypad_1 & PAD_RIGHT) && x < 239) ++x;
        if ((joypad_1 & PAD_UP) && y > 1) --y;
        if ((joypad_1 & PAD_DOWN) && y < 175) ++y;
        if (++tick == 8) { tick = 0; anim = anim ? 0 : 12; }
        sat[0] = sat[4] = sat[8] = y;
        sat[1] = sat[5] = sat[9] = x;
        sat[2] = anim;
        sat[3] = 15;
        sat[6] = anim + 4;
        sat[7] = 11;
        sat[10] = anim + 8;
        sat[11] = 1;
        sat[12] = 0xd0;
        vdp_putvram(sprgen, sat, sizeof(sat));
    }
}
