; Pure Z80 ASM animated three-layer metasprite.
MODE_1 equ $1f85
WRITE_VRAM equ $1fdf
WRITE_REGISTER equ $1fd9
READ_REGISTER equ $1fdc
TURN_OFF_SOUND equ $1fd6
VDP_CTRL equ $bf
VRAM_SAT equ $1b00
VRAM_SPRITES equ $3800
TICK equ $7020
FRAME equ $7021
cpu Z80
org $8000
db $55,$aa
dw 0,0,$7000,0
dw Start
db $c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0
jp Nmi
Nmi:
 push af
 in a,(VDP_CTRL)
 ld a,(TICK)
 inc a
 and 7
 ld (TICK),a
 jr nz,NmiDone
 ld a,(FRAME)
 xor 1
 ld (FRAME),a
 call DrawSprite
NmiDone:
 pop af
 retn
Start:
 im 1
 call TURN_OFF_SOUND
 call MODE_1
 ld hl,Patterns
 ld de,VRAM_SPRITES
 ld bc,192
 call WRITE_VRAM
 xor a
 ld (TICK),a
 ld (FRAME),a
 call DrawSprite
 ld bc,$01e2
 call WRITE_REGISTER
 ei
Forever: jr Forever
DrawSprite:
 ld a,(FRAME)
 or a
 ld a,0
 jr z,HavePattern
 ld a,12
HavePattern:
 ld (SatPatterns),a
 add a,4
 ld (SatPatterns+4),a
 add a,4
 ld (SatPatterns+8),a
 ld hl,Sat
 ld de,VRAM_SAT
 ld bc,13
 jp WRITE_VRAM
Sat:
 db 88,120
SatPatterns: db 0,15
 db 88,120,4,11
 db 88,120,8,1
 db $d0
Patterns:
 incbin "sprite-patterns.bin"
