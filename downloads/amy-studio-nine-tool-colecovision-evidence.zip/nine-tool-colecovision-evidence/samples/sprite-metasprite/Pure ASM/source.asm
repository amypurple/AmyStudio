; Pure Z80 ASM animated three-layer metasprite.
MODE_1 equ $1f85
WRITE_VRAM equ $1fdf
WRITE_REGISTER equ $1fd9
READ_REGISTER equ $1fdc
TURN_OFF_SOUND equ $1fd6
UPDATE_CONTROLLERS equ $1f76
VDP_CTRL equ $bf
VRAM_SAT equ $1b00
VRAM_SPRITES equ $3800
TICK equ $7200
FRAME equ $7201
PLAYER_X equ $7202
PLAYER_Y equ $7203
FRAME_READY equ $7204
SAT_BUFFER equ $7205
BIOS_JOYPAD_1 equ $73ee
cpu Z80
org $8000
db $55,$aa
dw 0,0,$7000,0
dw Start
db $c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0
jp Nmi
Nmi:
 push af
 in a,(VDP_CTRL)
 ld a,1
 ld (FRAME_READY),a
 pop af
 retn
Start:
 im 1
 call TURN_OFF_SOUND
 call MODE_1
 ld hl,Patterns
 ld de,VRAM_SPRITES
 ld bc,192
 call WRITE_VRAM
 xor a
 ld (TICK),a
 ld (FRAME),a
 ld (FRAME_READY),a
 ld a,120
 ld (PLAYER_X),a
 ld a,88
 ld (PLAYER_Y),a
 ld hl,SatTemplate
 ld de,SAT_BUFFER
 ld bc,13
 ldir
 call DrawSprite
 ld bc,$01e2
 call WRITE_REGISTER
 ei
MainLoop:
 halt
 ld a,(FRAME_READY)
 or a
 jr z,MainLoop
 xor a
 ld (FRAME_READY),a
 call UPDATE_CONTROLLERS
 ld a,(BIOS_JOYPAD_1)
 bit 3,a
 jr z,NotLeft
 ld a,(PLAYER_X)
 cp 2
 jr c,NotLeft
 dec a
 ld (PLAYER_X),a
NotLeft:
 ld a,(BIOS_JOYPAD_1)
 bit 1,a
 jr z,NotRight
 ld a,(PLAYER_X)
 cp 239
 jr nc,NotRight
 inc a
 ld (PLAYER_X),a
NotRight:
 ld a,(BIOS_JOYPAD_1)
 bit 0,a
 jr z,NotUp
 ld a,(PLAYER_Y)
 cp 2
 jr c,NotUp
 dec a
 ld (PLAYER_Y),a
NotUp:
 ld a,(BIOS_JOYPAD_1)
 bit 2,a
 jr z,NotDown
 ld a,(PLAYER_Y)
 cp 175
 jr nc,NotDown
 inc a
 ld (PLAYER_Y),a
NotDown:
 ld a,(TICK)
 inc a
 and 7
 ld (TICK),a
 jr nz,DrawCurrent
 ld a,(FRAME)
 xor 1
 ld (FRAME),a
DrawCurrent:
 call DrawSprite
 jr MainLoop
DrawSprite:
 ld a,(FRAME)
 or a
 ld a,0
 jr z,HavePattern
 ld a,12
HavePattern:
 ld (SAT_BUFFER+2),a
 add a,4
 ld (SAT_BUFFER+6),a
 add a,4
 ld (SAT_BUFFER+10),a
 ld a,(PLAYER_Y)
 ld (SAT_BUFFER),a
 ld (SAT_BUFFER+4),a
 ld (SAT_BUFFER+8),a
 ld a,(PLAYER_X)
 ld (SAT_BUFFER+1),a
 ld (SAT_BUFFER+5),a
 ld (SAT_BUFFER+9),a
 ld hl,SAT_BUFFER
 ld de,VRAM_SAT
 ld bc,13
 jp WRITE_VRAM
SatTemplate:
 db 88,120
 db 0,15
 db 88,120,4,11
 db 88,120,8,1
 db $d0
Patterns:
 incbin "sprite-patterns.bin"
