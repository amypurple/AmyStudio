DEFINE DEFAULT TYPE BYTE

DEFINE SCREEN MODE UNIQUE OFF
BITMAP ENABLE (16)

frame0Image := LOAD IMAGE("ugbasic-frame0.png")
frame1Image := LOAD IMAGE("ugbasic-frame1.png")

frame0 = CSPRITE(frame0Image)
frame1 = CSPRITE(frame1Image)

VAR spriteX AS BYTE = 120
VAR spriteY AS BYTE = 88
VAR tick AS BYTE = 0
VAR anim AS BYTE = 0
VAR lastTick AS WORD = 0

SPRITE frame0 AT spriteX,spriteY ENABLE

lastTick = TIMER
DO
    WHILE TIMER = lastTick
    WEND
    lastTick = TIMER
    IF JLEFT(0) THEN
        IF spriteX > 1 THEN : DEC spriteX : ENDIF
    ENDIF
    IF JRIGHT(0) THEN
        IF spriteX < 239 THEN : INC spriteX : ENDIF
    ENDIF
    IF JUP(0) THEN
        IF spriteY > 1 THEN : DEC spriteY : ENDIF
    ENDIF
    IF JDOWN(0) THEN
        IF spriteY < 175 THEN : INC spriteY : ENDIF
    ENDIF
    INC tick
    IF tick = 8 THEN
        tick = 0
        IF anim = 0 THEN
            anim = 1
            SPRITE frame0 DISABLE
            SPRITE frame1 AT spriteX,spriteY ENABLE
        ELSE
            anim = 0
            SPRITE frame1 DISABLE
            SPRITE frame0 AT spriteX,spriteY ENABLE
        ENDIF
    ELSE
        IF anim = 0 THEN
            SPRITE frame0 AT spriteX,spriteY
        ELSE
            SPRITE frame1 AT spriteX,spriteY
        ENDIF
    ENDIF
LOOP
