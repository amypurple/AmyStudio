#include <games.h>
#include <intrinsic.h>
#include <video/tms99x8.h>
#include "sprite-patterns.h"

static unsigned char sat[16] = {
    0, 0, 0, VDP_INK_WHITE,
    0, 0, 4, VDP_INK_LIGHT_YELLOW,
    0, 0, 8, VDP_INK_BLACK,
    0xd0, 0, 0, 0
};

int main(void)
{
    unsigned char x = 120, y = 88, tick = 0, anim = 0;
    unsigned int input;

    vdp_set_sprite_mode(sprite_large);
    vdp_vwrite_direct((void *)sprite_patterns, 0x3800, sizeof(sprite_patterns));

    for (;;) {
        intrinsic_halt();
        input = joystick(3);
        if ((input & MOVE_LEFT) && x > 1) --x;
        if ((input & MOVE_RIGHT) && x < 239) ++x;
        if ((input & MOVE_UP) && y > 1) --y;
        if ((input & MOVE_DOWN) && y < 175) ++y;
        if (++tick == 8) { tick = 0; anim ^= 12; }
        sat[0] = sat[4] = sat[8] = y - 1;
        sat[1] = sat[5] = sat[9] = x;
        sat[2] = anim;
        sat[6] = anim + 4;
        sat[10] = anim + 8;
        vdp_vwrite_direct(sat, 0x1b00, sizeof(sat));
    }
}
