#include <conio.h>

int main(void)
{
    cputs("\x0c\n\n\n\n\n\n\n\n\n\n\n  HELLO, WORLD!");
    for (;;) {}
}
