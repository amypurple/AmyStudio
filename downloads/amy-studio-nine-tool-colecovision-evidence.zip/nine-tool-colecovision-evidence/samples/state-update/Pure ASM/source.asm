; Pure Z80 ASM deterministic six-actor state update.
READ_REGISTER equ $1fdc
VDP_CTRL equ $bf
ACTORS equ $7030
WORLD_MODE equ $7020
PLAYER_X equ $7021
TICK equ $7022
COLLISIONS equ $7023
SCORE equ $7024
CHECKSUM equ $7026
cpu Z80
org $8000
db $55,$aa
dw 0,0,$7000,0
dw Start
db $c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0
jp Nmi
Nmi: in a,(VDP_CTRL)
 retn
Start:
 im 1
 ld a,1
 ld (WORLD_MODE),a
 ld a,88
 ld (PLAYER_X),a
 xor a
 ld (TICK),a
 ld (COLLISIONS),a
 ld (SCORE),a
 ld (SCORE+1),a
 call InitActors
MainTick:
 ld a,(WORLD_MODE)
 cp 2
 jr nz,RunActors
 call UpdateBonus
 jr TickDone
RunActors:
 call UpdateActors
TickDone:
 ld a,(TICK)
 inc a
 ld (TICK),a
 cp 48
 jr nz,MainTick
 call MakeChecksum
Forever: jr Forever
InitActors:
 ld ix,ACTORS
 ld b,6
 ld c,0
InitLoop:
 ld a,c
 add a,a
 add a,a
 add a,a
 ld d,a
 add a,a
 add a,d
 add a,24
 ld (ix+0),a
 ld a,c
 add a,a
 add a,a
 add a,a
 add a,48
 ld (ix+1),a
 ld a,c
 and 1
 ld (ix+2),a
 ld a,c
 add a,3
 ld (ix+3),a
 xor a
 ld (ix+4),a
 ld (ix+5),a
 ld de,6
 add ix,de
 inc c
 djnz InitLoop
 ret
UpdateBonus:
 ld hl,(SCORE)
 ld de,100
 add hl,de
 ld (SCORE),hl
 ld a,(PLAYER_X)
 add a,4
 ld (PLAYER_X),a
 ld a,1
 ld (WORLD_MODE),a
 ret
UpdateActors:
 ld ix,ACTORS
 ld b,6
 ld c,0
ActorLoop:
 push bc
 ld a,(ix+4)
 or a
 jr nz,NotPatrol
 ld a,(ix+2)
 or a
 jr nz,PatrolLeft
 inc (ix+0)
 ld a,(ix+0)
 cp 208
 jr c,AfterMove
 ld (ix+2),1
 jr AfterMove
PatrolLeft:
 dec (ix+0)
 ld a,(ix+0)
 cp 17
 jr nc,AfterMove
 ld (ix+2),0
 jr AfterMove
NotPatrol:
 cp 1
 jr nz,Cooldown
 ld a,(ix+0)
 ld d,a
 ld a,(PLAYER_X)
 cp d
 jr z,ChaseY
 jr c,ChaseLeft
 inc (ix+0)
 inc (ix+0)
 jr ChaseY
ChaseLeft:
 dec (ix+0)
 dec (ix+0)
ChaseY:
 ld a,(ix+1)
 cp 80
 jr z,AfterMove
 jr nc,ChaseUp
 inc (ix+1)
 jr AfterMove
ChaseUp: dec (ix+1)
 jr AfterMove
Cooldown:
 ld a,(ix+3)
 or a
 jr nz,AfterMove
 xor a
 ld (ix+4),a
 ld a,c
 add a,5
 ld (ix+3),a
AfterMove:
 ld a,(ix+3)
 or a
 jr z,TimerExpired
 dec (ix+3)
TimerExpired:
 ld a,(ix+3)
 or a
 jr nz,TryCollision
 ld a,(ix+4)
 or a
 jr nz,MaybeChaseEnd
 ld (ix+4),1
 ld (ix+3),8
 jr TryCollision
MaybeChaseEnd:
 cp 1
 jr nz,TryCollision
 ld (ix+4),2
 ld (ix+3),4
TryCollision:
 ld a,(ix+4)
 cp 2
 jr z,ActorDone
 call Collides
 jr nc,ActorDone
 inc (ix+5)
 ld hl,COLLISIONS
 inc (hl)
 ld hl,(SCORE)
 ld de,25
 add hl,de
 ld (SCORE),hl
 ld (ix+4),2
 ld (ix+3),6
ActorDone:
 ld de,6
 add ix,de
 pop bc
 inc c
 dec b
 jp nz,ActorLoop
 ld a,(TICK)
 cp 23
 ret nz
 ld a,2
 ld (WORLD_MODE),a
 ret
Collides:
 ld a,(ix+0)
 add a,8
 ld d,a
 ld a,(PLAYER_X)
 cp d
 ret nc
 ld a,(PLAYER_X)
 add a,12
 ld d,a
 ld a,(ix+0)
 cp d
 ret nc
 ld a,(ix+1)
 add a,8
 cp 81
 jr c,NoCollision
 ld a,(ix+1)
 cp 92
 ret nc
 scf
 ret
NoCollision:
 or a
 ret
MakeChecksum:
 ld ix,ACTORS
 ld b,6
 ld hl,0
SumActor:
 ld a,(ix+0)
 call AddA
 ld a,(ix+1)
 call AddA
 ld a,(ix+3)
 call AddA
 ld a,(ix+4)
 call AddA
 ld a,(ix+5)
 call AddA
 ld de,6
 add ix,de
 djnz SumActor
 ld de,(SCORE)
 add hl,de
 ld a,(COLLISIONS)
 call AddA
 ld (CHECKSUM),hl
 ret
AddA:
 ld e,a
 ld d,0
 add hl,de
 ret
