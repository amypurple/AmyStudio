; Pure Z80 ASM Warrior benchmark. BIOS-assisted, matching Amy's ZX0 path.
MODE_1          equ $1f85
TURN_OFF_SOUND  equ $1fd6
WRITE_REGISTER  equ $1fd9
READ_REGISTER   equ $1fdc
VRAM_PATTERN    equ $0000
VRAM_NAME       equ $1800
VRAM_COLOR      equ $2000
VDP_DATA_PORT   equ $be
VDP_CTRL_PORT   equ $bf

cpu Z80
org $8000
db $55,$aa
dw 0,0,0,0
dw Start
db $c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0,$c9,0,0
jp Nmi

Nmi:
    call READ_REGISTER
    retn

Start:
    im 1
    call TURN_OFF_SOUND
    call MODE_1
    ld hl,WarriorPattern
    ld de,VRAM_PATTERN
    call zx0_decompress
    ld hl,WarriorColor
    ld de,VRAM_COLOR
    call zx0_decompress
    ld bc,$01e2
    call WRITE_REGISTER
Forever:
    jp Forever

include "zx0_vram.asm"

WarriorPattern:
    incbin "warrior.pattern.zx0"
WarriorColor:
    incbin "warrior.color.zx0"
