# ZOMBIE BOTTE POULET — r5.3 : le poulet garde ses couleurs (clignotement des sprites)

**r5.3** (demande d'Amy) : quand le poulet partage des lignes avec le zombie, il **garde sa crête, ses pattes rouges et ses yeux**. Il ne perd plus ses couleurs : quand une ligne a plus de 4 sprites, les sprites du poulet **passent à tour de rôle**. Le zombie, lui, ne clignote jamais.

Le reste ne change pas : MegaCart de 64 Ko, aucun changement de banque pendant le jeu, œufs et secrets, presque réussi et pleine puissance. Toutes les vérifications de la section 7 ont été refaites sur la ROM r5.3.

Jeu original pour ColecoVision, écrit en Amy (Amy Studio r12.11, profil `balanced` du début à la fin). Amy & Claude 2026.

Tout le menu est jouable : acte I (Halloween), acte II (l'hiver), acte III (l'été), mode ninja. Plus trois œufs de Pâques, trois coups secrets, un écran des secrets.

## 00. Nouveautés de la r5.3

### Ce qu'on voit
- **Avant (r5.2)** : sur les lignes du zombie, le poulet perdait d'abord ses yeux, puis sa crête et ses pattes. Sur les 36 parties de la r5.2, les yeux n'étaient montrés que dans environ 1 image de jeu sur 9 où le poulet était visible.
- **Maintenant** : la crête et les pattes sont toujours là. Les yeux le sont environ une image sur deux (voir plus bas pourquoi pas toujours). Quand une ligne a plus de 4 sprites, l'ordre des sprites du poulet est inversé à chaque image : ce qui manque à une image est là à la suivante (clignotement à 30 Hz, le compromis approuvé).
- **Le zombie ne clignote jamais** : ses 6 sprites (4 couleurs, 2 contours) sont toujours les premiers de la table.
- Conséquence voulue de « le zombie d'abord » : là où les deux se chevauchent, **le poulet passe derrière le zombie** (avant, il passait devant). C'est logique pour un coup de pied (la botte devant le poulet), mais c'est un changement visible.
- Captures : `screenshots/flicker/` :
  - `r52-before.png` : r5.2, le poulet contre le zombie, sans ses yeux ;
  - `r53-rotation-a.png` puis `r53-rotation-b.png` : r5.3, deux images de suite au même endroit. En **a**, la crête et le bec rouges sont là, les yeux manquent ; en **b**, les yeux bleus sont là et une partie du rouge manque ;
  - `flicker-zoom-6x.png` : les trois côte à côte, agrandis 6 fois.
  
  Les trois sont au niveau 1 de l'acte I, graine 1 : le même moment de la même partie.

### Comment
- **Les numéros de sprites** : 0-5 le zombie (haut gauche, haut droit, contour du haut, bas gauche, bas droit, contour du bas), 6-10 le poulet et le reste (yeux, corps blanc, rouge, ombre, étoiles).
- **Le dessin du poulet** : le corps blanc a maintenant des trous sous les pupilles. Les trois couches ne se recouvrent plus, donc l'ordre des sprites ne change pas le dessin. Petit effet : dans une image où les yeux sont coupés, on voit le fond par les trous (2 × 2 pixels, du vert sur la pelouse de l'acte I).
- **L'ordre qui tourne** : 6-10 dans un sens, puis 10-6 dans l'autre, une image sur deux. Avec cet aller-retour, chaque sprite se voit au moins une image sur deux, à une condition : sur chacune de ses lignes, le nombre de sprites qui tournent ne dépasse pas 2 fois les places libres (4 moins les sprites du zombie).
- **Le budget par ligne** garde cette condition : « 2 × zombie + sprites qui tournent ≤ 8 », compté comme avant de la façon prudente (un sprite compte avec tout ce dont les 16 lignes touchent les siennes). Ordre de priorité : le corps blanc toujours, puis le rouge, les yeux, l'ombre, les étoiles.
  - Avec 2 sprites du zombie sur la ligne, le poulet a ses 3 couches.
  - Avec 3 (une moitié du zombie qui montre son contour, sur la clôture ou un objet), il ne reste qu'une place libre : au plus 2 sprites qui tournent. Le poulet y montre son blanc et son rouge à tour de rôle, sans les yeux. Trois sprites pour une place, ça ferait 1 image sur 3 : interdit par la règle.
- **Quand l'ordre tourne** : il s'inverse à chaque image où un sprite du poulet (ou l'ombre, ou les étoiles) est sur les lignes du zombie. Plus de 4 sprites sur une ligne n'arrive que dans ce cas. Le drapeau du 5e sprite du VDP (lu par l'interruption) le fait aussi tourner.
  - Pourquoi pas le drapeau seul : il arrive une image trop tard. Le premier sprite coupé le restait donc **2 images de suite** au début de chaque chevauchement. Le bot l'a mesuré (voir bogue 7).
- **Pendant un œuf** (3,2 s, tout est arrêté), le poulet figé continue à passer à tour de rôle : `Frame1` appelle `eg_turn` quand `Phase` = 5. Sans ça, une partie (acte III, graine 2, œuf trouvé par hasard) gardait le corps et les yeux coupés 200 images de suite.
- **Mode ninja** : rien ne change. Le poulet caché a tous ses sprites à Y = 209.

### Pourquoi pas le clignotement intégré d'Amy
Je l'ai d'abord essayé tel quel (`sprites stable 0 to 5`, `sprites flicker on`). Le zombie ne clignotait jamais, mais la rotation n'est pas juste : sur l'acte I, graine 1, le rouge du poulet était coupé **60 % des images, jusqu'à 5 images de suite**, et les yeux 3 de suite. Ça ne respecte pas « jamais invisible plus d'une image sur deux ». Détails et correctif proposé : bogue 6. Le jeu garde donc `update sprites` d'Amy en ordre normal (`sprites flicker off`) et place lui-même les sprites du poulet dans un sens ou dans l'autre (même principe : le stable d'abord, le reste tourne).

### La place
- **Attention, le chiffre de la r5.2 était trompeur** : « 175 octets libres » est vrai pour la fin du programme, mais le code placé **avant** la table `RevTab` (alignée sur 256 octets) n'avait que les ~15 octets du trou d'alignement. Un octet de plus fait sauter la table à la page suivante : 256 octets de plus, et la compilation échoue (« 32785 / 32768 bytes »). Je l'ai mesuré avec des `nop` : 15 passent, 16 échouent.
- Ce que j'ai fait :
  - le nouveau budget est plus simple que l'ancien code qui enlevait les couleurs, et les « sinon cacher » ont disparu (un seul `set sprite` par sprite, à Y = 209 s'il est caché). Le code avant `RevTab` a donc **diminué** d'environ 13 octets, malgré la rotation ;
  - `eg_turn` (le tour de rôle pendant les œufs, 26 octets) est placé après les images du zombie, donc après `RevTab`, dans la place libre de la fin ;
  - le sens de l'ordre (0 ou 12) est rangé dans `AMY_SPRITE_FLICKER_PHASE`, l'octet d'Amy pour son propre clignotement. Il est libre, puisque celui-ci est éteint, et `sprites flicker off` le remet à 0. Pas d'octet de RAM en plus.
- Résultat : programme de **32 559 octets** sur 32 704 (145 libres à la fin). RAM : 612 sur 675, 64 octets de marge de pile, comme avant. Les garde-fous de `build.py` passent. Toujours aucun changement de banque pendant le jeu.

### Le bot et les vérifications
- La règle « jamais plus de 4 par ligne » est remplacée (`tests/bot.mjs`, table des sprites lue en VRAM à chaque image de jeu et d'œuf). Pour chaque sprite, reconnu par son motif (zombie, blanc, rouge, yeux, ombre, étoiles) :
  - il est **coupé** sur une de ses lignes quand 4 sprites avant lui dans la table l'occupent déjà ;
  - **zombie coupé** : doit rester 0 ;
  - **pire taux de coupe** : la part des images où le sprite est coupé sur au moins une ligne, au plus 50 % ;
  - **pire suite** : le plus grand nombre d'images de suite où la même rangée du sprite est coupée, au plus 1.
  
  Le rapport du bot a `sprites.vis.ok` = vrai quand les trois tiennent. `--debug` ajoute les cas de 2 coupes de suite (`consecLog`).
- `tests/shotpair.mjs` fait les captures de la r5.3 (le bot, plus `--mode old|new`).
- Le flash ≤ 3 Hz ne concerne que les effets voulus (lanternes, arrosage, gouttes). Aucun n'a changé. Le clignotement à 30 Hz est le compromis approuvé.

## 0. Nouveautés de la r5.2 (rappel)

### Le coup presque réussi
- Quand le poulet retombe sans entrer dans un panier (à plus de 10 × 9 px de son milieu), mais **à moins de 20 px en largeur et 16 px en hauteur** d'un panier vide, il fait un **petit saut de 16 images** (environ 5 px de haut, avec son ombre) jusque dans le panier, avec un gloussement.
- Pourquoi ce rayon : c'est environ le double de la zone du panier. Un coup qui touche le bord du panier est récompensé, mais pas un coup franchement à côté.
- Les points sont ceux d'un panier normal : 10, 20 ou 30 selon la longueur du coup. Il n'y a pas de tournis en plus.
- Ça ne s'applique pas au saut de sortie d'un panier : le poulet ne retombe donc jamais dans le panier qu'il vient de quitter.

### Le coup à pleine puissance
- **La fenêtre** : une charge de 42 à 47, soit **les 6 dernières images (0,1 s)** avant la perte d'équilibre (48). Le risque est réel : 2 images de trop et le zombie titube, avec 2 points de tournis.
- **Le rebond** : un coup à pleine puissance qui touche le poulet l'envoie faire **4 petits bonds** très vite (30 à 45/16 px par image) dans toute la cour. Il ricoche sans perdre de vitesse :
  - sur la clôture et les bords de la pelouse ;
  - sur les obstacles : tombes, bonhommes de neige, luges, flamants.
  
  Chaque ricochet fait « bonk », chaque bond glousse. La direction est au hasard, avec haut/bas si on les tient.
- Puis il fait **un dernier saut de 32 images** (environ 17 px de haut) jusqu'au **panier vide le plus proche**. Durée totale : environ 2 s.
- **30 points en tout**, toujours (le point du coup compris). Les coups secrets restent possibles, sauf le ricochet sur une tombe de l'acte I, qui ne compte que pour un coup normal.
- **Mode ninja** : le poulet reste visible pendant tout le rebond, et encore 1 s après.
- Sprites : ce sont les sprites habituels du poulet en vol. Aucun sprite de plus. (r5.3 : avec le budget et la rotation de la section 00.)

### L'aide, page 1
Une ligne de texte sur deux : chaque ligne a une rangée libre au-dessus (pour l'accent des capitales pleine hauteur) et en dessous (pour la cédille du Ç). Nouvelle ligne : « COUP À FOND : SURPRISE ! ». Colonnes 2 à 29, lignes 1 à 22. Capture `05-help1`.

### Technique
- La place manquait : il restait 431 octets dans le programme de 32 Ko. Le nouveau code est écrit en asm dans `tiles.asm` (`pw_*`).
- `Fly` et la recherche du panier dans `Land` sont passés aussi en asm, avec la même physique. Le simulateur du bot (`flight()`), qui reproduit cette physique, vise toujours aussi juste.
- Place : programme de 32 529 octets sur 32 704. RAM : 612 sur 675, et 64 octets de marge de pile, la valeur recommandée. C'est pourquoi `pw_step` répond dans `D8` et garde le meilleur panier dans `HRes` : ce sont deux variables de travail existantes, utilisées à un autre moment.
- Le plan de la ROM et les garde-fous de `build.py` ne changent pas.
- Bot : `--feat` vise d'abord des coups presque réussis, puis des coups à pleine puissance (charge 43). Ensuite il joue normalement.
- Le bot sait aussi se dégager quand il hésite sur place devant une luge. La graine 1 de l'acte II le bloquait : le zombie restait immobile alors que le poulet circulait librement. C'était un problème du bot, pas du jeu.

## 1. La MegaCart (64 Ko en r5.1)

### Vérification d'Amy Studio r12.11 d'abord

- Projet MegaCart modèle d'Amy Studio (`project.amy.json`, banque fixe Amy, banque asm, banque Amy) : il se construit avec `amyc.mjs` (128 Ko, 8 banques), **mais seulement après avoir retiré la ligne `decompress mdkrle ... from bank 2`** du modèle (bogue 2 plus bas).
- Le banc de test (cœur GearColeco) charge cette ROM et la reconnaît comme MegaCart (`getCartridgeType() = 1`). Le texte copié de la banque 2 s'affiche.
- Le contrôleur VDP canonique (`/tmp/cxv/vdpcheck.mjs`) l'accepte : il pose ses points d'arrêt dans toutes les banques.

### Pourquoi le jeu n'utilise pas le projet MegaCart d'Amy

- Dans ce modèle, la banque fixe ne fait que 16 Ko, et un fichier Amy de banque ne peut avoir que des procédures et des données, sans variables globales partagées avec la banque fixe.
- Le code Amy du jeu seul fait environ 21 Ko (plus 6 Ko d'images du zombie). Il ne peut pas tenir dans 16 Ko, et le couper en fichiers de banque est impossible quand chaque écran lit et écrit les variables du jeu.
- La demande « la banque fixe contient tout ce que la boucle de jeu touche » n'est donc pas réalisable telle quelle. Voici ce que j'ai fait à la place, qui garde l'idée : **pendant le jeu, rien ne change de banque**.

### Le plan de la ROM (`build.py`, `build/banks.txt`)

| Banque | Adresse | Contenu |
|---|---|---|
| 3 (fixe) | $8000-$BFFF | les 16 premiers Ko du programme Amy : le runtime, l'interruption, la plus grande partie du code |
| 2 (« maison » de l'acte I, du titre et des menus) | $C000-$FFBF | le reste du programme : code, images du zombie, RevTab, `tiles.asm`, `zup_upload`, table des sons, décodeur AMYZ |
| 1 (« maison » des actes II et III) | $C000-$FFBF | le même programme, avec ce qui est propre aux actes II et III (voir plus bas) |
| 0 (données) | $C000- | les images compressées AMYZ des trois actes, du titre et du gros plan, les pages de texte (8,6 Ko) |

- Le programme Amy est compilé comme une cartouche normale de 32 Ko au plus ($8000-$FFBF), puis coupé en deux par `build.py`.
- La banque maison de l'acte est choisie au début de l'acte (`SetAct`). Pendant le jeu, la banque fixe et la banque maison sont toujours en place : la boucle de jeu et l'interruption (musique) ne voient jamais de changement de banque.
- Les banques de données ne sont lues qu'à la mise en place d'un écran (et au rechargement de la table des noms de `LawnBand`), par `bk_unpack` et `bk_page` :
  - choisir la banque de données, décoder vers la VRAM, revenir à la banque maison ;
  - l'interruption est retenue pendant ce temps (Amy ne la laisse passer que dans l'attente de `Frame1`) ;
  - Amy place le bloc asm après les données, donc dans la zone $C000 : **le morceau `bk_find`..`bk_mirror_end` (routines de banque, décodeur, table des flux) est recopié aux mêmes adresses dans chaque banque de données**. Le code continue donc sans heurt quand la banque change sous lui.
- Place : programme 32 273 octets sur 32 704. Banque de données : 8,6 Ko sur 16 Ko. RAM : 602 octets sur 675.

### Le passage à 64 Ko (r5.1)

La r5 avait une banque maison par acte, plus 4 banques de données dont 3 vides. En 64 Ko, il n'y a que 4 banques : la banque fixe, une banque de données, et donc **deux** banques maison. Le programme n'avait pas la place de garder deux jeux de musiques à des adresses différentes. J'ai donc rangé ce qui est propre à chaque acte dans de la place qui est morte dans la banque des actes II et III :

- **Acte II** : sa musique, son air d'œuf et ses niveaux sont aux mêmes adresses que ceux de l'acte I (comme en r5).
- **Acte III** :
  - sa musique est **à la place de la musique du titre**, qui ne joue que sur l'écran-titre et les menus, toujours avec la banque de l'acte I. L'acte III la lance par les mêmes entrées de la table des sons (`SndMt*`) ;
  - son air d'œuf et sa table de niveaux sont dans la place qui reste dans les voix de la musique du titre. Il y a 4 entrées de plus dans la table des sons (`SndXg*`) ;
  - les lunettes de soleil (`GpTab`, `GlTab`) sont **par-dessus le code des écrans de menu** (`TextScreen` à `TitleScreen`, 989 octets de place), qui ne tourne qu'avec la banque de l'acte I.
- Garde-fous dans `build.py` (la construction échoue sinon) :
  - les lunettes doivent tenir dans le code des menus ;
  - `SetAct`, qui change de banque, doit être hors de cette zone ;
  - chaque morceau de l'acte III doit tenir dans sa place.
- Les écrans de menu ne sont appelés qu'après `SetAct` vers l'acte I : fin d'acte, game over, titre.
- Les tables de niveaux sont réunies en une table de 132 octets (`LvAll`), lue par `LvGet` à partir de `LvBase` (l'adresse de la table de l'acte).
- **Démarrage (correction)** : la banque en place à la mise sous tension n'est pas connue. Le code de démarrage d'Amy copie ses valeurs initiales de RAM depuis la zone $C000 (`AMY_INIT_RAM_DATA`) avant toute instruction du programme. L'entrée de la cartouche (en-tête $800A) passe donc maintenant par 6 octets en $8018 (les cases inutilisées de RST $28 et $30) qui choisissent la banque maison avant d'aller à `Start`.
  - En r5, ces valeurs initiales pouvaient venir d'une autre banque. Ça ne se voyait pas, parce que le jeu redonne leur valeur à ces variables avant de s'en servir. C'est corrigé.
- Le cœur de test et le contrôleur VDP prennent bien l'image de 64 Ko comme une MegaCart (`tests/coretype.mjs` : type 1, banque 2 en place après le démarrage, 0 accès perdu).

## 2. Acte II : « L'HIVER »

- **Neige** : plaine gris clair (couleur 14), une seule tuile (code 205), avec l'astuce du contour en tuiles (noir sur gris, `$1E`). Le poulet reste blanc.
- **Contre l'éblouissement** : le pâle n'est que sur le sol. Ciel noir et bleu foncé avec quelques flocons, sapins vert foncé (juste un point de neige à la pointe), clôture rouge foncé.
- **Obstacles** :
  - un **bonhomme de neige** à chaque niveau ;
  - des **luges** à partir du niveau 2 ;
  - une **plaque de glace** (4 × 2 cases).
- **Ils touchent le poulet et le zombie de la même façon** :
  - bonhomme et luge : le poulet rebondit dessus, le zombie s'y cogne ;
  - glace : le zombie glisse sans contrôle horizontal, le poulet glisse et perd son chemin.
- Musique : « Les bottes dans la neige », mi mineur, trot de traîneau, 448 images.

## 3. Acte III : « L'ÉTÉ » (changement d'Amy : plus de grenier)

- Soir d'été : bandes de coucher de soleil, soleil derrière une haie fleurie, clôture jaune foncé, **pelouse unie** (l'astuce du contour reste).
- **Le zombie porte des lunettes de soleil**, sur toutes ses images, à gauche comme à droite :
  - `zombie.py` redessine les 34 images avec les lunettes, avec les mêmes fenêtres ;
  - le jeu applique la différence : les couches de couleur perdent quelques octets (trous, `GpTab`), et la couche noire gagne les lunettes (`GlTab`, par lignes en masques 16 bits) ;
  - planche : `zombie-frames-shades-4x.png`.
- **Coup de soleil** : le corps du poulet passe d'un pastel à l'autre (rose, jaune pâle, cyan, magenta, vert clair). Une couleur toutes les 1,5 s, couleurs du TMS seulement.
- **Spectacle d'arrosage** :
  - toutes les 9 s, la moitié du fond de la pelouse est mouillée pendant 1,5 s (gouttes bleu clair), puis la moitié de devant ;
  - les gouttes changent 3 fois par seconde ;
  - pas de sprite : c'est la tuile du sol de ce tiers qui change (16 octets) ;
  - qui est sur la moitié mouillée quand l'eau arrive : **le poulet s'enfuit en panique** (vitesse +10, direction au hasard pendant 75 images) et **le zombie tourne sur lui-même** (l'animation de toupie), sans tournis ajouté.
- Obstacles : des **flamants roses en plastique** (le premier cache un œuf de Pâques). Paniers d'osier.
- Musique : « Le flamant rose », do majeur, shuffle paresseux, 448 images.

## 4. Mode ninja

- La cour d'Halloween, ses 6 niveaux. **Le poulet n'est visible que s'il est à moins de 48 px (40 en hauteur) du zombie et du côté où il regarde.** Sinon ses sprites sont cachés (son ombre aussi).
- Indices justes :
  - une **empreinte** discrète sur une case de sol uni (une seule à la fois, effacée après 1 s) ;
  - un **pas doux** toutes les 16 images quand il marche (sur la voix 2 : le canal de bruit porte la basse) ;
  - un **petit nuage** là où il retombe ;
  - **visible 1 s après chaque coup**.
- Empreinte et nuage : codes 203-204 des tiers de la pelouse. Jamais sous le bloc du contour : s'il arrive dessus, le bloc rend ses cases d'abord.
- Entrée dans le menu (« MODE NINJA ») et page d'aide 5/5 en capitales sans accents.

## 5. Œufs de Pâques et secrets (absents de l'aide)

Chaque œuf arrête le jeu 3,2 s avec son propre air, puis tout est remis en place : noms, objets, couche de contour reconstruite. La musique de l'acte repart du début, ce qui garde juste le compteur `MusC` des images légères. Rien ne reste bloqué.

- **Acte I** : un coup dans le vide contre chacune des **trois citrouilles-lanternes** de la clôture (le zombie s'y cogne : étoiles, pas de tournis). À la troisième, les lanternes se réveillent et dansent (sautillent et se balancent, à contretemps, leur lueur sur le temps) sur « La gigue des citrouilles », puis reprennent leur place.
- **Acte II** : coups successifs au **bonhomme de neige** : il perd sa carotte, puis son chapeau, puis ses yeux. Ensuite il tâtonne :
  1. il retrouve ses yeux sur la neige et les remet ;
  2. il va chercher son chapeau ;
  3. il remet la carotte ;
  4. il revient à sa place.
  
  L'air : « À tâtons ».
- **Acte III** (mon idée) : un coup renverse le **flamant rose**. Au second, il se relève, met des lunettes de soleil comme le zombie, saute à l'écart et danse sur une patte (« Les lunettes du flamant »), puis reprend la pose.
- Les deux derniers spectacles se jouent du côté opposé au zombie, pour ne pas être cachés par lui.
- **Petits secrets en plus** (un par acte), un panier réussi :
  - acte I, après un ricochet sur une tombe ;
  - acte II, botté depuis la glace ;
  - acte III, pendant l'arrosage.
- Un son scintillant marque chaque secret trouvé pour la première fois.
- Finir le mode ninja compte aussi comme un secret.
- **Écran « SECRETS — DEPUIS L'ALLUMAGE »** :
  - dans le menu, après chaque fin d'acte et après chaque game over ;
  - une ligne par acte : une étoile pour l'œuf, une pour le coup secret (jaune = trouvé, bleu foncé = pas encore), un cadenas si l'acte n'a pas été joué ;
  - rien n'est enregistré : c'est remis à zéro à l'allumage.

## 6. Autres changements et retouches

- Menu : 7 entrées (3 actes, ninja, aide, secrets, crédits). Aide en 5 pages. Les crédits disent « TROIS ACTES ET UN MODE NINJA ».
- **r5.1 : chaque coup qui touche le poulet rapporte 1 point**, même sans panier. Un panier rapporte toujours 10, 20 ou 30 au total (le point du coup en fait partie). Un coup dans le vide ne rapporte rien, et les ratés font toujours monter le tournis. Le HUD se met à jour l'image suivante. Aide page 1 : « CHAQUE COUP : 1 POINT. ».
- **r5.1 : niveau 6 de l'acte I avec 4 tombes au lieu de 5** (une graine du bot y perdait ses 3 vies).
- **Une vie rendue (jusqu'à 3) après les niveaux 3 et 5**. Le bot perdait parfois tout au niveau 6 des nouveaux actes ; avec ce bonus et un obstacle de moins au niveau 6 de l'hiver, les 36 parties finissent.
- **Correction r4** : au début de chaque niveau, le HUD était effacé par le rechargement de la table des noms et ne revenait qu'au premier événement. Il revient maintenant l'image suivante.
- Pierres tombales (r4) : les lignes à trois couleurs donnaient une pierre noire. Les bords sont maintenant noirs et la croix se voit.
- Musique : attaque au volume de la note puis environ la moitié, basse en bruit périodique qui décroît comme une corde pincée, batterie au même niveau que l'acte I, toutes les musiques d'acte bouclent en 448 images. Les airs des œufs ne bouclent pas.

## 7. Vérifications (émulateur de test GearColeco, vrai BIOS OS7)

Toutes ces vérifications ont été refaites sur la ROM r5.3 finale (`tests/checks.sh`, une étape à la fois, chacune sous 8 minutes). Les parties ne sont pas les mêmes qu'en r5.2 : un changement d'écran prend maintenant une image de plus ou de moins, et le hasard du jeu avance à chaque image. Les scores changent donc un peu.

**36 parties du bot r5.3** (graines 1 à 9 de chaque mode, manette seulement, sans écritures en RAM) :

| Mode | Graine | Résultat | Score | Vies | Images de jeu | Images perdues | Sprites/ligne max | Zombie coupé | Pire taux de coupe | Pire suite de coupes | Presque réussis | Pleine puissance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Acte I | 1 | acte terminé | 530 | 3 | 6002 | 0 | 6 | 0 | 42.7 % | 1 | 1 | 4 |
| Acte I | 2 | acte terminé | 620 | 3 | 6866 | 0 | 6 | 0 | 42.7 % | 1 | 8 | 10 |
| Acte I | 3 | acte terminé | 601 | 3 | 6365 | 0 | 6 | 0 | 43.7 % | 1 | 2 | 6 |
| Acte I | 4 | acte terminé | 551 | 3 | 6867 | 0 | 6 | 0 | 41.5 % | 1 | 5 | 5 |
| Acte I | 5 | acte terminé | 560 | 2 | 8579 | 0 | 6 | 0 | 39.8 % | 1 | 4 | 8 |
| Acte I | 6 | acte terminé | 610 | 3 | 10801 | 0 | 6 | 0 | 36.0 % | 1 | 3 | 9 |
| Acte I | 7 | acte terminé | 511 | 3 | 7750 | 0 | 6 | 0 | 42.2 % | 1 | 2 | 2 |
| Acte I | 8 | acte terminé | 590 | 3 | 6397 | 0 | 6 | 0 | 44.5 % | 1 | 5 | 6 |
| Acte I | 9 | acte terminé | 550 | 3 | 8474 | 0 | 6 | 0 | 41.2 % | 1 | 2 | 5 |
| Acte II | 1 | acte terminé | 551 | 3 | 9794 | 0 | 6 | 0 | 42.4 % | 1 | 6 | 3 |
| Acte II | 2 | acte terminé | 630 | 3 | 8169 | 0 | 6 | 0 | 42.0 % | 1 | 4 | 10 |
| Acte II | 3 | acte terminé | 520 | 3 | 7516 | 0 | 6 | 0 | 40.7 % | 1 | 2 | 5 |
| Acte II | 4 | acte terminé | 642 | 3 | 9027 | 0 | 6 | 0 | 41.8 % | 1 | 5 | 9 |
| Acte II | 5 | acte terminé | 591 | 3 | 6742 | 0 | 6 | 0 | 42.4 % | 1 | 4 | 4 |
| Acte II | 6 | acte terminé | 590 | 3 | 7225 | 0 | 6 | 0 | 40.8 % | 1 | 2 | 5 |
| Acte II | 7 | acte terminé | 540 | 3 | 7696 | 0 | 6 | 0 | 41.9 % | 1 | 4 | 6 |
| Acte II | 8 | acte terminé | 640 | 3 | 7500 | 0 | 6 | 0 | 41.4 % | 1 | 2 | 7 |
| Acte II | 9 | acte terminé | 520 | 3 | 6111 | 0 | 6 | 0 | 45.7 % | 1 | 5 | 5 |
| Acte III | 1 | acte terminé | 550 | 3 | 7729 | 0 | 6 | 0 | 42.4 % | 1 | 2 | 6 |
| Acte III | 2 | acte terminé | 590 | 2 | 9280 | 0 | 6 | 0 | 46.8 % | 1 | 4 | 8 |
| Acte III | 3 | acte terminé | 570 | 3 | 8238 | 0 | 6 | 0 | 42.5 % | 1 | 3 | 7 |
| Acte III | 4 | acte terminé | 630 | 3 | 7333 | 0 | 6 | 0 | 41.2 % | 1 | 1 | 8 |
| Acte III | 5 | acte terminé | 580 | 3 | 7199 | 0 | 6 | 0 | 43.2 % | 1 | 4 | 8 |
| Acte III | 6 | acte terminé | 520 | 3 | 7258 | 0 | 6 | 0 | 42.5 % | 1 | 5 | 4 |
| Acte III | 7 | acte terminé | 490 | 3 | 7924 | 0 | 6 | 0 | 42.2 % | 1 | 0 | 4 |
| Acte III | 8 | acte terminé | 570 | 3 | 8036 | 0 | 6 | 0 | 43.2 % | 1 | 4 | 5 |
| Acte III | 9 | acte terminé | 570 | 3 | 7460 | 0 | 6 | 0 | 42.8 % | 1 | 2 | 5 |
| Ninja | 1 | acte terminé | 540 | 3 | 7105 | 0 | 6 | 0 | 41.8 % | 1 | 4 | 4 |
| Ninja | 2 | acte terminé | 640 | 2 | 7807 | 0 | 6 | 0 | 43.3 % | 1 | 1 | 9 |
| Ninja | 3 | acte terminé | 571 | 3 | 6790 | 0 | 6 | 0 | 43.9 % | 1 | 3 | 9 |
| Ninja | 4 | acte terminé | 550 | 3 | 6349 | 0 | 6 | 0 | 43.8 % | 1 | 4 | 3 |
| Ninja | 5 | acte terminé | 580 | 3 | 6296 | 0 | 6 | 0 | 44.2 % | 1 | 4 | 5 |
| Ninja | 6 | acte terminé | 610 | 3 | 8247 | 0 | 6 | 0 | 42.2 % | 1 | 6 | 6 |
| Ninja | 7 | acte terminé | 571 | 3 | 8453 | 0 | 6 | 0 | 43.9 % | 1 | 7 | 4 |
| Ninja | 8 | acte terminé | 580 | 3 | 7035 | 0 | 6 | 0 | 41.2 % | 1 | 5 | 8 |
| Ninja | 9 | acte terminé | 540 | 2 | 9421 | 0 | 6 | 0 | 41.9 % | 1 | 3 | 4 |


- Les 36 parties finissent l'acte. 0 image perdue.
- Jusqu'à 6 sprites sur une ligne (permis), le zombie **jamais** coupé, aucun sprite coupé 2 images de suite, au pire 46,8 % des images avec une coupe (acte III, graine 2, qui trouve l'œuf par hasard).
- Le rouge du poulet est montré dans toutes les images où le poulet l'est. Les yeux, environ une sur deux (absents seulement sur les lignes à 3 sprites du zombie, ou quand l'ombre et les étoiles prennent la place). En r5.2 : rouge environ une sur deux, yeux environ une sur neuf.
- Chaque coup à pleine puissance des 36 parties a fini dans un panier avec exactement 30 points.

**Contrôle VDP** avec le contrôleur canonique (`/tmp/cxv/vdpcheck.mjs`, identique à `common/test/vdpcheck.mjs`), y compris les 3 œufs et le bot `--feat` (presque réussi puis pleine puissance, graine 1) :

| Partie | Résultat | Images perdues (jeu / œuf) | Zombie coupé | Pire taux | Pire suite | Accès perdus | Écritures mal dirigées | Écart min. (affichage) | VRAM fantôme divergente | Presque réussis (points du panier) | Pleine puissance (points) | Œuf |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Acte I, graine 4, démonstration | acte terminé | 0 / 0 | 0 | 42.9 % | 1 | 0 | 0 | 31 T | 0 | 4 (19, 19, 19, 29) | 8 (30, 30, 30, 30, 30, 30, 30, 30) |  |
| Acte II, graine 4 | acte terminé | 0 / 0 | 0 | 41.8 % | 1 | 0 | 0 | 31 T | 0 | 2 (19, 19) | 6 (30, 30, 30, 30, 30, 30) |  |
| Acte III, graine 4 | acte terminé | 0 / 0 | 0 | 40.6 % | 1 | 0 | 0 | 31 T | 0 | 5 (19, 29, 19, 19, 29) | 7 (30, 30, 30, 30, 30, 30, 30) |  |
| Ninja, graine 4 | acte terminé | 0 / 0 | 0 | 43.7 % | 1 | 0 | 0 | 31 T | 0 | 6 (29, 19, 19, 9, 19, 19) | 4 (30, 30, 30, 30) |  |
| Acte I, maladroite (game over voulu) | game over | 0 / 0 | 0 | 38.5 % | 1 | 0 | 0 | 31 T | 0 | 0 | 0 |  |
| Acte I, œuf au niveau 1 | acte terminé | 0 / 0 | 0 | 37.5 % | 1 | 0 | 0 | 31 T | 0 | 4 (9, 29, 19, 29) | 8 (30, 30, 30, 30, 30, 30, 30, 30) | oui (200 images) |
| Acte II, œuf au niveau 1 | acte terminé | 0 / 0 | 0 | 46.5 % | 1 | 0 | 0 | 31 T | 0 | 4 (29, 29, 9, 19) | 9 (30, 30, 30, 30, 30, 30, 30, 30, 30) | oui (200 images) |
| Acte III, œuf au niveau 1 | acte terminé | 0 / 0 | 0 | 50.0 % | 1 | 0 | 0 | 31 T | 0 | 3 (19, 29, 29) | 3 (30, 30, 30) | oui (200 images) |
| Acte I, --feat | acte terminé | 0 / 0 | 0 | 42.2 % | 1 | 0 | 0 | 31 T | 0 | 5 (29, 9, 9, 29, 29) | 9 (30, 30, 30, 30, 30, 30, 30, 30, 30) |  |
| Acte II, --feat | acte terminé | 0 / 0 | 0 | 42.9 % | 1 | 0 | 0 | 31 T | 0 | 5 (9, 29, 29, 9, 9) | 7 (30, 30, 30, 30, 30, 30, 30) |  |
| Acte III, --feat | acte terminé | 0 / 0 | 0 | 42.6 % | 1 | 0 | 0 | 31 T | 0 | 3 (9, 19, 19) | 4 (30, 30, 30, 30) |  |
| Ninja, --feat | acte terminé | 0 / 0 | 0 | 42.6 % | 1 | 0 | 0 | 31 T | 0 | 2 (19, 9) | 6 (30, 30, 30, 30, 30, 30) |  |

- « Points du panier » : sans le point du coup. 9, 19, 29 font donc 10, 20, 30 en tout ; une pleine puissance fait toujours 30.
- Écart min. 31 T pendant l'affichage (≥ 29 demandé), 0 accès perdu, 0 écriture mal dirigée, 0 divergence de la VRAM fantôme. L'envoi de la table des sprites est celui d'Amy, inchangé.
- Les trois œufs sont déclenchés par le bot (`tests/bot.mjs --egg`) : 200 images chacun, 0 perdue, le poulet continue son tour de rôle, puis la partie continue. Captures `egg-*`, `feat-*` comme en r5.2.
- **Contour (`tests/shbcheck.py`)** : 6459 dumps, 0 mismatches, les 12 cas couverts.
- **Cœur de test et contrôleur VDP sur l'image de 64 Ko** (`tests/coretype.mjs`) : MegaCart reconnue (type 1), banque 2 en place après le démarrage, 0 accès perdu.
- **Ninja** : 9 graines et `--feat` terminées. Le poulet reste caché comme avant (même code, tous ses sprites à Y = 209).

## 8. Bogues d'Amy Studio r12.11

**1. (r4, toujours là) `vram.spr_pat` n'est pas résolu dans une affectation.**
- Reproduction : `u16 DecTo = 0` puis `DecTo = vram.spr_pat + SpSkip`.
- Attendu : `DecTo` reçoit $3800 + SpSkip, comme `copy ... to vram.spr_pat + SpSkip`, qui marche.
- Obtenu : `ld A, vram.spr_pat + AMY_UCONST_SpSkip`, puis « Invalid expression ». En plus, c'est un chargement 8 bits (`ld A`) pour une variable u16.
- Correctif suggéré : résoudre `vram.*` dans toute expression constante (ou les refuser clairement), et choisir la largeur du chargement selon la destination.

**2. Le modèle « ColecoVision MegaCart » d'Amy Studio ne s'assemble pas.**
- Reproduction : le projet créé par le modèle (`newProjectTemplates.js`, `megacart`), construit avec `node tools/amyc.mjs project.amy.json --output mcv.rom --opt balanced`.
- Attendu : une ROM de 128 Ko.
- Obtenu : `Assembly failed on pass 3 ... call mdkrle_decompress - Invalid expression: mdkrle_decompress`. La ligne `decompress mdkrle Bank2Compressed from bank 2 to vram.name + 360` produit un appel au décodeur MDK-RLE sans le lier. Sans cette ligne, tout marche (copie de la banque 2 vers la VRAM et la RAM, `call bank`).
- Correctif suggéré : quand la trampoline MegaCart `decompress-vram` demande un codec, lier son décodeur dans la banque fixe (comme le fait `decompress` hors MegaCart). Et ajouter le modèle aux tests de la chaîne.
- Repro : `repro/mcv/` (projet, `main-with-decompress.amy`, `harness-check.mjs`).

**3. Un bloc `asm { }` du programme principal qui contient des données (`db`) est déplacé, en entier, après le programme, sans aucun message.**
- Reproduction (`repro/r3b.alexis`) :
  ```
  u8 A1 = 0
    asm {
      ld a,7
      ld (A1),a
      jp past_table
  my_table:
      db 1,2,3
  past_table:
    }
    text screen
    print A1 at 2,2
  ```
- Attendu : les instructions s'exécutent à leur place (A1 = 7), comme pour un bloc sans `db` (`repro/r3.alexis`, qui reste à sa place).
- Obtenu : tout le bloc, instructions comprises, est émis après la fin du programme (`--opt off` comme `balanced`). Les instructions ne s'exécutent jamais, et le programme affiche 0.
- Pour moi, c'est ce qui m'a fait perdre la sélection de la banque au démarrage : je l'avais mise en tête du gros bloc asm.
- Correctif suggéré : ne déplacer que les blocs sans instruction exécutable, ou garder le bloc à sa place. Dans tous les cas, avertir : « asm block with data moved after the program: its instructions will not run here ».

**4. Message trompeur : `Unsupported comparison: A1 <> B1`.**
- Reproduction (`repro/r5.alexis`) : une sub compare `A1 <> B1`, mais `u8 B1` est déclarée après la sub.
- Attendu : le message habituel « Global variable 'B1' is used before its declaration », qu'Amy donne pour une affectation.
- Obtenu : « Unsupported comparison », qui fait chercher un problème de syntaxe.
- Correctif suggéré : vérifier la déclaration des opérandes avant de classer la comparaison.

**5. (Limite plus que bogue) Le projet MegaCart ne permet pas de couper un gros programme Amy.**
- Un fichier Amy de banque ne peut pas partager les variables globales de la banque fixe. Un jeu dont le code fait plus de 16 Ko ne peut donc pas utiliser le projet MegaCart.
- Suggestion :
  - permettre à un fichier de banque de déclarer `extern` les variables de la banque fixe (même plan de RAM) ;
  - ou offrir le mode que j'ai fait à la main : programme de 32 Ko (banque fixe + une banque « maison » toujours en place), avec des banques de données lues par une routine recopiée aux mêmes adresses.

**6. (r5.3) Le clignotement intégré (`sprites flicker on`) n'est pas juste : un sprite peut rester invisible plusieurs images de suite.**
- Reproduction : `sprites stable 0 to 5`, `sprites flicker on`, 2 sprites stables sur une ligne, et 3 sprites non stables (A, B, C en 6, 7, 8) sur la même ligne, plus 2 autres non stables ailleurs (9, 10). Il y a 2 places pour A, B, C.
- Attendu (la doc dit « rotate fairly ») : chacun visible au moins une image sur deux.
- Obtenu : la phase avance d'un cran par image et la liste est lue en tournant à partir de la phase. Celui qui est coupé est le dernier des trois dans l'ordre lu. Avec les phases 6, 7, 8, 9, 10, les coupés sont C, A, B, C, C : **C est coupé 3 images de suite**. Les phases sur des sprites qui ne sont pas sur la ligne (9, 10) donnent le même ordre que la suivante. Dans ce jeu (acte I, graine 1) : le rouge du poulet coupé 60 % des images, jusqu'à 5 de suite.
- Correctif suggéré : à chaque débordement, **inverser l'ordre** des sprites non stables (aller, puis retour). C'est prouvé juste : sur une ligne avec k places et n ≤ 2k sprites qui tournent, chacun est dans les k premiers ou les k derniers. Documenter aussi cette limite (n ≤ 2k), sans laquelle aucune rotation ne peut être juste.

**7. (r5.3) Le clignotement réagit une image trop tard.**
- Reproduction : n'importe quel débordement qui commence (deux objets qui se rejoignent sur une ligne).
- Obtenu : le drapeau du 5e sprite, lu par l'interruption, ne décrit que l'image déjà affichée. La rotation ne commence donc qu'à l'image d'après, et le sprite coupé dans la première image l'est aussi dans la deuxième : 2 images de suite au début de chaque chevauchement (mesuré par le bot : pire suite 2 avec le drapeau seul, 1 avec la prédiction).
- Correctif suggéré : permettre de tourner sans attendre le drapeau (par exemple `sprites flicker always`, ou une instruction `rotate sprites` que le programme appelle quand il sait que des objets se chevauchent).

**8. (r5.3, documentation) Le rang stable est forcément devant, et forcément d'un seul tenant.**
- `sprites stable A to B` envoie ce rang en premier, donc il passe **devant** tous les autres sprites, quel que soit leur numéro. La doc dit « uploaded first » sans dire la conséquence sur l'ordre d'affichage. Dans ce jeu, le poulet (avant le zombie dans les numéros) serait passé derrière lui sans prévenir.
- Un seul rang : il a fallu renuméroter les sprites du zombie (ils étaient en 3, 4, 5, 6, 7 et 10).
- Suggestion : le dire dans la doc ; éventuellement, accepter une liste de sprites stables.

**9. (r5.3, mesure) La place affichée ne dit pas ce qui reste avant une table alignée.**
- Le programme fait 32 529 octets sur 32 704, mais 16 octets de code de plus avant `RevTab` (`ds (256 - ($ & 255)) & 255`) font échouer la compilation avec « 32785 / 32768 bytes (17 bytes over) ». Le message est juste, mais rien n'annonce avant qu'il ne reste que 15 octets à cet endroit.
- Suggestion : dans le résumé de la compilation, donner la place perdue en alignements, et la marge avant chaque `ds` d'alignement.

## 9. Compromis, non fait, non testé

- r5.3 : le poulet clignote à 30 Hz presque chaque fois qu'il est près du zombie (5 sprites sur une ligne dès que ses 3 couches touchent les lignes du zombie). C'est le compromis demandé. Personne ne l'a encore regardé sur un vrai téléviseur.
- r5.3 : le poulet passe derrière le zombie quand ils se chevauchent (section 00).
- r5.3 : sur les lignes où le zombie montre un contour (3 sprites), le poulet n'a pas ses yeux et son blanc et son rouge passent à tour de rôle. Le contraire violerait la règle d'une image sur deux.
- r5.3 : dans une image où les yeux sont coupés, on voit le fond par les trous sous les pupilles (2 × 2 pixels).

- La boucle de jeu lit aussi la banque maison (pas seulement la banque fixe) : voir la section 1.
- Acte III : pendant l'arrosage, le bloc de 5 × 5 cases du contour autour du zombie reste sec : une case de contour n'a que 2 couleurs par ligne.
- Les lunettes sont une barre noire de deux lignes. À cette taille, elles se lisent comme des lunettes de soleil surtout de face et en marchant.
- Les œufs ont été déclenchés par le bot, une partie par acte (graine 1), et regardés en captures et en vidéo. Pas plus.
- `tests/shbcheck.py` (tampon de contour comparé au modèle) reste valable pour les actes I et II. Il ne connaît pas les lunettes de l'acte III. Les lunettes ont été vérifiées en captures agrandies (droite, gauche, décalages différents).
- r5.2 : le coup presque réussi et la pleine puissance ont été vus en captures (les 4 modes) et mesurés par le bot. Personne n'a encore joué à la main la fenêtre de 6 images pour juger si elle est trop dure ou trop facile.
- r5.2 : la fenêtre n'a pas de signal visuel ou sonore à elle. Le zombie tremble plus vite dès la charge 31, comme avant. Le seul repère : le titubement qui suit si on attend trop.
- Pas de vrai ColecoVision ni d'openMSX. Pas d'écoute humaine des nouvelles musiques. Difficulté jugée par le bot seulement.
- RST $28 et $30 ne sont plus des `ret` (ils servent au démarrage). Ni Amy ni ce jeu ne les utilisent.

## Livré

- `ZOMBIE-BOTTE-POULET-r5.3.zip` contient :
  - la ROM (64 Ko) ;
  - `source/` : toutes les sources, les tests, les journaux, les repros Amy ;
  - `screenshots/` (par acte, ninja, œufs, menus ; `flicker/` : avant/après et la paire de la rotation) ;
  - `sheets/` (zombie, zombie à lunettes, tuiles des trois actes, aperçus des cours) ;
  - `video/` : la partie de l'acte I (graine 4, ROM r5.3, avec le clignotement) et ses temps forts ;
  - ce rapport ;
  - `MTIMES.txt` (heures de Toronto).
- Construire : `AMY_TOOLCHAIN=<dossier r12.11> python3 build.py`.
- Reconstruction depuis un dossier vide : SHA-256 identique, `f7ad9210fcf32981f6ce47776c74cc21ee6a0eba99cea1942622aa9bab42a7e6` (le dossier `source/` du zip copié dans un dossier vide).
