// coretype.mjs ROM - does the GearColeco test core take the image as a MegaCart?
import { openPort } from "../common/test/portlib.mjs";
const base = process.argv[2].replace(/\.rom$/, "");
const p = await openPort(base, { vdp: true });
p.step(0, 1200);   // past the BIOS title screen
const r = p.vdpReport();
console.log(JSON.stringify({ cartridgeType: p.g.core.getCartridgeType(), megacart: p.g.core.isMegaCart(), romBank: p.g.core.getRomBank(), phase: p.get("Phase"), vdpDrops: r.drops, misdirected: r.misdirected }));
