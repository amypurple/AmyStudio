"""cutvideo.py REPORT.json FULL.mp4 OUT.mp4 - a highlights video from the bot's
event list: a few seconds round walking, kicks, spins, staggers, and the
chicken hitting gravestones (ricochet in flight, bump while waddling)."""
import json, subprocess, sys, tempfile, os
rep, full, out = sys.argv[1:4]
ev = json.load(open(rep))['events']            # [kind, video frame, level]
want = ['kick', 'chicken-ricochet', 'stagger', 'chicken-bump', 'spin', 'kick', 'chicken-ricochet',
        'stagger', 'chicken-bump', 'kick', 'zombie-bonk', 'chicken-ricochet']
used, picks = set(), []
for kind in want:
    for i, (k, f, lv) in enumerate(ev):
        if k == kind and i not in used and lv >= 2 and all(abs(f - q) > 420 for q in picks):
            used.add(i); picks.append(f); break
picks.sort()
tmp = tempfile.mkdtemp()
parts = []
# the opening: title and the first walk (6 s), then 6 s round each event
spans = [(4.0, 6.0)] + [(max(0, f / 60 - 3.0), 6.0) for f in picks]
for i, (ss, dur) in enumerate(spans):
    pth = os.path.join(tmp, f'p{i}.mp4')
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-ss', f'{ss:.2f}', '-i', full, '-t', f'{dur}',
                    '-c:v', 'libx264', '-crf', '20', '-pix_fmt', 'yuv420p', '-an', pth], check=True)
    parts.append(pth)
lst = os.path.join(tmp, 'list.txt')
open(lst, 'w').write(''.join(f"file '{p}'\n" for p in parts))
subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-f', 'concat', '-safe', '0', '-i', lst, '-c', 'copy', out], check=True)
print(f"cutvideo: {len(parts)} parts, events at frames {picks}")
