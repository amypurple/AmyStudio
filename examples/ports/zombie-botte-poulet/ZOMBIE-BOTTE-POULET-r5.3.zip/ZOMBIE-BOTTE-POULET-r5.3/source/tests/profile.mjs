// profile.mjs - cycle counts of the heavy routines during a bot game (test aid).
//   import { attachProfile } from "./profile.mjs"; const pr = attachProfile(g, symText, ["tl_render", ...]);
//   ... run ...; pr.report()  -> { name: { calls, avgT, maxT } , frameMaxT }
// Execute breakpoints on each routine's entry; at the entry the return address
// (top of stack) gets a breakpoint too; the cycles in between are the call's.
export function attachProfile(g, symText, names) {
  const c = g.core, M = c.module;
  const addr = {};
  for (const n of names) {
    const m = symText.match(new RegExp(`^${n}: equ \\$([0-9A-F]{4})`, "mi"));
    if (!m) throw new Error("no symbol " + n);
    addr[n] = parseInt(m[1], 16);
    c.setExecuteBreakpoint(addr[n]);
  }
  const byAddr = Object.fromEntries(Object.entries(addr).map(([n, a]) => [a, n]));
  const S = Object.fromEntries(names.map(n => [n, { calls: 0, sum: 0, max: 0 }]));
  const open = new Map();   // return address -> [name, start clock]
  // per play-loop pass (Frame1 return to the next Frame1 call): the work and
  // the routines' cycles in it; hist keeps the last 4 passes
  let cur = {}, hist = [], lastRet = 0, worst = [];
  c.runFrame = () => {
    for (;;) {
      const r = M._gcw_run_frame();
      if (r !== 1) break;
      const pc = M._gcw_get_pc() & 0xFFFF;
      const clk = c.getMasterClockCycles();
      if (open.has(pc)) {
        const [n, t0] = open.get(pc);
        open.delete(pc);
        c.clearExecuteBreakpoint(pc);
        const d = (clk - t0);
        S[n].calls++; S[n].sum += d; if (d > S[n].max) S[n].max = d;
        if (n === "Nmi" && d > 10000) (globalThis.bigNmi ||= []).push([Math.round(Number(clk)/59736), d]); if (n === "AMY_UPROC_Frame1") { lastRet = clk; cur.f1 = d; } else cur[n] = (cur[n] || 0) + d;
      }
      if (byAddr[pc] === "AMY_UPROC_Frame1" && lastRet) {
        cur.work = clk - lastRet; hist.push(cur); if (hist.length > 4) hist.shift();
        worst.push(cur); worst.sort((a, b) => b.work - a.work); if (worst.length > 60) worst.pop();
        cur = {};
      }
      if (byAddr[pc] !== undefined) {
        const sp = c.getSp();
        const ra = c.readRam(sp, 2); const ret = ra[0] | (ra[1] << 8);
        open.set(ret, [byAddr[pc], clk]);
        c.setExecuteBreakpoint(ret);
      }
      c.stepInstruction();
    }
  };
  return {
    recent() { return hist.slice(); }, worst() { return worst; },
    report() {
      const o = {};
      for (const n of names) o[n] = { calls: S[n].calls, avg: S[n].calls ? Math.round(S[n].sum / S[n].calls) : 0, max: S[n].max };
      return o;
    }
  };
}
