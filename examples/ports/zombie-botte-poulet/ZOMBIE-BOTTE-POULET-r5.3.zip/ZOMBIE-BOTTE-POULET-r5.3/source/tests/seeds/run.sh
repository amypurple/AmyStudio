cd /tmp/claude-0/-home-claude/1a989a62-868e-5188-adf8-4832b4e486a2/scratchpad/work/poulet
for sd in "$@"; do timeout 470 node tests/bot.mjs --seed $sd --max-frames 40000 --out tests/out-dev > tests/seeds/s$sd.json 2>/dev/null; done
echo done
