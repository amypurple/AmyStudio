#!/bin/sh
# run.sh [main|seeds|eggs|shb|core|feat] - the r5.3 checks (each run stays under 8 minutes).
#   main:  for each act and the ninja mode, a bot game with the VDP checker
#          and screenshots (act I also the video and the help/secrets pages),
#          then a clumsy game (spins, stumble, OUPS, game over) with the checker
#   seeds: seeds 1-9 of each act and of the ninja mode, plain bot
#   feat:  r5.2, for each act and the ninja mode: near misses, then full-power
#          kicks (screenshots), with the VDP checker, then play on
#   eggs:  each act's Easter egg set off on level 1 (screenshots), then play on
# Needs the real OS7 BIOS (COLECO_BIOS) and AMY_STUDIO (see common/test/portlib.mjs).
set -e
cd "$(dirname "$0")/.."
R=build/zombie-botte-poulet
mkdir -p tests/logs
case "$1" in
main)
  rm -rf tests/out tests/out-clumsy tests/out-act2 tests/out-act3 tests/out-ninja
  node tests/bot.mjs $R --act 1 --seed 4 --vdp --shots --menus --showoff --video tests/out/gameplay-full.mp4 > tests/logs/bot-act1-seed4-vdp.json
  node tests/bot.mjs $R --act 2 --seed 4 --vdp --shots --out tests/out-act2 > tests/logs/bot-act2-seed4-vdp.json
  node tests/bot.mjs $R --act 3 --seed 4 --vdp --shots --out tests/out-act3 > tests/logs/bot-act3-seed4-vdp.json
  node tests/bot.mjs $R --ninja --seed 4 --vdp --shots --out tests/out-ninja > tests/logs/bot-ninja-seed4-vdp.json
  node tests/bot.mjs $R --seed 4 --vdp --shots --clumsy --out tests/out-clumsy > tests/logs/bot-clumsy-vdp.json
  python3 tests/cutvideo.py tests/logs/bot-act1-seed4-vdp.json tests/out/gameplay-full.mp4 tests/out/gameplay-highlights.mp4
  ;;
seeds)
  for m in "--act 1" "--act 2" "--act 3" "--ninja"; do
    t=$(echo $m | tr -d ' -')
    for s in 1 2 3 4 5 6 7 8 9; do node tests/bot.mjs $R $m --seed $s --out tests/out-s > tests/logs/bot-$t-seed$s.json; done
  done
  rm -rf tests/out-s
  ;;
shb)
  node tests/bot.mjs $R --act 1 --seed 2 --shbuf --out tests/out-s > tests/logs/shb-act1.json
  node tests/bot.mjs $R --act 2 --seed 2 --shbuf --out tests/out-s > tests/logs/shb-act2.json
  rm -rf tests/out-s
  python3 tests/shbcheck.py tests/logs/shb-act1.json tests/logs/shb-act2.json > tests/logs/shbcheck.txt
  ;;
core)
  node tests/coretype.mjs $R.rom > tests/coretype.txt
  ;;
feat)
  for m in "--act 1:act1" "--act 2:2" "--act 3:3" "--ninja:ninja"; do a=${m%%:*}; t=${m##*:}; rm -rf tests/out-feat$t; node tests/bot.mjs $R $a --seed 1 --feat --shots --vdp --out tests/out-feat$t > tests/logs/bot-feat-$t.json; done
  ;;
eggs)
  for a in 1 2 3; do rm -rf tests/out-egg$a; node tests/bot.mjs $R --act $a --egg --shots --seed 1 --vdp --max-frames 16000 --out tests/out-egg$a > tests/logs/bot-egg$a.json; done
  ;;
esac
