// shotpair.mjs - r5.3: the bot (bot.mjs), plus screenshots of the chicken
// next to the zombie: --mode old (r5.2: a frame where the chicken shares the
// zombie's lines and has lost a colour) or --mode new (r5.3: two frames in a
// row where a line has more than 4 sprites: the rotation). Amy & Claude 2026.
// bot.mjs - ZOMBIE BOTTE POULET: QA bot (Amy & Claude 2026).
//   node tests/bot.mjs [build/zombie-botte-poulet] [--act 1|2|3] [--ninja] [--egg] [--seed S] [--vdp]
//                      [--shots] [--video file.mp4] [--clumsy] [--max-frames N] [--out dir]
// r5: --act picks the act in the menu, --ninja the ninja mode (act I's yard,
// hidden chicken), --egg walks to the act's Easter egg on level 1 and sets it
// off (screenshots during the egg), then plays on. --menus: the help pages
// and the secrets screen are visited and shot.
// Boots the ROM on the real OS7 BIOS, goes through credits, title and act menu,
// then plays act I with the joystick only (no RAM writes). The player reads
// the positions from RAM, walks behind the toy chicken, holds the button and
// lets go when a simulated flight (the game's own physics) ends in a basket.
// Checks every frame of the play loop: lost frames (Phase = 1 and Tick did not
// move), sprite visibility (r5.3: from the SAT in VRAM; zombie never cut, any
// other sprite cut at most 1 frame in 2), and with
// --vdp the TMS9928A access timing. --clumsy kicks at thin air until the
// zombie trips (for the stumble, OUPS and game-over screenshots).
// r5.2: --feat first aims for near misses (a landing 10..20 px off a basket:
// the hop in), then kicks at full power (charge 43, the last frames before
// the stagger), with screenshots of both; then plays on as usual. Every run
// reports the near misses and full-power kicks seen (and the full-power score).
import path from "node:path";
import { readFileSync } from "node:fs";
import { spawn } from "node:child_process";
import { openPort, IN } from "../common/test/portlib.mjs";

const args = process.argv.slice(2);
const opt = (k, d) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : d; };
const VALUED = new Set(["--mode", "--skip", "--video", "--max-frames", "--out", "--profile", "--act"]);
const pos = args.filter((a, i) => !a.startsWith("--") && !VALUED.has(args[i - 1]));
const base = path.resolve(pos[0] || "build/zombie-botte-poulet");
const SEED = +opt("--seed", 4), MAXF = +opt("--max-frames", 60 * 60 * 25);
const SHOWOFF = args.includes("--showoff");
const SHOTS = args.includes("--shots"), VDP = args.includes("--vdp"), CLUMSY = args.includes("--clumsy");
const VIDEO = opt("--video", null);
const FEAT = args.includes("--feat");
const DEBUG = args.includes("--debug");
const ACT = +opt("--act", 1), NINJA = args.includes("--ninja"), EGG = args.includes("--egg"), MENUS = args.includes("--menus");
const outDir = path.resolve(opt("--out", "tests/out"));
const p = await openPort(base, { outDir, vdp: VDP, seed: SEED });
let PROF = null;
if (args.includes("--profile")) {
  const { attachProfile } = await import("./profile.mjs");
  PROF = attachProfile(p.g, readFileSync(base + ".sym", "utf8"), opt("--profile", "").split(","));
}
const say = s => console.log(s);
const g = p.g;
const v = n => p.get(n), v16 = n => p.get16(n);

// ---------------------------------------------------------------- per-frame checks
const overLog = [];
let maxPerLine = 0, overLines = 0, satFrames = 0;
// r5.3: more than 4 sprites on a line is allowed (flicker), so each sprite's
// visibility is measured instead: a sprite is cut on a line when 4 sprites
// before it in the SAT already use that line. The zombie (patterns 0-47: his
// buffers and outline halves) must never be cut; any other sprite may be cut
// on a given pixel row of its own at most 1 frame in 2 (never 2 frames in a
// row), counted per role (chicken white, red, eyes, shadow, stars, other).
const ROLE = pat => pat < 48 ? "zombie" : pat === 144 ? "shadow" : pat === 148 ? "stars" :
  [88, 92, 136, 140].includes(pat) ? "eyes" : (pat >= 48 && pat < 136) ? (((pat - 48) & 4) ? "red" : "white") : "other";
const vis = {}, overFrames = { n: 0 };
const roleRun = {}, consecLog = [];
let prevSat = null; const hist = [];
function satCheck() {
  const sat = g.core.readVram(0x1B00, 128);
  const cnt = new Uint8Array(256);
  const seen = {};
  for (let s = 0; s < 32; s++) {
    const y = sat[s * 4];
    if (y === 208) break;
    if (y === 209) continue;
    const top = (y + 1) & 255;
    const role = ROLE(sat[s * 4 + 2]);
    let cutRows = 0, on = 0;
    for (let k = 0; k < 16; k++) {
      const l = (top + k) & 255;
      if (l >= 192) continue;
      on = 1;
      if (cnt[l] >= 4) cutRows |= 1 << k;
      cnt[l]++;
    }
    if (!on) continue;
    const r = vis[role] || (vis[role] = { frames: 0, cutFrames: 0, maxConsec: 0 });
    const key = role + (role === "zombie" ? s : "");
    if (seen[key]) continue;
    seen[key] = 1;
    if (role !== "zombie" || !seen.zombieCounted) { r.frames++; if (role === "zombie") seen.zombieCounted = 1; }
    if (cutRows) r.cutFrames++;
    const run = roleRun[key] || (roleRun[key] = { f: -2, rows: new Array(16).fill(0) });
    const cont = run.f === g.frame - 1;
    for (let k = 0; k < 16; k++) {
      run.rows[k] = (cutRows >> k) & 1 ? (cont ? run.rows[k] + 1 : 1) : 0;
      if (run.rows[k] > r.maxConsec) r.maxConsec = run.rows[k];
      if (run.rows[k] === 2 && consecLog.length < 8 && !(consecLog.length && consecLog[consecLog.length - 1].f === g.frame)) consecLog.push({ f: g.frame, role, row: k, tick: v("Tick"), sat: Array.from(sat.slice(0, 44)), prev: prevSat, hist: DEBUG ? hist.slice() : null });
    }
    run.f = g.frame;
  }
  let m = 0;
  for (let l = 0; l < 192; l++) { if (cnt[l] > m) m = cnt[l]; if (cnt[l] > 4) overLines++; }
  if (DEBUG) { hist.push([g.frame, g.core.readRam(0x707D, 1)[0], g.core.readRam(0x7093, 1)[0], m, v("Tick")]); if (hist.length > 6) hist.shift(); }
  if (m > 4) overFrames.n++;
  if (m > maxPerLine) maxPerLine = m;
  if (m > 4 && overLog.length < 12) overLog.push({ f: g.frame, zs: v("ZState"), cs: v("CState"), zy: v("Zpy"), cy: v("Cpy"), ch: v("Cph"), sat: Array.from(sat.slice(0, 48)), tt: v("TlTop") + 2 * v("TlBot"), tk: v("Tick") & 1 });
  satFrames++;
  prevSat = Array.from(sat.slice(0, 44));
}
function visReport() {
  const out = {};
  let worstRatio = 0, worstConsec = 0;
  for (const [k, r] of Object.entries(vis)) {
    const ratio = r.frames ? r.cutFrames / r.frames : 0;
    out[k] = { frames: r.frames, cutFrames: r.cutFrames, ratio: +ratio.toFixed(4), maxConsec: r.maxConsec };
    if (k !== "zombie") { worstRatio = Math.max(worstRatio, ratio); worstConsec = Math.max(worstConsec, r.maxConsec); }
  }
  const zc = vis.zombie ? vis.zombie.cutFrames : 0;
  return { roles: out, zombieCut: zc, worstRatio: +worstRatio.toFixed(4), worstConsec, overFrames: overFrames.n,
    ok: zc === 0 && worstConsec <= 1 && worstRatio <= 0.5 };
}
// video: every frame from the title on, piped to ffmpeg (60 fps, 2x)
let ff = null;
if (VIDEO) {
  ff = spawn("ffmpeg", ["-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", "256x192", "-r", "60", "-i", "-",
    "-vf", "scale=512:384:flags=neighbor", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "20", path.resolve(VIDEO)], { stdio: ["pipe", "inherit", "inherit"] });
}
let recording = false, recFrames = 0, lostSeen = 0;
const lostInfo = []; const SHB = args.includes("--shbuf"), shbLog = [];
// events seen (frame number in the video): kicks, spins, staggers, chicken hits a stone
const events = [];
let lastEv = {}, prevCs = 0;
function noteEvents() {
  if (v("Phase") === 5) { if (!lastEv.egg) { events.push(["egg", recFrames, v("Level")]); lastEv.egg = 1; } return; }
  lastEv.egg = 0;
  if (v("Phase") !== 1) return;
  if (ACT === 3) { v("WShow") === 1 ? (lastEv.water || events.push(["water", recFrames, v("Level")]), lastEv.water = 1) : (lastEv.water = 0); }
  const zs = v("ZState"), cs = v("CState");
  const ev = k => { if (!lastEv[k]) { events.push([k, recFrames, v("Level")]); lastEv[k] = 1; } };
  const clear = k => { lastEv[k] = 0; };
  zs === 2 ? ev("kick") : clear("kick");
  zs === 3 ? ev("spin") : clear("spin");
  zs === 4 ? ev("stagger") : clear("stagger");
  zs === 6 ? ev("zombie-bonk") : clear("zombie-bonk");
  v("RicoT") === 10 ? ev("chicken-ricochet") : clear("chicken-ricochet");
  (cs === 2 && v("CT") === 13 && prevCs === 0) ? ev("chicken-bump") : clear("chicken-bump");
  prevCs = cs;
}
const step0 = p.step;
p.step = (m = 0, n = 1) => {
  for (let i = 0; i < n; i++) {
    step0(m, 1);
    pairHook();
    if (v("Phase") === 1 || v("Phase") === 5) satCheck();
    if (v("Phase") === 5) { eggFrames++; const t = v("Tick"); if (t === eggTick) eggLost++; eggTick = t; }
    if (SHB && v("Phase") === 1 && v("ZPhase") === 0 && v("ZReady") === 0 && v("ZUplC") === 0 && v("TlValid") === 1) { const b = g.getArray("ShBuf", 240); shbLog.push([g.frame, v("TlF"), v("TlFl"), v("TlSx"), b.join(",")]); }
    if (ff && recording) { const f = g.rgb(); ff.stdin.write(Buffer.from(f.out)); recFrames++; }
    if (recording) noteEvents();
    if (p.watch && p.watch.lost !== lostSeen) { lostSeen = p.watch.lost; lostInfo.push({ f: g.frame, mv: v("TlMv"), ub: v("ZUplB"), up: v("ZUpl"), hp: v("HPrep"), q: v("TlQ"), tt: v("TlTop") + 2 * v("TlBot"), tk: v("Tick") & 1, rdy: v("ZReady"), go: v("TlGo"), nl: v("TlNl"), zs: v("ZState"), cs: v("CState"), lv: v("Level"), zf: v("ZFn"), fl: v("ZFlip"), wet: v("Wet"), gm: v("GMode"), ch: v("Cph"), pr: PROF ? PROF.recent() : null }); }
  }
};

// ---------------------------------------------------------------- r5.3 shots
const MODE = opt("--mode", "new"); let SKIP = +opt("--skip", 0), pairDone = 0, pairNext = -1;
function pairHook() {
  if (pairDone >= 2 || v("Phase") !== 1) return;
  const sat = g.core.readVram(0x1B00, 44);
  const zt = sat[0], ct = sat[MODE === "old" ? 4 : 0];
  const ent = []; for (let i = 0; i < 11; i++) ent.push([sat[i * 4], sat[i * 4 + 1], sat[i * 4 + 2], sat[i * 4 + 3]]);
  const zomb = ent.filter(e => e[2] < 48 && e[0] !== 209), chick = ent.filter(e => e[2] >= 48 && e[2] < 144 && e[0] !== 209);
  if (!zomb.length || !chick.length) { pairNext = -1; return; }
  const zy = Math.min(...zomb.map(e => e[0])), cy = chick[0][0];
  const dx = Math.abs(chick[0][1] - zomb[0][1]);
  const near = cy + 16 > zy && cy < zy + 32 && dx < 40;
  if (pairNext === g.frame) { p.shot("r53-rotation-b"); pairDone = 2; return; }
  if (!near) return;
  if (MODE === "old") { if (chick.length < 3 && SKIP-- <= 0) { p.shot("r52-before"); pairDone = 2; } return; }
  if (chick.length === 3 && SKIP-- <= 0) { p.shot("r53-rotation-a"); pairNext = g.frame + 1; pairDone = 1; }
}
const xshots = {};
let eggFrames = 0, eggLost = 0, eggTick = -1;
const shots = [];
const shot = name => { if (SHOTS) { p.shot(name); shots.push(name); } };

// ---------------------------------------------------------------- the game's physics (for aiming)
const FX0 = 16 * 16, FX1 = 236 * 16, FY0 = 104 * 16, FY1 = 170 * 16;
function baskets() {
  const n = v("NBk"), bx = p.arr("BkX", 4), by = p.arr("BkY", 4), bf = p.arr("BkFull", 4);
  const out = [];
  for (let i = 0; i < n; i++) if (!bf[i]) out.push({ x: bx[i] * 8 + 8, y: by[i] * 8 + 10, i });
  return out;
}
// landing point of a kick with charge K (after the increment), facing f, slant s (-1,0,1), random r (0..7)
let GV = [];
function readGraves() {
  const n = v("NGv"), gx = p.arr("GvX", 5), gy = p.arr("GvY", 5);
  GV = []; for (let i = 0; i < n; i++) GV.push([gx[i] * 8, gy[i] * 8 + 4]);
}
const onGrave = (x, y) => GV.some(([gx, gy]) => x >= gx && x <= gx + 15 && y >= gy && y <= gy + 12);
function flight(cx, cy, K, f, s, r, dizzy) {
  if (K < 6) K = 6;
  const Q = K + 16;
  let vx = f === 0 ? Q : -Q, vy = s * (Q >> 1);
  vy += r + dizzy - ((dizzy >> 1) + 4);
  let vz = (K >> 1) + 20, up = true, h = 0, X = cx, Y = cy, rico = 0;
  const half = q => (q >= 0 ? q >> 1 : -((-q) >> 1));
  for (let t = 0; t < 200; t++) {
    X += vx; Y += vy;
    if (X < FX0) { X = FX0; vx = -vx; } if (X > FX1) { X = FX1; vx = -vx; }
    if (Y < FY0) { Y = FY0; vy = -vy; } if (Y > FY1) { Y = FY1; vy = -vy; }
    if (rico > 0) rico--;
    if (h < 160 && rico === 0 && onGrave(X >> 4, Y >> 4)) { X -= vx; Y -= vy; vx = half(-vx); vy = half(-vy); rico = 10; }
    if (up) { h += vz; if (vz > 2) vz -= 2; else { up = false; vz = 0; } continue; }
    vz += 2;
    if (h > vz) { h -= vz; continue; }
    if (onGrave(X >> 4, Y >> 4)) return null;          // bounces off a stone: no basket
    return { x: X >> 4, y: Y >> 4 };
  }
  return null;
}
// r5.2: landings next to a basket (not in it, within the game's 20 x 16 px)
function nearRate(K, f, s, bks) {
  const cx = v16("CX"), cy = v16("CY"), dz = v("Dizzy");
  readGraves();
  let best = 0;
  for (const b of bks) {
    let n = 0;
    for (let r = 0; r < 8; r++) {
      const l = flight(cx, cy, K, f, s, r, dz);
      if (!l) continue;
      const dx = Math.abs(l.x - b.x), dy = Math.abs(l.y - b.y);
      if (dx < 20 && dy < 16 && !(dx < 10 && dy < 9)) n++;
    }
    if (n > best) best = n;
  }
  return best;
}
function hitRate(K, f, s, bks) {
  const cx = v16("CX"), cy = v16("CY"), dz = v("Dizzy");
  readGraves();
  let best = 0;
  for (const b of bks) {
    let n = 0;
    for (let r = 0; r < 8; r++) {
      const l = flight(cx, cy, K, f, s, r, dz);
      if (l && Math.abs(l.x - b.x) < 9 && Math.abs(l.y - b.y) < 8) n++;
    }
    if (n > best) best = n;
  }
  return best;
}
// where the zombie wants to stand: on the side of the chicken away from the
// most reachable basket, on its line (or offset for a slanted kick)
function plan() {
  const cx = v("Cpx"), cy = v("Cpy"), bks = baskets();
  readGraves();
  // the spot behind the chicken must not be on (or right next to) a stone
  const blockedSide = f => { const sx = f === 0 ? cx - 12 : cx + 12; return sx < 18 || sx > 234 ||
    GV.some(([gx, gy]) => sx >= gx - 4 && sx <= gx + 19 && cy >= gy - 4 && cy <= gy + 14); };
  let best = null;
  for (const b of bks) {
    const dx = b.x - cx, dy = b.y - cy;
    const adx = Math.abs(dx);
    if (adx < 24) continue;
    const f = dx > 0 ? 0 : 1;
    if (blockedSide(f)) continue;
    const s = Math.abs(dy) < adx / 4 ? 0 : (dy < 0 ? -1 : 1);
    const err = Math.abs(dy - s * adx / 2);
    const score = err + adx / 8;
    if (!best || score < best.score) best = { f, s, score };
  }
  if (best) return best;
  const f = blockedSide(0) ? 1 : blockedSide(1) ? 0 : (cx < 128 ? 0 : 1);
  return { f, s: 0, score: 0 };
}

// ---------------------------------------------------------------- one frame of play
let featStage = 0, stallX = 0, stallY = 0, stallT = 0, stalls = 0;
let overhold = false, charges = 0, detour = 0, detourDir = 0;
let holding = false, rel = 0, waitT = 0, kicks = 0, aimS = 0, releases = 0;
// steer round the gravestones: look 10 frames ahead along the zombie's speed
function avoid(m) {
  readGraves();
  const vx = v("ZVx") - 128, vy = v("ZVy") - 128;
  const zx = v("Zpx"), zy = v("Zpy");
  for (const [gx, gy] of GV) {
    for (const t of [4, 8, 12]) {
      const px = zx + (vx * t) / 16, py = zy + (vy * t) / 16;
      if (px >= gx - 5 && px <= gx + 20 && py >= gy - 4 && py <= gy + 16) {
        // brake sideways and go round above or below
        m &= ~(IN.LEFT | IN.RIGHT);
        if (vx > 0) m |= IN.LEFT; else if (vx < 0) m |= IN.RIGHT;
        m &= ~(IN.UP | IN.DOWN);
        m |= (zy < gy + 6 && gy - 8 > 104) || zy + 20 > 170 ? IN.UP : IN.DOWN;
        return m;
      }
    }
  }
  return m;
}
function playFrame() {
  const zx = v("Zpx"), zy = v("Zpy"), cx = v("Cpx"), cy = v("Cpy");
  const zs = v("ZState"), cs = v("CState");
  let m = 0;
  if (CLUMSY) {
    // walk away from the chicken and kick at nothing
    if (zs === 0 && cs !== 1) {
      if (Math.abs(zx - cx) < 60) m |= cx > zx ? IN.LEFT : IN.RIGHT;
      if (g.frame % 24 < 6) m |= IN.FIRE_LEFT;
    }
    p.step(m);
    return;
  }
  // just bumped into a stone: go round it (up or down, whichever is nearer its edge)
  if (zs === 6 && detour === 0) {
    readGraves();
    let near = null, dmin = 1e9;
    for (const [gx, gy] of GV) { const d = Math.abs(gx + 8 - zx) + Math.abs(gy + 6 - zy); if (d < dmin) { dmin = d; near = [gx, gy]; } }
    detourDir = near && (zy < near[1] + 6 && near[1] - 10 > 104 || zy + 22 > 170) ? IN.UP : IN.DOWN;
    detour = 40;
  }
  // r5.2: a bot stall (it can dither between a sled and its target): when the
  // zombie has not moved for 4 s, step aside for a while
  if (Math.abs(zx - stallX) + Math.abs(zy - stallY) > 3) { stallX = zx; stallY = zy; stallT = 0; }
  else if (++stallT > 240 && detour === 0 && !holding) { stallT = 0; stalls++; detourDir = (stalls & 1 ? IN.LEFT : IN.RIGHT) | (zy > 140 ? IN.UP : IN.DOWN); detour = 90; }
  if (detour > 0) { detour--; if (!holding) { p.step(detour > 30 ? 0 : detourDir); return; } }
  const pl = plan();
  // stand 12 px behind the chicken, on its line
  const tx = pl.f === 0 ? cx - 12 : cx + 12;
  if (!holding) {
    if (zx + 2 < tx) m |= IN.RIGHT; else if (zx > tx + 2) m |= IN.LEFT;
    // face the right way when close
    if (!(m & (IN.LEFT | IN.RIGHT)) && v("ZFace") !== pl.f) m |= pl.f === 0 ? IN.RIGHT : IN.LEFT;
    if (zy + 2 < cy) m |= IN.DOWN; else if (zy > cy + 2) m |= IN.UP;
    const inZone = (cs === 0 || cs === 2) && Math.abs(cy - zy) <= 8 && (pl.f === 0 ? cx >= zx + 4 && cx - zx <= 22 : zx >= cx + 4 && zx - cx <= 22);
    if (inZone && zs === 0 && v("ZFace") === pl.f && waitT === 0) { holding = true; m = IN.FIRE_LEFT; overhold = SHOWOFF && ++charges % 4 === 0; }
    if (waitT > 0) waitT--;
    if (!holding) m = avoid(m);
  } else {
    m = IN.FIRE_LEFT;
    // keep with the chicken (only towards the facing side, so the facing stays)
    if (pl.f === 0 && zx + 4 < cx - 12) m |= IN.RIGHT;
    if (pl.f === 1 && zx > cx + 16) m |= IN.LEFT;
    if (zy + 3 < cy) m |= IN.DOWN; else if (zy > cy + 3) m |= IN.UP;
    const ch = v("ZCharge"), f = v("ZFace");
    const inZone = (cs === 0 || cs === 2) && Math.abs(cy - zy) <= 9 && (f === 0 ? cx >= zx + 3 && cx - zx <= 23 : zx >= cx + 3 && zx - cx <= 23);
    if (overhold) { if (zs !== 1) { holding = false; overhold = false; waitT = 30; } }
    else if (zs !== 1) { holding = false; }
    else if (inZone && FEAT && featStage === 1) {
      if (ch + 1 >= 43) { m = 0; holding = false; releases++; waitT = 20; }
    }
    else if (inZone && FEAT && featStage === 0) {
      let bestS = null, bestN = 0;
      for (const s of [0, -1, 1]) { const n = nearRate(ch + 1, f, s, baskets()); if (n > bestN) { bestN = n; bestS = s; } }
      if (bestN >= 4 || (ch >= 38 && bestN >= 1)) {
        m = 0;
        if (bestS === -1) m |= IN.UP; if (bestS === 1) m |= IN.DOWN;
        holding = false; releases++; waitT = 20;
      } else if (ch >= 40) { m = 0; holding = false; waitT = 30; }
    }
    else if (inZone) {
      let bestS = null, bestN = 0;
      for (const s of [0, -1, 1]) { const n = hitRate(ch + 1, f, s, baskets()); if (n > bestN) { bestN = n; bestS = s; } }
      if (bestN >= 4 || (ch >= 44 && bestN >= 1)) {
        m = 0;
        if (bestS === -1) m |= IN.UP; if (bestS === 1) m |= IN.DOWN;
        holding = false; releases++; waitT = 20;
      } else if (ch >= 46) { m = 0; holding = false; waitT = 30; }   // let go before he staggers
    } else if (ch >= 46) { m = 0; holding = false; waitT = 30; }
  }
  p.step(m);
}

// ---------------------------------------------------------------- r5.2: near misses and full-power kicks
const feat = { near: 0, power: 0, powerScores: [], nearScores: [], powerHops: [], lostDuring: 0, maxPerLineDuring: 0 };
let lastPM = 0, pmScore = 0, pmKickScore = 0, lostAt = 0, mplAt = 0;
function featWatch() {
  const pm = v("PMode");
  if (pm === 1 && lastPM === 0) { pmKickScore = v16("Score") - 1; feat.power++; }
  if (pm === 3 && lastPM === 0) { pmScore = v16("Score"); feat.near++; }
  if (pm === 2 && lastPM === 1) { pmScore = pmKickScore; }
  if (pm !== 0) { feat.maxPerLineDuring = Math.max(feat.maxPerLineDuring, maxPerLine); }
  if (pm === 0 && lastPM !== 0) {
    const d = v16("Score") - pmScore, inb = v("CState") === 3;
    if (lastPM === 2) feat.powerScores.push(inb ? d : "no basket");
    if (lastPM === 3) feat.nearScores.push(inb ? d : "no basket");
    if (inb && SHOTS) {
      const ex = k => xshots[k] ? false : (xshots[k] = true);
      if (lastPM === 2 && ex("p9")) shot("p9-power-basket");
      if (lastPM === 3 && ex("a9")) shot("a9-near-basket");
    }
    if (FEAT && lastPM === 3 && featStage === 0) featStage = 1;
    if (FEAT && lastPM === 2 && featStage === 1) featStage = 2;
  }
  if (SHOTS) {
    const ex = k => xshots[k] ? false : (xshots[k] = true);
    if (pm === 3 && v("PN") === 12 && ex("a1")) shot("a1-near-miss-landed");
    if (pm === 3 && v("PN") === 7 && ex("a2")) shot("a2-near-miss-hop");
    if (pm === 1 && v("PHops") === 3 && v("Cph") >= 6 && ex("p1")) shot("p1-power-bounce");
    if (pm === 1 && v("PHops") === 2 && v("D8") === 1 && ex("p2")) shot("p2-power-ricochet");
    if (pm === 1 && v("PHops") === 1 && v("Cph") >= 6 && ex("p3")) shot("p3-power-bounce-late");
    if (pm === 2 && v("PN") === 16 && ex("p4")) shot("p4-power-last-hop");
  }
  lastPM = pm;
}

// ---------------------------------------------------------------- the session
const menuTo = n => { for (let i = 0; i < n; i++) { p.press(IN.DOWN); p.step(0, 4); } };
p.boot();
p.step(0, 30);
shot("01-credits");
p.press(); p.step(0, 60);
recording = true;
p.step(0, 240);
shot("02-title");
p.press(); p.step(0, 30);
shot("03-menu");
if (MENUS) {
  menuTo(4); p.press(); p.step(0, 20);
  p.step(0, 30); for (const n of ["05-help1", "06-help2", "06b-help3", "06c-help4", "06d-help5"]) { shot(n); p.press(); p.step(0, 45); }
  { let n = 0; while (v("Phase") !== 3 && n < 600) { p.press(); p.step(0, 20); n++; } }
  p.step(0, 20);
  menuTo(5); p.press(); p.step(0, 30); shot("06e-secrets"); p.press(); p.step(0, 30);
  { let n = 0; while (v("Phase") !== 3 && n < 600) { p.step(0, 20); n++; } }
  p.step(0, 20);
}
p.step(0, SEED * 7);   // in the menu (it stirs the random numbers): each seed is another game
menuTo(NINJA ? 3 : ACT - 1);
p.press(); p.step(0, 50);
shot("07-level");
p.frameWatch("Phase", 1, "Tick");
const report = { levels: [], seed: SEED };
let lvl = v("Level"), lvStart = g.frame, kicksAt = v("Kicks"), hitsAt = v("Hits"), lifeLost = 0;
let shotKick = false, shotBasket = false, shotPlay = false, shotStumble = false, shotOups = false, shotOver = false;
let lastLives = v("Lives"), lastGoals = v("Goals"), done = false, over = false;
let idle = 0, alignN = 0; const alignRec = [];
const phaseLog = []; let lastPh = -1;
// ---------------------------------------------------------------- the Easter egg (--egg)
const eggReport = { triggered: false };
function goTo(tx, ty, face, max = 1500) {
  for (let i = 0; i < max; i++) {
    if (process.env.EGGDBG && i % 100 === 0) console.error("goTo", tx, ty, v("Zpx"), v("Zpy"), v("ZVx"), v("ZVy"), v("ZState"), v("Phase"));
    if (v("Phase") !== 1) return false;
    const zx = v("Zpx"), zy = v("Zpy"), zs = v("ZState");
    let m = 0;
    if (zs === 0) {
      if (zx + 2 < tx) m |= IN.RIGHT; else if (zx > tx + 2) m |= IN.LEFT;
      // line up on the spot's column first, then go up or down (round the object)
      if (Math.abs(zx - tx) <= 6) { if (zy + 2 < ty) m |= IN.DOWN; else if (zy > ty + 2) m |= IN.UP; }
      const near = Math.abs(zx - tx) <= 4 && Math.abs(zy - ty) <= 4;
      if (near && v("ZVx") === 128 && v("ZVy") === 128) {
        if (v("ZFace") !== face) { p.step(face === 0 ? IN.RIGHT : IN.LEFT); continue; }
        return true;
      }
      // brake: let the floaty speed run out near the spot
      if (near) m = 0;
      else if (Math.abs(zx - tx) <= 8 && Math.abs(zy - ty) <= 8 && (Math.abs(v("ZVx") - 128) > 3 || Math.abs(v("ZVy") - 128) > 3)) m = 0;
    }
    p.step(m);
  }
  return false;
}
function kickAir() {
  p.step(IN.FIRE_LEFT, 4); p.step(0, 1);
  for (let i = 0; i < 80 && v("ZState") !== 0 && v("Phase") === 1; i++) p.step(0);
}
function doEgg() {
  for (let i = 0; i < 600 && v("Phase") !== 1; i++) p.step(0);
  p.step(0, 10);
  const targets = [];
  if (ACT === 1) for (const lx of [48, 120, 192]) targets.push([lx - 12, 105, 0, 1]);
  else { const gx = p.arr("GvX", 1)[0] * 8, gy = p.arr("GvY", 1)[0] * 8; targets.push([gx - 8, gy + 10, 0, ACT === 2 ? 3 : 2]); }
  let tries = 0;
  for (const [tx, ty, f, n] of targets) {
    for (let k = 0; k < n && tries < 40; tries++) {
      if (v("Phase") === 5) break;
      if (!goTo(tx, ty, f)) { eggReport.fail = (eggReport.fail || 0) + 1; continue; }
      (eggReport.log = eggReport.log || []).push([g.frame, v("Zpx"), v("Zpy"), v("ZFace")]);
      const before = ACT === 1 ? v("LtHit") : ACT === 2 ? v("SnowSt") : v("FlSt");
      if (ACT !== 1 && k === n - 1) shot("egg-0-before");
      kickAir();
      const after = ACT === 1 ? v("LtHit") : ACT === 2 ? v("SnowSt") : v("FlSt");
      if (after !== before || v("Phase") === 5 || v("EggGo")) k++;
      if (ACT === 1 && k === 1 && targets.indexOf(targets.find(t => t[0] === tx)) === 2) shot("egg-0-before");
    }
  }
  for (let i = 0; i < 30 && v("Phase") !== 5; i++) p.step(0);
  if (v("Phase") === 5) {
    eggReport.triggered = true; eggReport.frame = g.frame;
    for (const at of [40, 100, 150]) { while (v("Phase") === 5 && v("EgT") < at) p.step(0); shot(`egg-${at}`); }
    while (v("Phase") === 5) p.step(0);
    p.step(0, 20);
    shot("egg-after");
    eggReport.after = { phase: v("Phase"), eggF: v("EggF"), lt: v("LtHit"), snow: v("SnowSt"), fl: v("FlSt"), tlOn: v("TlOn") };
  }
}
if (EGG) doEgg();
while (g.frame < MAXF && !done) {
  const ph = v("Phase");
  if (ph !== lastPh) { phaseLog.push([g.frame, ph, v('Level'), v('Lives')]); lastPh = ph; }
  if (ph === 1) {
    playFrame();
    featWatch();
    if (args.includes('--align') && g.frame % 37 === 0 && v('Tick') % 2 === 0 && alignN < 12) { const f = g.rgb(); alignRec.push({ n: alignN, fn: v('DFn'), fl: v('DFl'), x: v('ShX'), y: v('ShY'), rgb: Buffer.from(f.out).toString('base64') }); alignN++; }
    if (SHOTS) {
      if (!shotPlay && g.frame - lvStart > 400) { shot("08-gameplay"); shotPlay = true; }
      if (!shotKick && v("CState") === 1 && v("Cph") > 18) { shot("09-kick-arc"); shotKick = true; }
      if (!shotBasket && v("CState") === 3) { shot("10-basket"); shotBasket = true; }
      if (!shotStumble && v("ZState") === 5 && v("GTime") > 20) { shot("11-stumble"); shotStumble = true; }
      // r5: the ninja's cues, the summer show, the ice
      const ex = k => xshots[k] ? false : (xshots[k] = true);
      if (NINJA && v("NHid") === 1 && v("FpT") > 20 && v("CState") === 0 && g.frame - lvStart > 300 && ex("n1")) shot("n1-hidden-footprint");
      if (NINJA && v("NHid") === 0 && v("CState") === 0 && v("KVisT") === 0 && g.frame - lvStart > 300 && ex("n2")) shot("n2-seen-in-front");
      if (NINJA && v("CState") === 2 && v("CT") === 36 && v("FpT") > 50 && ex("n3")) shot("n3-landing-puff");
      if (ACT === 3 && v("WShow") === 1 && v("WTimer") === 40 && ex("s1")) shot("s1-water-far");
      if (ACT === 3 && v("WShow") === 2 && v("WTimer") === 40 && ex("s2")) shot("s2-water-near");
      if (ACT === 3 && v("PanicT") === 60 && ex("s3")) shot("s3-chicken-panic");
      if (ACT === 3 && v("ZState") === 3 && v("WShow") !== 0 && v("ZT") === 20 && ex("s4")) shot("s4-zombie-spins");
      if (ACT === 2 && v("Wet") === 1 && v("CState") === 0 && ex("i1")) shot("i1-chicken-on-ice");
      if (ACT === 2 && v("Level") >= 2 && v("NGv") >= 2 && ex("i2")) shot("i2-snowman-sled");
    }
    if (v("Goals") !== lastGoals) { lastGoals = v("Goals"); }
  } else if (ph === 4) {
    // the close-up: wait for the card, then press
    if (SHOTS && !shotOups && v("GagN") >= 1 && v("GagN") <= 2) { p.step(0); shot("12-closeup"); shotOups = "c"; }
    const big = v("GagBig");
    if (v("Cnt") >= 30 && v("Cnt") < 40) {
      if (SHOTS && big === 0 && shotOups !== true) { shot("13-oups"); shotOups = true; }
      if (SHOTS && big === 1 && !shotOver) { shot("14-game-over"); shotOver = true; }
    }
    p.step(0);
    if (v("Cnt") > 60) p.step(IN.FIRE_LEFT, 2);
  } else {
    // panels between levels, the end of act I, the title after a game over
    p.step(0, 2);
    if (v("Level") !== lvl || ph === 2) {
      report.levels.push({ level: lvl, frames: g.frame - lvStart, kicks: v("Kicks") - kicksAt, hits: v("Hits") - hitsAt, score: v16("Score"), lives: v("Lives") });
      lvl = v("Level"); lvStart = g.frame; kicksAt = v("Kicks"); hitsAt = v("Hits");
    }
    if (ph === 2) { over = true; done = true; break; }
    const pc = g.core.getPc();
    // a pause (act done, game over): press after a while
    if (++idle % 45 === 0) p.press();
  }
  if (v("Lives") < lastLives) { lastLives = v("Lives"); lifeLost++; }
  // the act is done when the menu comes back after level 6
  if (ph === 3 && report.levels.length > 0) { done = true; }
}
if (v("Phase") === 3 && lvl === 6) report.levels.push({ level: 6, frames: g.frame - lvStart, kicks: v("Kicks") - kicksAt, hits: v("Hits") - hitsAt, score: v16("Score"), lives: v("Lives") });
recording = false;
report.end = { phase: v("Phase"), level: v("Level"), score: v16("Score"), lives: v("Lives"), livesLost: lifeLost, gameOver: over };
report.lost = p.lost();
report.feat = feat; report.botStalls = stalls;
report.egg = { ...eggReport, frames: eggFrames, lost: eggLost };
report.act = ACT; report.ninja = NINJA; report.eggF = v("EggF");
report.sprites = { framesChecked: satFrames, maxPerLine, linesOver4: overLines, vis: visReport() };
report.frames = g.frame;
if (PROF) { report.profile = PROF.report(); report.worst = PROF.worst(); report.bigNmi = globalThis.bigNmi; }
if (args.includes('--debug')) report.consecLog = consecLog, report.overLog = overLog, report.phases = phaseLog;
if (VDP) {
  const r = p.vdpReport();
  report.vdp = { timingModel: r.timingModel, shadowMismatchFrames: r.shadowMismatchFrames, chained: r.chained, nmiDeferred: r.nmiDeferred, tight: r.tightMidScreenByPc, drops: r.drops, misdirected: r.misdirected, misdirectedByPc: r.misdirectedByPc, dropsByPhase: r.dropsByPhase, minGapDisplay: r.minGapDisplay, satFramesBad: r.satFramesBad };
}
if (SHOTS) report.shots = shots;
if (SHB) report.shb = shbLog; report.events = events; if (alignRec.length) report.align = alignRec; report.lostInfo = lostInfo;
const evc = {}; for (const [k] of events) evc[k] = (evc[k] || 0) + 1; report.eventCounts = evc;
if (args.includes("--checkspr")) {
  // the shown sprite buffer against the frame data (mirrored when facing left)
  const z = readFileSync(path.join(path.dirname(base), "zframes.asm"), "utf8");
  const frames = {}; let cur = null;
  for (const line of z.split("\n")) {
    const mm = line.match(/^ZFr(\d+):/); if (mm) { cur = +mm[1]; frames[cur] = []; continue; }
    if (/^\w/.test(line)) cur = null;
    const db = line.match(/^\s+db (.*)$/); if (db && cur !== null) frames[cur].push(...db[1].split(",").map(x => parseInt(x.replace("$", ""), 16)));
  }
  const dec = enc => { const o = []; for (let i = 0; i < enc.length && o.length < 128;) { if (enc[i] === 0) { for (let k = 0; k < enc[i + 1]; k++) o.push(0); i += 2; } else o.push(enc[i++]); } return o; };
  const rev = b => parseInt(b.toString(2).padStart(8, "0").split("").reverse().join(""), 2);
  const fn = v("DFn"), fl = v("DFl"), slot = v("ZSlot");
  const raw = dec(frames[fn]);
  const want = fl ? raw.map((b, i) => rev(raw[(i & ~31) | ((i & 31) ^ 16)])) : raw;
  const got = Array.from(p.g.core.readVram(0x3800 + slot * 128, 128));
  report.sprCheck = { fn, fl, slot, diffs: want.reduce((n, b, i) => n + (b !== got[i]), 0) };
}
if (args.includes("--dumpcells")) { report.cells = p.arr("CellOrig", 25); report.tl = ["TlCx","TlCy","TlNsx","TlNsy","TlNb","TlRmin","TlRmax","Zpx","Zpy","ZFn","ZFlip"].map(k => [k, v(k)]); }
if (args.includes("--endshot")) { p.shot("zz-end"); report.botState = { holding, waitT, detour, overhold, featStage }; report.endState = Object.fromEntries(["ZVx","ZVy","IL","IR","IU","IDn","IB","ZCharge","PMode","Zpx","Zpy","Cpx","Cpy","CState","ZState","CT","CDir","CGx","CGy","Goals","Dizzy"].map(k => [k, v(k)])); }
say(JSON.stringify(report, null, 1));
if (ff) { ff.stdin.end(); await new Promise(r => ff.on("close", r)); }
