# shbcheck.py - checks ShBuf dumps (bot.mjs --shbuf) byte for byte against a
# model of tl_shbuf built from the dark rows in build/zframes.asm.
#   python3 tests/shbcheck.py dump.json [...]
# Model: each dark row (nb bytes, mirrored = the whole row's bits reversed)
# starts at pixel TlNsx of a 40-pixel row; column c of ShBuf (48 bytes, canvas
# row r at byte r + 8) holds pixels 8c..8c+7.
import json, re, sys
z = open('build/zframes.asm').read()
rows = {}
for m in re.finditer(r'^ZDk(\d+):\n((?:\s+db .*\n)+)', z, re.M):
    b = [int(v.strip().lstrip('$'), 16) for v in re.findall(r'\$[0-9A-Fa-f]+', m.group(2))]
    rows[int(m.group(1))] = b
def model(fn, fl, s):
    b = rows[fn]; r0, n, nb = b[0], b[1], b[2]; d = b[3:]
    buf = [0] * 240
    for i in range(n):
        bits = ''.join(f'{v:08b}' for v in d[i * nb:(i + 1) * nb])
        if fl: bits = bits[::-1]
        line = ('0' * s + bits).ljust(40, '0')
        for c in range(5):
            buf[c * 48 + r0 + i + 8] = int(line[c * 8:c * 8 + 8], 2)
    return buf, nb
tot = bad = 0; seen = set()
for f in sys.argv[1:]:
    for fr, fn, fl, s, data in json.load(open(f)).get('shb', []):
        got = [int(v) for v in data.split(',')]
        exp, nb = model(fn, fl, s)
        tot += 1; seen.add((nb, fl, s >= 5))
        if got != exp:
            bad += 1
            if bad < 4: print('mismatch', f, fr, fn, fl, s)
print(f'{tot} dumps, {bad} mismatches; cases (nb, mirrored, left path): {sorted(seen)}')
