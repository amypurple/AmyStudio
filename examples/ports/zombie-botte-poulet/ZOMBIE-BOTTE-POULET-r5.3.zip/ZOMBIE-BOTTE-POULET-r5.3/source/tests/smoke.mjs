// smoke.mjs - boot, credits, title, menu, help, level 1 (screenshots in tests/smoke)
import path from "node:path";
import { openPort, IN } from "../common/test/portlib.mjs";
const p = await openPort(path.resolve("build/zombie-botte-poulet"), { outDir: path.resolve("tests/smoke") });
p.boot(); p.step(0, 60); p.shot("s0-credits");
p.press(); p.step(0, 120); p.shot("s1-title"); console.log("phase", p.get("Phase"));
p.step(0, 200); p.shot("s1b-title");
p.press(); p.step(0, 40); p.shot("s2-menu"); console.log("phase", p.get("Phase"));
p.press(IN.DOWN); p.step(0,10); p.press(); p.step(0,30); p.shot("s2b-soon");
p.press(IN.DOWN); p.press(IN.DOWN); p.step(0,10); p.press(); p.step(0, 40); p.shot("s3-help1");
p.press(); p.step(0, 40); p.shot("s3-help2"); p.press(); p.step(0, 40);
p.press(); p.step(0, 60); p.shot("s4-ready");
p.step(0, 120); p.shot("s5-play"); console.log("phase", p.get("Phase"), "Zpx", p.get("Zpx"), p.get("Zpy"), "C", p.get("Cpx"), p.get("Cpy"));
p.step(IN.RIGHT, 40); p.shot("s6-walk");
p.step(IN.FIRE_LEFT, 20); p.step(0, 6); p.shot("s7-kick"); console.log("ZState", p.get("ZState"), "Dizzy", p.get("Dizzy"));
