// poses.mjs - screenshots of the zombie in set places (test aid, writes RAM).
//   node tests/poses.mjs [--act N] [--dump] [--out dir] [--cases JSON]
// Plays to a level, then holds the zombie (and the chicken) where each case
// wants them by writing their positions every frame, lets the 30 Hz display
// catch up and takes a picture. --dump prints the level's name table rows 8-21.
import path from "node:path";
import { openPort, IN } from "../common/test/portlib.mjs";

const args = process.argv.slice(2);
const opt = (k, d) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : d; };
const outDir = path.resolve(opt("--out", "tests/poses"));
const p = await openPort(path.resolve("build/zombie-botte-poulet"), { outDir });
const g = p.g, c = g.core;
const asm = (await import("node:fs")).readFileSync("build/zombie-botte-poulet.asm", "utf8");
const addr = n => parseInt(asm.match(new RegExp(`^AMY_UVAR_${n}\\s+EQU\\s+\\$([0-9A-Fa-f]{4})`, "m"))[1], 16);
const put = (n, v) => c.writeRam(addr(n), Uint8Array.from([v & 255]));
const put16 = (n, v) => c.writeRam(addr(n), Uint8Array.from([v & 255, (v >> 8) & 255]));

// to the menu, then a new game
p.boot(); p.step(0, 60); p.press(); p.step(0, 120);
p.until(() => p.get("Phase") === 3, 2000, 0) || (p.press(), p.step(0, 60));
for (let i = 0; i < 40 && p.get("Phase") !== 3; i++) { p.press(); p.step(0, 20); }
// r5: --act N picks the act in the menu
for (let i = 1; i < +opt("--act", 1); i++) { p.press(IN.DOWN); p.step(0, 4); }
p.press(); p.until(() => p.get("Phase") === 1, 2000);
p.step(0, 30);

const level = n => {           // jump to level n through the game's own level start
  while (p.get("Level") < n) {
    put("Goals", 0); put("GMode", 1); put("GTime", 89);
    p.until(() => p.get("Phase") === 0, 600); p.until(() => p.get("Phase") === 1, 2000, 0);
    // the "bravo" panel waits for a press after 50 frames
    for (let i = 0; i < 30 && p.get("Phase") !== 1; i++) { p.press(); p.step(0, 10); }
    p.step(0, 30);
  }
};
const dump = () => {
  const nt = c.readVram(0x1800, 768);
  for (let r = 8; r < 22; r++) console.log(String(r).padStart(2), Array.from(nt.slice(r * 32, r * 32 + 32)).map(v => String(v).padStart(3)).join(""));
};
// hold the zombie at (zx, zy) facing f, the chicken at (cx, cy) or where it is
const hold = (name, zx, zy, f, cx, cy, n = 12) => {
  for (let i = 0; i < n; i++) {
    put16("ZX", zx * 16); put16("ZY", zy * 16); put("Zpx", zx); put("Zpy", zy); put("ZVx", 128); put("ZVy", 128); put("ZFace", f);
    if (cx !== undefined) { put16("CX", cx * 16); put16("CY", cy * 16); put("Cpx", cx); put("Cpy", cy); put("CVx", 128); put("CVy", 128); put("Cph", 0); }
    p.step(0, 1);
  }
  console.log(name, "Zpx", p.get("Zpx"), "Zpy", p.get("Zpy"), "TlTop", p.get("TlTop"), "TlBot", p.get("TlBot"), "TlNl", p.get("TlNl"));
  p.shot(name);
};

const cases = JSON.parse(opt("--cases", "[]"));
// --fallsweep: trips the zombie, holds a fall pose (GTime) and moves him one
// pixel every 2 frames, both ways; ShBuf dumps after each phase B (for
// tests/shbcheck.py: the tl_shbuf fast paths, shifts 0-7, mirrored or not)
if (args.includes("--fallsweep")) {
  const shb = [];
  put("Dizzy", 250); p.step(0, 2);
  for (const gt of [20, 30]) for (const f of [0, 1]) for (let i = 0; i < 48; i++) {
    put("GTime", gt); put("ZFace", f); put16("ZX", (100 + (i >> 1)) * 16); put("Zpx", 100 + (i >> 1)); put("ZVx", 128);
    p.step(0, 1);
    if (p.get("ZPhase") === 0 && p.get("ZReady") === 0 && p.get("ZUplC") === 0 && p.get("TlValid") === 1)
      shb.push([g.frame, p.get("TlF"), p.get("TlFl"), p.get("TlSx"), g.getArray("ShBuf", 240).join(",")]);
  }
  (await import("node:fs")).writeFileSync(path.join(outDir, "fallsweep.json"), JSON.stringify({ shb }));
  console.log("fallsweep dumps", shb.length, "GMode", p.get("GMode"), "ZState", p.get("ZState"));
  process.exit(0);
}
if (args.includes("--dump")) { level(+opt("--level", 1)); dump(); process.exit(0); }
for (const k of cases) {
  level(k.lv);
  hold(k.name, k.zx, k.zy, k.f || 0, k.cx, k.cy, k.n || 12);
}
