#!/bin/sh
# r5.3 resumable checks: each step leaves tests/logs/step-NAME.ok
cd "$(dirname "$0")/.."
R=build/zombie-botte-poulet; T="timeout 480"
st() { [ -f tests/logs/step-$1.ok ] && return; shift2=$1; }
run() { n=$1; shift; [ -f tests/logs/step-$n.ok ] && return 0; sh -c "$*" && touch tests/logs/step-$n.ok; }
run a1 "rm -rf tests/out; $T node tests/bot.mjs $R --act 1 --seed 4 --vdp --shots --menus --showoff --video tests/out/gameplay-full.mp4 > tests/logs/bot-act1-seed4-vdp.json"
run a2 "rm -rf tests/out-act2; $T node tests/bot.mjs $R --act 2 --seed 4 --vdp --shots --out tests/out-act2 > tests/logs/bot-act2-seed4-vdp.json"
run a3 "rm -rf tests/out-act3; $T node tests/bot.mjs $R --act 3 --seed 4 --vdp --shots --out tests/out-act3 > tests/logs/bot-act3-seed4-vdp.json"
run nj "rm -rf tests/out-ninja; $T node tests/bot.mjs $R --ninja --seed 4 --vdp --shots --out tests/out-ninja > tests/logs/bot-ninja-seed4-vdp.json"
run cl "rm -rf tests/out-clumsy; $T node tests/bot.mjs $R --seed 4 --vdp --shots --clumsy --out tests/out-clumsy > tests/logs/bot-clumsy-vdp.json"
run cut "$T python3 tests/cutvideo.py tests/logs/bot-act1-seed4-vdp.json tests/out/gameplay-full.mp4 tests/out/gameplay-highlights.mp4"
for a in 1 2 3; do run egg$a "rm -rf tests/out-egg$a; $T node tests/bot.mjs $R --act $a --egg --shots --seed 1 --vdp --max-frames 16000 --out tests/out-egg$a > tests/logs/bot-egg$a.json"; done
run shb "$T sh tests/run.sh shb"
run core "$T sh tests/run.sh core"
for m in "act 1" "act 2" "act 3" "ninja"; do t=$(echo $m | tr -d ' '); a=$(echo "--$m"); for s in 1 2 3 4 5 6 7 8 9; do run $t-s$s "$T node tests/bot.mjs $R $a --seed $s --out tests/out-s > tests/logs/bot-$t-seed$s.json"; done; done
rm -rf tests/out-s
for m in "--act 1:act1" "--act 2:2" "--act 3:3" "--ninja:ninja"; do a=${m%%:*}; t=${m##*:}; run feat$t "rm -rf tests/out-feat$t; $T node tests/bot.mjs $R $a --seed 1 --feat --shots --vdp --out tests/out-feat$t > tests/logs/bot-feat-$t.json"; done
echo CHECKSDONE
