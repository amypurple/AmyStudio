"""highlights.py OUT.mp4 REPORT.json:FULL.mp4:KIND,KIND... [...] - one highlights
video from several bot games (r5: the three acts, the ninja mode, the eggs).
For each game, 6 s round the first event of each listed kind (the bot's
event list: kick, spin, stagger, zombie-bonk, chicken-ricochet, egg, water,
...); 'start' is the first 6 s of play. Events closer than 7 s are skipped."""
import json, subprocess, sys, tempfile, os
out = sys.argv[1]
tmp = tempfile.mkdtemp()
parts = []
for spec in sys.argv[2:]:
    rep, full, kinds = spec.split(':')
    ev = json.load(open(rep))['events']            # [kind, video frame, level]
    picks = []
    for kind in kinds.split(','):
        if kind == 'start':
            f0 = next((f for k, f, lv in ev), 300)
            picks.append(max(0, f0 - 120) + 180)
            continue
        if kind.endswith('+'):                     # a later one (level 2 and up)
            kind = kind[:-1]
            cand = [f for k, f, lv in ev if k == kind and lv >= 2]
        else:
            cand = [f for k, f, lv in ev if k == kind]
        for f in cand:
            if all(abs(f - q) > 420 for q in picks):
                picks.append(f)
                break
    picks.sort()
    for f in picks:
        dur = 6.0
        if any(k == 'egg' and abs(fe - f) < 2 for k, fe, lv in ev):
            dur = 5.0
            ss = f / 60 - 1.0
        else:
            ss = max(0, f / 60 - 3.0)
        pth = os.path.join(tmp, f'p{len(parts)}.mp4')
        subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-ss', f'{ss:.2f}', '-i', full, '-t', f'{dur}',
                        '-c:v', 'libx264', '-crf', '20', '-pix_fmt', 'yuv420p', '-an', pth], check=True)
        parts.append(pth)
    print(f"highlights: {rep}: events at video frames {picks}")
lst = os.path.join(tmp, 'list.txt')
open(lst, 'w').write(''.join(f"file '{p}'\n" for p in parts))
subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-f', 'concat', '-safe', '0', '-i', lst, '-c', 'copy', out], check=True)
print(f"highlights: {len(parts)} parts -> {out}")
