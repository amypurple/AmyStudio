# zombie.py - the zombie's animation, made the stick-figure way (Amy & Claude 2026).
#
# A skeleton (hip, knees, feet, shoulders, elbows, hands, neck, head) is posed by
# a few keyframes per animation; the in-betweens are interpolated; then the
# costume is drawn onto the skeleton for every frame. r3: a taller body that
# fills the 16x32 sprite pair, a dark outline all round, a big green face with
# hollow eyes and crooked teeth, white stringy hair with a dark line between it
# and the face, a dark chest panel with clear white ribs, a torn tan costume
# with visible rips, white bony hands and feet.
#
# Drawing: a 48 x 32 canvas, facing right, the hip near x 16, the feet on row 31.
# Each half (rows 0-15, rows 16-31) is shown by two 16x16 sprites (two colour
# layers); the dark layer (black: outline, eyes, mouth, chest panel, rips) is a
# 32x32 bitmap drawn by the game into background tiles (r4), and two colour layers
# (top: white hair/teeth + green face/hands; bottom: tan costume + white
# ribs/hands/feet). Each half picks its own 16-column window of the canvas
# (dx = window start - 8), so a long kick or the fall forward still fits.
#
#   import zombie; frames, starts, counts = zombie.build()
#   python3 zombie.py OUTDIR       # writes the 4x sheets (PNG)
import math, os, sys

CW, H = 48, 32
HIPX = 16
COLV = {'k': 1, 'w': 15, 'g': 3, 'y': 10}
RGB = {'w': (255, 255, 255), 'g': (94, 220, 120), 'y': (212, 193, 84), 'k': (0, 0, 0), '.': None}

# bone lengths (pixels): a taller body than r2
TORSO, NECK, THIGH, SHIN, UPPER, FORE = 8.0, 5.2, 5.0, 4.6, 3.4, 3.0
HEAD_RX, HEAD_RY = 4.6, 5.2


class Pose(dict):
    """hx hy (hip, in r2 units: 7.5 / 23.5 = standing), lean (deg, + forward), head
    (deg), yaw (0 = facing right, 90 = facing the viewer), tn kn tf kf (thigh angle
    from vertical, + forward; knee bend; n near, f far leg), an en af ef (shoulder
    angle: 0 down, 90 forward, 180 up; elbow bend), spread (arms out), hair (sway),
    tip (deg: the whole body tips forward round the feet, for the fall)"""
    KEYS = dict(hx=7.5, hy=23.5, lean=8, head=0, yaw=0, tn=0, kn=0, tf=0, kf=0, an=80, en=0, af=80, ef=0,
                spread=0, hair=0, tip=0)

    def __init__(self, **kw):
        super().__init__(Pose.KEYS)
        self.update(kw)


def lerp(p, q, t):
    return Pose(**{k: p[k] + (q[k] - p[k]) * t for k in Pose.KEYS})


def inbetween(keys, n, loop=True):
    """n frames from keyframes spread evenly (loop: the last eases back to the first)"""
    out = []
    seg = len(keys) if loop else len(keys) - 1
    for i in range(n):
        u = i * seg / n if loop else i * seg / (n - 1)
        j = min(int(u), seg - 1) if not loop else int(u)
        t = u - j
        t = t * t * (3 - 2 * t)                      # ease in and out
        out.append(lerp(keys[j % len(keys)], keys[(j + 1) % len(keys)], t))
    return out


def joints(P):
    """the skeleton in body space (f forward from the hip, y down, z towards the viewer)"""
    rad = math.radians
    hipy = 21.6 + (P['hy'] - 23.5) * 1.2
    hip = (0.0, hipy, 0.0)
    L = rad(P['lean'])
    sh = (TORSO * math.sin(L), hipy - TORSO * math.cos(L), 0.0)
    hd = L + rad(P['head'])
    head = (sh[0] + NECK * math.sin(hd), sh[1] - NECK * math.cos(hd), 0.0)
    J = dict(hip=hip, sh=sh, head=head)
    for s, z in (('n', 1.4), ('f', -1.4)):
        th, kb = rad(P['t' + s]), rad(P['k' + s])
        knee = (THIGH * math.sin(th), hipy + THIGH * math.cos(th), z)
        sa = th - kb
        foot = (knee[0] + SHIN * math.sin(sa), knee[1] + SHIN * math.cos(sa), z)
        J['hip' + s] = (0.0, hipy, z)
        J['knee' + s], J['foot' + s] = knee, foot
    for s, z in (('n', 3.0), ('f', -3.0)):
        a, e = rad(P['a' + s]), rad(P['e' + s])
        zz = z * (1 + P['spread'])
        sho = (sh[0], sh[1] + 2.4, z)
        elb = (sho[0] + UPPER * math.sin(a), sho[1] + UPPER * math.cos(a), (z + zz) / 2)
        hand = (elb[0] + FORE * math.sin(a + e), elb[1] + FORE * math.cos(a + e), zz)
        J['sho' + s], J['elb' + s], J['hand' + s] = sho, elb, hand
    # the fall: everything turns forward round the feet (pivot at the near foot level)
    if P['tip']:
        t = rad(P['tip'])
        px, py = 0.0, 31.0
        for k, (f, y, z) in list(J.items()):
            dx, dy = f - px, y - py
            J[k] = (px + dx * math.cos(t) - dy * math.sin(t), py + dx * math.sin(t) + dy * math.cos(t), z)
    return J


def project(P, p):
    yaw = math.radians(P['yaw'])
    f, y, z = p
    hx = HIPX + (P['hx'] - 7.5) * 1.2
    return hx + f * math.cos(yaw) + z * math.sin(yaw), y, -f * math.sin(yaw) + z * math.cos(yaw)


class Canvas:
    """labels per pixel (semantic: the colour is chosen per half later)"""
    def __init__(self):
        self.c = [['.'] * CW for _ in range(H)]

    def px(self, x, y, lab):
        x, y = int(math.floor(x + 0.5)), int(math.floor(y + 0.5))
        if 0 <= x < CW and 0 <= y < H:
            self.c[y][x] = lab

    def get(self, x, y):
        x, y = int(math.floor(x + 0.5)), int(math.floor(y + 0.5))
        return self.c[y][x] if 0 <= x < CW and 0 <= y < H else '.'

    def seg(self, a, b, r, lab):
        x0, x1 = int(min(a[0], b[0]) - r - 1), int(max(a[0], b[0]) + r + 2)
        y0, y1 = int(min(a[1], b[1]) - r - 1), int(max(a[1], b[1]) + r + 2)
        dx, dy = b[0] - a[0], b[1] - a[1]
        ll = dx * dx + dy * dy or 1e-9
        for yy in range(max(0, y0), min(H, y1)):
            for xx in range(max(0, x0), min(CW, x1)):
                t = max(0, min(1, ((xx - a[0]) * dx + (yy - a[1]) * dy) / ll))
                ex, ey = a[0] + t * dx - xx, a[1] + t * dy - yy
                if ex * ex + ey * ey <= r * r:
                    self.c[yy][xx] = lab


# labels: H hair, F face, E eye/mouth (dark), W teeth, T torso costume, P chest
# panel (dark), R rib, A arm costume, N hand, L leg costume, S foot, X rip (dark)
DARK = set('EPX')


def render(P, shades=False):
    J = joints(P)
    S = {k: project(P, v) for k, v in J.items()}
    yaw = math.radians(P['yaw'])
    fx, fz = math.cos(yaw), math.sin(yaw)
    tip = math.radians(P['tip'])
    cv = Canvas()
    parts = []

    def along(a, b, t):
        return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)

    def leg(s):
        def draw():
            hp, kn, ft = S['hip' + s], S['knee' + s], S['foot' + s]
            cv.seg(hp, kn, 1.45, 'L')
            cv.seg(kn, ft, 1.15, 'L')
            # rips: a dark slit across the thigh and one at the shin, a ragged hem
            r1 = along(hp, kn, 0.55)
            cv.px(r1[0], r1[1], 'X')
            cv.px(r1[0] + 0.9, r1[1] + 0.4, 'X')
            r2 = along(kn, ft, 0.55)
            cv.px(r2[0] - 0.5, r2[1], 'X')
            cv.px(ft[0] - fx * 1.0, ft[1] - 1.0, '.')
            # the bony foot, pointing forward
            dirx = fx * math.cos(tip) if abs(fx) > 0.2 else 0.0
            cv.seg((ft[0] - dirx * 0.4, ft[1] + 0.2), (ft[0] + dirx * 2.0 + (0 if abs(fx) > 0.2 else 0.8), ft[1] + 0.2), 0.6, 'S')
        return (S['knee' + s][2] + S['foot' + s][2]) / 2, draw

    def arm(s):
        def draw():
            so, el, ha = S['sho' + s], S['elb' + s], S['hand' + s]
            cv.seg(so, el, 1.2, 'A')
            cv.seg(el, ha, 1.0, 'A')
            r = along(so, el, 0.6)                    # a rip in the sleeve
            cv.px(r[0], r[1], 'X')
            # a bony hand with fingers
            dx, dy = ha[0] - el[0], ha[1] - el[1]
            n = math.hypot(dx, dy) or 1
            ux, uy = dx / n, dy / n
            cv.seg(ha, (ha[0] + ux * 1.6, ha[1] + uy * 1.6), 0.9, 'N')
            cv.px(ha[0] + ux * 2.6 - uy * 0.8, ha[1] + uy * 2.6 + ux * 0.8, 'N')
            cv.px(ha[0] + ux * 2.6 + uy * 0.8, ha[1] + uy * 2.6 - ux * 0.8, 'N')
        return S['hand' + s][2] + 0.3, draw

    def torso():
        hp, sh = S['hip'], S['sh']
        width = 3.0 + 1.0 * abs(fz)
        cv.seg(hp, sh, width, 'T')
        # torn hem: two notches at the bottom
        for d in (-1.8, 1.4):
            cv.px(hp[0] + d, hp[1] + 2.4, '.')
        cv.px(hp[0] - 0.4, hp[1] + 1.6, 'X')
        # the chest panel (dark) with white ribs and the spine, on the side facing us
        if fz > -0.4:
            ax, ay = sh[0] - hp[0], sh[1] - hp[1]
            ln = math.hypot(ax, ay) or 1
            ux, uy = ax / ln, ay / ln                 # up the spine
            nx, ny = -uy, ux                          # across
            front = 1 if abs(fz) > 0.5 else 0
            off = 0.0 if front else fx * 0.9          # seen from the side the panel is on the chest
            half = (2.2 if front else 1.4)
            for k in range(1, 7):                     # panel rows from just under the shoulders
                t = 0.25 + k * 0.11
                cx = sh[0] - ux * ln * (t - 0.12) + nx * off
                cy = sh[1] - uy * ln * (t - 0.12) + ny * off
                for j in range(-3, 4):
                    q = j * 0.75
                    if abs(q) <= half:
                        rib = k % 2 == 0 and (front == 0 or abs(q) > 0.5)
                        spine = front and abs(q) <= 0.4 and k < 6
                        cv.px(cx + nx * q, cy + ny * q, 'R' if (rib or spine) else 'P')
    parts.append((0.0, torso))

    def head():
        hx, hy = S['head'][0], S['head'][1]
        rx, ry = HEAD_RX, HEAD_RY
        sway = P['hair']
        inside = lambda xx, yy: ((xx - hx) / rx) ** 2 + ((yy - hy) / ry) ** 2 <= 1.0
        for yy in range(int(hy - ry) - 1, int(hy + ry) + 2):
            for xx in range(int(hx - rx) - 1, int(hx + rx) + 2):
                if inside(xx, yy):
                    cv.px(xx, yy, 'H')
        # the face: the part of the head turned to its forward side, below the hairline
        face = set()
        if fz > -0.6:
            for yy in range(int(hy - ry) - 1, int(hy + ry) + 2):
                for xx in range(int(hx - rx) - 1, int(hx + rx) + 2):
                    u, v = (xx - hx) / rx, (yy - hy) / ry
                    if u * u + v * v > 1.0 or v < -0.35:
                        continue
                    zs = math.sqrt(max(0.0, 1 - u * u - v * v))
                    if u * fx + zs * fz > -0.25:
                        cv.px(xx, yy, 'F')
                        face.add((xx, yy))
            # a dark line between the hair and the face
            for (xx, yy) in list(face):
                if cv.get(xx, yy - 1) == 'H':
                    cv.px(xx, yy - 1, 'E')
            for (xx, yy) in list(face):
                if (xx - fx, yy) not in face and cv.get(xx - (1 if fx > 0 else -1), yy) == 'H' and abs(fz) < 0.5:
                    cv.px(xx - (1 if fx > 0 else -1), yy, 'E')
            # hollow eyes (2 tall) and a crooked grin
            for side in (-0.55, 0.55):
                ang = yaw + side
                if math.sin(ang) > -0.3:
                    ex = hx + math.cos(ang) * rx * 0.55
                    cv.px(ex, hy - 0.2, 'E')
                    cv.px(ex, hy + 0.8, 'E')
            mx = hx + (0 if abs(fz) > 0.5 else fx * rx * 0.4)
            wdt = 2 if abs(fz) > 0.5 else 1
            my = hy + 2.8
            for j in range(-wdt, wdt + 2):
                cv.px(mx + j, my, 'E')
            for j, dy in zip(range(-wdt, wdt + 2), (0, -1, 0, 1, -1, 0)):
                if j % 2 == 0:
                    cv.px(mx + j, my + (0.0 if dy >= 0 else -0.0) + (1 if dy > 0 else 0) * 0, 'W')
            cv.px(mx - wdt + 1, my + 1, 'W')            # one tooth sticks out below
            if shades:
                # r5, act III: sunglasses, a dark band two rows tall across the
                # face at the eyes (with a temple towards the ear)
                for yy in (int(math.floor(hy - 0.2 + 0.5)), int(math.floor(hy + 0.8 + 0.5))):
                    for (xx, y2) in face:
                        if y2 == yy:
                            cv.px(xx, yy, 'E')
                ey = int(math.floor(hy - 0.2 + 0.5))
                if abs(fz) < 0.5:
                    cv.px(hx - fx * rx * 0.2, ey, 'E')
                    cv.px(hx - fx * rx * 0.5, ey, 'E')
        # stringy hair: strands hanging down behind and at the sides, swinging
        back = -fx
        for k, u in enumerate((-1.0, -0.6, -0.2, 0.2, 0.6, 1.0)):
            x0 = hx + u * rx * 0.9 + back * 0.5 * (1 - abs(fz))
            if fz > 0.5 and abs(u) < 0.7:
                continue                               # the face, seen from the front
            ln = 5 + (k * 3) % 4
            for j in range(ln):
                if (j + k) % 4 == 3:
                    continue
                cv.px(x0 + sway * j / ln * 1.5, hy + ry * 0.2 + j, 'H')
        # spiky top of the hair
        for j in (-2, 0, 2):
            cv.px(hx + j + sway * 0.5, hy - ry - 0.6, 'H')
    parts.append((0.5, head))

    for s in 'nf':
        parts.append(leg(s))
        parts.append(arm(s))
    for _, fn in sorted(parts, key=lambda q: q[0]):
        fn()
    # the outline: every empty pixel next (4-way) to the figure
    lab = [row[:] for row in cv.c]
    for yy in range(H):
        for xx in range(CW):
            if lab[yy][xx] != '.':
                continue
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                x2, y2 = xx + dx, yy + dy
                if 0 <= x2 < CW and 0 <= y2 < H and cv.c[y2][x2] not in ('.', 'O'):
                    lab[yy][xx] = 'O'
                    break
    return lab, S


# label -> colour, per half; the fall frames may pick other colours (see bands)
TOPMAP = dict(H='w', F='g', E='k', W='w', T='k', P='k', R='w', A='g', N='g', L='g', S='w', X='k', O='k')
BOTMAP = dict(H='w', F='y', E='k', W='w', T='y', P='k', R='w', A='y', N='w', L='y', S='w', X='k', O='k')


def bands(lab, free=False, force=None):
    """two halves: choose each half's 16-column window and its colours; returns
    rows (48 wide letters, for the sheets), per half (dx, (c1, c2), [16 rows of 16])"""
    halves = []
    rows = [['.'] * CW for _ in range(H)]
    for r0, mp in ((0, TOPMAP), (16, BOTMAP)):
        mp = dict(mp)
        if free:
            # the fall: the head comes down into the bottom half: keep its face green
            cnt = {}
            for yy in range(r0, r0 + 16):
                for ch in lab[yy]:
                    if ch not in '.O':
                        cnt[ch] = cnt.get(ch, 0) + 1
            if cnt.get('F', 0) >= 6 and r0 == 16:
                mp.update(F='g', T='y', A='y', L='y', N='g', S='g', R='g', H='y', W='g')
        cols = []
        for yy in range(r0, r0 + 16):
            for xx in range(CW):
                ch = lab[yy][xx]
                if ch != '.':
                    c = mp[ch]
                    rows[yy][xx] = c
                    if c != 'k' and c not in cols:
                        cols.append(c)
        order = [c for c in ('w', 'g', 'y') if c in cols]
        assert len(order) <= 2, (r0, order)
        while len(order) < 2:
            order.append([c for c in ('w', 'g', 'y') if c not in order][0])
        # the window: the 16 columns that hold the most of the coloured figure
        # (the dark layer is drawn with background tiles, r4: it has no window)
        best, bx = -1, 8
        for x0 in (range(0, CW - 15) if force is None else [force[0][len(halves)] + 8]):
            n = sum(1 for yy in range(r0, r0 + 16) for xx in range(x0, x0 + 16) if rows[yy][xx] not in '.k')
            if n > best or (n == best and abs(x0 - 8) < abs(bx - 8)):
                best, bx = n, x0
        lost = sum(1 for yy in range(r0, r0 + 16) for xx in range(CW) if rows[yy][xx] not in '.k' and not bx <= xx < bx + 16)
        win = [''.join(c if c != 'k' else '.' for c in rows[yy][bx:bx + 16]) for yy in range(r0, r0 + 16)]
        halves.append((bx - 8, tuple(order), win, lost))
    # the dark layer (canvas columns 0-31): the outline and dark details, plus
    # any coloured pixel its half's window cannot show (so a long kick or the
    # fall keeps its silhouette, drawn black)
    on = [[False] * CW for _ in range(H)]
    for yy in range(H):
        bxh = halves[0 if yy < 16 else 1][0] + 8
        for xx in range(CW):
            c = rows[yy][xx]
            on[yy][xx] = c == 'k' or (c != '.' and not bxh <= xx < bxh + 16)
    # its own 32-column window (c0 = first canvas column), most pixels kept
    bestn, c0 = -1, 0
    for x0 in (range(0, CW - 31) if force is None else [force[1]]):
        n = sum(1 for yy in range(H) for xx in range(x0, x0 + 32) if on[yy][xx])
        if n > bestn:
            bestn, c0 = n, x0
    dark, cut = [], 0
    for yy in range(H):
        row = 0
        for xx in range(CW):
            if on[yy][xx]:
                if c0 <= xx < c0 + 32:
                    row |= 1 << (31 - (xx - c0))
                else:
                    cut += 1
        dark.append(row)
    halves.append((dark, cut, c0))
    return [''.join(r) for r in rows], halves


exec_anims = None


def anims():
    A = {}
    A['idle'] = inbetween([
        Pose(lean=6, an=70, af=82, en=-10, ef=-20, hair=-0.5, tn=4, tf=-4, kn=4, kf=4),
        Pose(lean=12, hx=8.0, an=84, af=70, en=-20, ef=-8, hair=0.6, head=8, tn=4, tf=-4, kn=6, kf=6, hy=23.8),
    ], 4)
    c = dict(lean=12)
    A['walk'] = inbetween([
        Pose(**c, tn=20, kn=4, tf=-18, kf=18, an=60, af=95, head=-4, hair=0.8),
        Pose(**{**c, 'lean': 16}, tn=12, kn=12, tf=-8, kf=50, hy=24.0, an=68, af=88, hx=8.0, head=6),
        Pose(**c, tf=20, kf=4, tn=-18, kn=18, an=95, af=60, head=-4, hair=-0.8),
        Pose(**{**c, 'lean': 16}, tf=12, kf=12, tn=-8, kn=50, hy=24.0, an=88, af=68, hx=8.0, head=6),
    ], 8)
    A['kick'] = [
        Pose(lean=-4, tn=-30, kn=45, tf=6, kf=6, an=150, en=20, af=-25, ef=10, hair=-0.6, head=-8),
        Pose(lean=-9, hx=7.0, tn=-38, kn=60, tf=8, kf=8, an=165, en=-25, af=-35, ef=25, hair=0.6, head=6),
        Pose(lean=0, tn=20, kn=40, tf=4, kf=10, an=110, en=10, af=30, ef=0, head=-6),
        Pose(lean=-14, tn=72, kn=4, tf=-4, kf=10, an=150, en=30, af=-30, ef=0, hair=-1.0, head=-10),
        Pose(lean=-20, hx=8.0, tn=86, kn=18, tf=-6, kf=14, an=175, en=-20, af=-50, ef=20, hair=-1.4, head=-16, hy=23.0),
        Pose(lean=10, hx=8.0, tn=30, kn=30, tf=-10, kf=14, an=95, en=-10, af=60, ef=-10, hair=0.6, head=6),
    ]
    A['stagger'] = inbetween([
        Pose(lean=-16, hx=6.5, tn=20, kn=10, tf=-6, kf=30, an=170, en=-40, af=130, ef=40, hair=1.2, head=-20),
        Pose(lean=22, hx=8.5, tn=-10, kn=30, tf=24, kf=6, an=120, en=50, af=175, ef=-50, hair=-1.2, head=18),
        Pose(lean=-6, hx=9.0, tn=30, kn=5, tf=-20, kf=40, an=150, en=-60, af=100, ef=60, hair=0.8, head=-12, hy=24.0),
    ], 6)
    A['spin'] = [Pose(yaw=60 * i, lean=4, an=95, af=95, spread=0.5, en=0, ef=0, tn=8, tf=-8, kn=8, kf=8,
                      hair=(1.4 if i % 2 else -1.4), head=0) for i in range(6)]
    # fall: a foot catches, he tips forward round his feet, arms thrown out in front,
    # the head up looking at what is coming (now there is room: each half has its own window)
    A['fall'] = [Pose(tip=T, lean=6, an=a, af=a - 20, en=-10, ef=10, tn=-6, kn=10, tf=-22, kf=40, head=-hd,
                      hair=hr) for T, a, hd, hr in ((12, 150, 8, 1.0), (24, 160, 16, -1.0), (36, 170, 26, 1.2),
                                                      (46, 178, 34, -1.2))]
    return A


ORDER = ['idle', 'walk', 'kick', 'stagger', 'spin', 'fall']


class Frame:
    def __init__(self, name, rows, halves, S, pose):
        self.name, self.rows, self.halves, self.S, self.pose = name, rows, halves, S, pose


def build(shades=False, base=None):
    """shades: the act III frames (sunglasses), with the windows of base"""
    frames, starts = [], {}
    A = anims()
    for an in ORDER:
        starts[an] = len(frames)
        for i, P in enumerate(A[an]):
            lab, S = render(P, shades)
            force = None
            if base is not None:
                bf = base[len(frames)]
                force = ([bf.halves[0][0], bf.halves[1][0]], bf.halves[2][2])
            rows, halves = bands(lab, free=(an == 'fall'), force=force)
            frames.append(Frame(f'{an}{i}', rows, halves, S, P))
    return frames, starts, {an: len(A[an]) for an in ORDER}


def sheets(frames, outdir, scale=4, tag=""):
    """the sprite sheet (4x: exactly what the game shows, both halves in their
    windows) and the skeleton overlay sheet"""
    from PIL import Image, ImageDraw
    per = 9
    cw, ch = 44 * scale, (H + 6) * scale
    nrow = (len(frames) + per - 1) // per
    for kind in ('frames', 'skeleton'):
        img = Image.new("RGB", (per * cw, nrow * ch), (33, 176, 59))
        d = ImageDraw.Draw(img)
        for i, fr in enumerate(frames):
            ox, oy = (i % per) * cw + scale, (i // per) * ch + scale
            dark, _cut, dc0 = fr.halves[2]
            for yy in range(H):
                for xx in range(32):
                    if dark[yy] >> (31 - xx) & 1:
                        X, Y = ox + (xx + dc0 - 4) * scale, oy + yy * scale
                        d.rectangle([X, Y, X + scale - 1, Y + scale - 1], fill=(0, 0, 0) if kind == 'frames' else (20, 20, 20))
            for hi, (dx, _cols, win, _lost) in enumerate(fr.halves[:2]):
                x0 = 8 + dx
                for yy, row in enumerate(win):
                    for xx, c in enumerate(row):
                        if c == '.':
                            continue
                        col = RGB[c] if kind == 'frames' else tuple(v // 2 + 20 for v in RGB[c])
                        X, Y = ox + (x0 + xx - 4) * scale, oy + (hi * 16 + yy) * scale
                        d.rectangle([X, Y, X + scale - 1, Y + scale - 1], fill=col)
            d.text((ox, oy + H * scale + 2), fr.name, fill=(220, 220, 220))
            if kind == 'skeleton':
                S = fr.S
                P = lambda k: (ox + (S[k][0] - 4 + 0.5) * scale, oy + (S[k][1] + 0.5) * scale)
                bones = [('hip', 'sh'), ('sh', 'head')]
                for s in 'nf':
                    bones += [('hip' + s, 'knee' + s), ('knee' + s, 'foot' + s), ('sho' + s, 'elb' + s), ('elb' + s, 'hand' + s)]
                for a, b in bones:
                    col = (255, 80, 80) if a.endswith('n') or b.endswith('n') else (80, 160, 255)
                    if a in ('hip', 'sh'):
                        col = (255, 220, 60)
                    d.line([P(a), P(b)], fill=col, width=2)
                for kk in S:
                    x0, y0 = P(kk)
                    d.ellipse([x0 - 3, y0 - 3, x0 + 3, y0 + 3], outline=(255, 255, 255))
        img.save(os.path.join(outdir, f"zombie-{kind}{tag}-4x.png"))


if __name__ == '__main__':
    fr, st, nn = build()
    out = sys.argv[1] if len(sys.argv) > 1 else '.'
    sheets(fr, out)
    print(len(fr), st, nn, 'cut beyond the dark canvas:', [(f.name, f.halves[2][1]) for f in fr if f.halves[2][1]])
