# font.py - POULET CONTRE ZOMBIE: the game's own 8x8 font (Amy & Claude 2026).
# 5x7 capitals, digits and signs, plus accented capitals (the accent on the top
# row, the letter one row shorter). Loaded at codes 32-127 in every third; the
# BIOS font is not used. Code map: ASCII 32-95 as usual; compressed accented
# capitals at 96-107, accent tiles (for the cell above) at 108-111.
G = {
 ' ': ["     "] * 7,
 'A': [" ### ", "#   #", "#   #", "#####", "#   #", "#   #", "#   #"],
 'B': ["#### ", "#   #", "#   #", "#### ", "#   #", "#   #", "#### "],
 'C': [" ### ", "#   #", "#    ", "#    ", "#    ", "#   #", " ### "],
 'D': ["#### ", "#   #", "#   #", "#   #", "#   #", "#   #", "#### "],
 'E': ["#####", "#    ", "#    ", "#### ", "#    ", "#    ", "#####"],
 'F': ["#####", "#    ", "#    ", "#### ", "#    ", "#    ", "#    "],
 'G': [" ### ", "#   #", "#    ", "# ###", "#   #", "#   #", " ####"],
 'H': ["#   #", "#   #", "#   #", "#####", "#   #", "#   #", "#   #"],
 'I': [" ### ", "  #  ", "  #  ", "  #  ", "  #  ", "  #  ", " ### "],
 'J': ["  ###", "   # ", "   # ", "   # ", "   # ", "#  # ", " ##  "],
 'K': ["#   #", "#  # ", "# #  ", "##   ", "# #  ", "#  # ", "#   #"],
 'L': ["#    ", "#    ", "#    ", "#    ", "#    ", "#    ", "#####"],
 'M': ["#   #", "## ##", "# # #", "# # #", "#   #", "#   #", "#   #"],
 'N': ["#   #", "##  #", "# # #", "#  ##", "#   #", "#   #", "#   #"],
 'O': [" ### ", "#   #", "#   #", "#   #", "#   #", "#   #", " ### "],
 'P': ["#### ", "#   #", "#   #", "#### ", "#    ", "#    ", "#    "],
 'Q': [" ### ", "#   #", "#   #", "#   #", "# # #", "#  # ", " ## #"],
 'R': ["#### ", "#   #", "#   #", "#### ", "# #  ", "#  # ", "#   #"],
 'S': [" ####", "#    ", "#    ", " ### ", "    #", "    #", "#### "],
 'T': ["#####", "  #  ", "  #  ", "  #  ", "  #  ", "  #  ", "  #  "],
 'U': ["#   #", "#   #", "#   #", "#   #", "#   #", "#   #", " ### "],
 'V': ["#   #", "#   #", "#   #", "#   #", "#   #", " # # ", "  #  "],
 'W': ["#   #", "#   #", "#   #", "# # #", "# # #", "## ##", "#   #"],
 'X': ["#   #", "#   #", " # # ", "  #  ", " # # ", "#   #", "#   #"],
 'Y': ["#   #", "#   #", " # # ", "  #  ", "  #  ", "  #  ", "  #  "],
 'Z': ["#####", "    #", "   # ", "  #  ", " #   ", "#    ", "#####"],
 '0': [" ### ", "#   #", "#  ##", "# # #", "##  #", "#   #", " ### "],
 '1': ["  #  ", " ##  ", "  #  ", "  #  ", "  #  ", "  #  ", " ### "],
 '2': [" ### ", "#   #", "    #", "   # ", "  #  ", " #   ", "#####"],
 '3': ["#####", "   # ", "  #  ", "   # ", "    #", "#   #", " ### "],
 '4': ["   # ", "  ## ", " # # ", "#  # ", "#####", "   # ", "   # "],
 '5': ["#####", "#    ", "#### ", "    #", "    #", "#   #", " ### "],
 '6': ["  ## ", " #   ", "#    ", "#### ", "#   #", "#   #", " ### "],
 '7': ["#####", "    #", "   # ", "  #  ", " #   ", " #   ", " #   "],
 '8': [" ### ", "#   #", "#   #", " ### ", "#   #", "#   #", " ### "],
 '9': [" ### ", "#   #", "#   #", " ####", "    #", "   # ", " ##  "],
 '.': ["     ", "     ", "     ", "     ", "     ", " ##  ", " ##  "],
 ',': ["     ", "     ", "     ", "     ", " ##  ", "  #  ", " #   "],
 ':': ["     ", " ##  ", " ##  ", "     ", " ##  ", " ##  ", "     "],
 ';': ["     ", " ##  ", " ##  ", "     ", " ##  ", "  #  ", " #   "],
 '!': ["  #  ", "  #  ", "  #  ", "  #  ", "  #  ", "     ", "  #  "],
 '?': [" ### ", "#   #", "    #", "   # ", "  #  ", "     ", "  #  "],
 "'": ["  #  ", "  #  ", " #   ", "     ", "     ", "     ", "     "],
 '-': ["     ", "     ", "     ", "#####", "     ", "     ", "     "],
 '+': ["     ", "  #  ", "  #  ", "#####", "  #  ", "  #  ", "     "],
 '/': ["    #", "    #", "   # ", "  #  ", " #   ", "#    ", "#    "],
 '&': [" ##  ", "#  # ", "# #  ", " #   ", "# # #", "#  # ", " ## #"],
 '(': ["   # ", "  #  ", " #   ", " #   ", " #   ", "  #  ", "   # "],
 ')': [" #   ", "  #  ", "   # ", "   # ", "   # ", "  #  ", " #   "],
 '<': ["    #", "   # ", "  #  ", " #   ", "  #  ", "   # ", "    #"],
 '>': ["#    ", " #   ", "  #  ", "   # ", "  #  ", " #   ", "#    "],
 '=': ["     ", "     ", "#####", "     ", "#####", "     ", "     "],
 '*': ["     ", "# # #", " ### ", "#####", " ### ", "# # #", "     "],
 '#': [" # # ", " # # ", "#####", " # # ", "#####", " # # ", " # # "],
 '%': ["##   ", "##  #", "   # ", "  #  ", " #   ", "#  ##", "   ##"],
 '"': [" # # ", " # # ", "     ", "     ", "     ", "     ", "     "],
 '[': [" ### ", " #   ", " #   ", " #   ", " #   ", " #   ", " ### "],
 ']': [" ### ", "   # ", "   # ", "   # ", "   # ", "   # ", " ### "],
 '@': [" ### ", "#   #", "# ###", "# # #", "# ###", "#    ", " ####"],
 '^': ["  #  ", " # # ", "#   #", "     ", "     ", "     ", "     "],
 '_': ["     ", "     ", "     ", "     ", "     ", "     ", "#####"],
 '$': ["  #  ", " ####", "# #  ", " ### ", "  # #", "#### ", "  #  "],
}
# Accents (French capitals stay full height):
# - "above" form: the plain capital in the text cell, and an accent tile (codes
#   108-111: acute, grave, circumflex, diaeresis) in the cell above, drawn on its
#   rows 5-6 so one blank row separates it from the letter. texts.py uses it when
#   the cell above is free.
# - "compressed" form (codes 96-107): accent on row 0, the capital squeezed to six
#   rows (1-6) on the same baseline as the other letters; used when the cell above
#   is taken. Ç is the full C with its hook on row 7 in both forms.
ACUTE1, GRAVE1, CIRC1, DIAER1 = "   # ", " #   ", " # # ", "#   #"
ABOVE = {'acute': ["   # ", "  #  "], 'grave': [" #   ", "  #  "], 'circ': ["  #  ", " # # "], 'diaer': ["     ", " # # "]}
ABOVE_CODE = {'acute': 108, 'grave': 109, 'circ': 110, 'diaer': 111}
ONE = {'acute': ACUTE1, 'grave': GRAVE1, 'circ': CIRC1, 'diaer': DIAER1}
# accented capitals at codes 96..: (char, base, accent)
ACCENTS = [('É', 'E', 'acute'), ('È', 'E', 'grave'), ('Ê', 'E', 'circ'), ('À', 'A', 'grave'), ('Â', 'A', 'circ'),
           ('Ô', 'O', 'circ'), ('Î', 'I', 'circ'), ('Û', 'U', 'circ'), ('Ù', 'U', 'grave'), ('Ë', 'E', 'diaer'),
           ('Ï', 'I', 'diaer'), ('Ç', 'C', None)]
ACC_CODE = {ch: 96 + i for i, (ch, _, _) in enumerate(ACCENTS)}
ACC_INFO = {ch: (base, acc) for ch, base, acc in ACCENTS}


def bits(r):
    v = 0
    for i, c in enumerate(r):
        if c == '#':
            v |= 0x40 >> i
    return v


def glyph8(rows7):
    """5x7 glyph -> 8 rows of 8 bits (1 column left margin, row 7 empty)"""
    return [bits(r) for r in rows7] + [0]


def squeeze(rows7):
    """7 rows -> 6: drop the row that repeats a neighbour (the middle one if several)"""
    cands = [i for i in range(1, 6) if rows7[i] == rows7[i + 1] or rows7[i] == rows7[i - 1]]
    i = min(cands, key=lambda j: abs(j - 3)) if cands else 3
    return rows7[:i] + rows7[i + 1:]


def accented(base, acc):
    b = G[base]
    if acc is None:                       # cedilla: the full C, the hook on row 7
        v = glyph8(b)
        v[7] = 0x10
        return v
    return [bits(ONE[acc])] + [bits(r) for r in squeeze(b)] + [0]


def font_patterns():
    """128 x 8 bytes: codes 0-127 (32-95 ASCII signs/capitals, 96-107 accents)"""
    pat = [[0] * 8 for _ in range(128)]
    for ch, rows in G.items():
        pat[ord(ch)] = glyph8(rows)
    for i, (ch, base, acc) in enumerate(ACCENTS):
        pat[96 + i] = accented(base, acc)
    for acc, code in ABOVE_CODE.items():
        pat[code] = [0] * 5 + [bits(r) for r in ABOVE[acc]] + [0]
    return pat


def encode_above(text, free_above):
    """text -> (codes for the line, codes for the row above or None).
    free_above(i) says whether the cell above character i is free."""
    line, above, used = [], [], False
    for i, ch in enumerate(text):
        if ch in ACC_INFO and ACC_INFO[ch][1] and free_above(i):
            base, acc = ACC_INFO[ch]
            line.append(ord(base)); above.append(ABOVE_CODE[acc]); used = True
        else:
            line += encode(ch); above.append(32)
    return line, (above if used else None)


def encode(text):
    """text -> font codes (capitals; accents mapped; anything else is an error)"""
    out = []
    for ch in text:
        if ch in ACC_CODE:
            out.append(ACC_CODE[ch])
        elif ch in G:
            out.append(ord(ch))
        else:
            raise ValueError(f"font: no glyph for {ch!r} in {text!r}")
    return out
