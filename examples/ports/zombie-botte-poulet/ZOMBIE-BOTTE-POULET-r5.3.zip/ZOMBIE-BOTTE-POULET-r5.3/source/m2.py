# m2.py - picture -> TMS9918A graphics mode 2 tiles (Amy & Claude 2026).
# Pictures are numpy arrays of palette indices (0-15, TMS9918A order).
# Each 8-pixel tile row keeps its two most used colours (others go to the
# nearer of the two); cells are merged per third; when a third needs more
# tiles than its budget, similar cells are merged (k-medoids on RGB).
import numpy as np

RGB = np.array([(0, 0, 0), (0, 0, 0), (33, 200, 66), (94, 220, 120), (84, 85, 237), (125, 118, 252),
                (212, 82, 77), (66, 235, 245), (252, 85, 84), (255, 121, 120), (212, 193, 84),
                (230, 206, 128), (33, 176, 59), (201, 91, 186), (204, 204, 204), (255, 255, 255)], float)
CL = dict(t=0, k=1, m=2, g=3, n=4, b=5, r=6, c=7, R=8, p=9, y=10, Y=11, G=12, M=13, a=14, w=15)


def reduce_rows(img):
    """every 8-pixel row segment to at most two colours (in place copy)"""
    out = img.copy()
    h, w = img.shape
    for y in range(h):
        for x0 in range(0, w, 8):
            seg = out[y, x0:x0 + 8]
            vals, cnt = np.unique(seg, return_counts=True)
            if len(vals) <= 2:
                continue
            order = vals[np.argsort(-cnt, kind='stable')]
            a, b = order[0], order[1]
            for i in range(8):
                c = seg[i]
                if c != a and c != b:
                    da = ((RGB[c] - RGB[a]) ** 2).sum()
                    db = ((RGB[c] - RGB[b]) ** 2).sum()
                    seg[i] = a if da <= db else b
    return out


def cell_bytes(cell):
    """8x8 indices (two colours a row) -> (8 pattern bytes, 8 colour bytes), canonical"""
    pat, col = [], []
    for r in range(8):
        row = cell[r]
        vals = sorted(set(int(v) for v in row))
        if len(vals) == 1:
            pat.append(0)
            col.append((vals[0] << 4) | vals[0])
            continue
        bg, fg = vals[0], vals[1]                  # fg = the larger index
        bits = 0
        for i in range(8):
            if row[i] == fg:
                bits |= 0x80 >> i
        pat.append(bits)
        col.append((fg << 4) | bg)
    return tuple(pat), tuple(col)


def cell_rgb(pc):
    pat, col = pc
    out = np.zeros((8, 8, 3))
    for r in range(8):
        fg, bg = col[r] >> 4, col[r] & 15
        for i in range(8):
            out[r, i] = RGB[fg if pat[r] & (0x80 >> i) else bg]
    return out.reshape(-1)


class Third:
    """tiles of one third: code allocation from `base`, at most `limit` codes"""
    def __init__(self, base, limit):
        self.base, self.limit = base, limit
        self.cells = []          # (pat, col)
        self.index = {}

    def add(self, pc):
        if pc not in self.index:
            self.index[pc] = len(self.cells)
            self.cells.append(pc)
        return self.index[pc]


def encode_frames(frames, rows_by_third, base, budget, fixed=None):
    """frames: list of index pictures (H x 256). For each third t, the rows of
    rows_by_third[t] (tile rows) of every frame are cut into cells; cells listed
    in `fixed` (dict pc -> code) keep their code. Returns (thirds, names) where
    names[f] is a 32 x 24 code array (only the given rows filled; others 0)."""
    reduced = [reduce_rows(f) for f in frames]
    names = [np.zeros((24, 32), int) for _ in frames]
    thirds = []
    for t, rows in enumerate(rows_by_third):
        allc = []
        where = []
        for fi, img in enumerate(reduced):
            for ty in rows:
                for tx in range(32):
                    pc = cell_bytes(img[ty * 8:ty * 8 + 8, tx * 8:tx * 8 + 8])
                    allc.append(pc)
                    where.append((fi, ty, tx))
        uniq = []
        idx = {}
        for pc in allc:
            if fixed and pc in fixed:
                continue
            if pc not in idx:
                idx[pc] = len(uniq)
                uniq.append(pc)
        mapping = {}
        bud = budget[t] if isinstance(budget, (list, tuple)) else budget
        print(f'  third {t}: {len(uniq)} distinct cells (budget {bud})')
        if len(uniq) > bud:
            # k-medoids-ish: frequency-weighted, start with the most frequent cells
            freq = {}
            for pc in allc:
                freq[pc] = freq.get(pc, 0) + 1
            vec = np.array([cell_rgb(pc) for pc in uniq])
            order = sorted(range(len(uniq)), key=lambda i: -freq[uniq[i]])
            cent = order[:bud]
            for _ in range(6):
                C = vec[cent]
                d = ((vec[:, None, :] - C[None, :, :]) ** 2).sum(axis=2)
                lab = d.argmin(axis=1)
                new = []
                for k in range(len(cent)):
                    members = np.where(lab == k)[0]
                    if len(members) == 0:
                        new.append(cent[k]); continue
                    w = np.array([freq[uniq[m]] for m in members], float)
                    sub = vec[members]
                    dd = ((sub[:, None, :] - sub[None, :, :]) ** 2).sum(axis=2) @ w
                    new.append(members[int(dd.argmin())])
                if new == cent:
                    break
                cent = new
            C = vec[cent]
            d = ((vec[:, None, :] - C[None, :, :]) ** 2).sum(axis=2)
            lab = d.argmin(axis=1)
            keep = [uniq[c] for c in cent]
            for i, pc in enumerate(uniq):
                mapping[pc] = keep[lab[i]]
            uniq = list(dict.fromkeys(keep))
        th = Third(base, bud)
        for pc in uniq:
            th.add(pc)
        for pc, (fi, ty, tx) in zip(allc, where):
            if fixed and pc in fixed:
                names[fi][ty, tx] = fixed[pc]
            else:
                names[fi][ty, tx] = base + th.index[mapping.get(pc, pc)]
        thirds.append(th)
    return thirds, names


def to_png(path, names_by_third_cells, names, scale=2):
    """preview: names (24x32 codes) with per-third code->(pat,col) dicts"""
    from PIL import Image
    img = np.zeros((192, 256, 3), np.uint8)
    for ty in range(24):
        t = ty // 8
        for tx in range(32):
            pc = names_by_third_cells[t].get(int(names[ty, tx]))
            if pc is None:
                continue
            img[ty * 8:ty * 8 + 8, tx * 8:tx * 8 + 8] = cell_rgb(pc).reshape(8, 8, 3).astype(np.uint8)
    Image.fromarray(img).resize((256 * scale, 192 * scale), Image.NEAREST).save(path)
