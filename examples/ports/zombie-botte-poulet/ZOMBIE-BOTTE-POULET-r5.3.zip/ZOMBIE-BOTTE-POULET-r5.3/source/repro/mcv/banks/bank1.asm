; Logical BANK 1 is visible at $C000 after BANK SELECT 1
org $C000
Bank1Data: db "BANK ONE"
