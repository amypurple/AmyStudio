import { openPort } from "/tmp/claude-0/-home-claude/1a989a62-868e-5188-adf8-4832b4e486a2/scratchpad/work/poulet/common/test/portlib.mjs";
const base = process.argv[2];
const p = await openPort(base, { outDir: process.argv[3] || ".", vdp: true });
console.log("type", p.g.core.getCartridgeType(), "megacart", p.g.core.isMegaCart());
p.step(0, 400);
p.shot("mc");
const r = p.vdpReport();
console.log(JSON.stringify({lost:r.lost, misdirected:r.misdirected, shadowMismatch:r.shadowMismatch, minGap:r.minGap, keys:Object.keys(r)}));
const vr = p.g.core.readVram ? Array.from(p.g.core.readVram(0x1800+328, 8)) : null; console.log("vram", vr && String.fromCharCode(...vr));
