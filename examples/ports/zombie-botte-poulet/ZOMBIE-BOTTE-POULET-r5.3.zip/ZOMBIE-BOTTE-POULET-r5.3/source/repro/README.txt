r3.alexis   asm block without data: stays in place (reference)
r3b.alexis  asm block with db: moved after the program, its instructions never run (bug 3)
r5.alexis   misleading "Unsupported comparison" for a variable declared later (bug 4)
mcv/        Amy Studio's MegaCart template: main-with-decompress.amy fails to assemble
            (mdkrle_decompress not linked, bug 2); main.amy (without that line) builds,
            runs in the GearColeco test core as a MegaCart and passes the VDP checker
            (harness-check.mjs)
Build: node <r12.11 toolchain>/tools/amyc.mjs <file> --asm --opt balanced
       node <r12.11 toolchain>/tools/amyc.mjs mcv/project.amy.json --output mcv.rom --opt balanced
