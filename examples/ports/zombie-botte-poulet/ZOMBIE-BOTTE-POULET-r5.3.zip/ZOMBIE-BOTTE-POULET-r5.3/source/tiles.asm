; tiles.asm - ZOMBIE BOTTE POULET r4: the zombie's black outline as a software
; sprite layer in background tiles (the Joust legs trick). Amy & Claude 2026.
;
; The zombie's dark layer (ZDkTab: first row, rows, bytes a row, then the rows)
; is copied (mirrored when he faces left) and shifted to his pixel position
; into ShBuf: 5 cell columns of 48 bytes (column-major); canvas row r is byte
; r + 8 of a column, so 8 empty rows lie above and below and the 8 bytes of a
; cell are always contiguous. The block of 5x5 cells at (TlCx, TlCy) uses the
; outline tiles 206-230 (cell i: tile 206 + i, the same codes in thirds 1, 2).
;   - tl_place: when the block moves to another cell position. Each cell's own
;     name is kept in CellOrig; a plain lawn cell (LawnTile) gets its outline
;     tile while the block stays there (black on green: no clash on the lawn).
;   - tl_stream: every frame he moves or changes pose: the 25 tiles' patterns
;     are written in one stream (200 bytes, 37 T each).
;   - tl_flags: a cell that is not lawn (fence, lantern, basket, gravestone,
;     sprinkler) keeps its own name; if his outline crosses it, that half of
;     him shows its outline as a sprite (TlTop, TlBot).
;   - tl_unplace: the block's cells get their own names back.
; Every VRAM access is at least 29 T after the previous one (display on).
; (No compositing: where the outline would cross a cell that is not plain
; lawn, that half of him shows its outline as a sprite instead, tl_flags.)

TL_LAWN         equ     205
TL_DYN          equ     206

; ------------------------------------------------------------ VRAM set-up (HL = address)
tl_wr:
        ld      a, l
        out     ($bf), a
        ld      a, h
        and     $3f
        or      $40
        out     ($bf), a
        ret
tl_rd:
        ld      a, l
        out     ($bf), a
        ld      a, h
        and     $3f
        out     ($bf), a
        ex      (sp), hl                ; 38 T: the read-ahead has its slot
        ex      (sp), hl
        ret

; ------------------------------------------------------------ ShBuf for this pose and TlNsx
; the NMI is off outside the frame wait, so the stack can clear the buffer
tl_shbuf:
        ld      (TlSpSave), sp
        ld      sp, ShBuf + 240
        ld      hl, 0
        ld      b, 120
tsb_clr:
        push    hl
        djnz    tsb_clr
        ld      sp, (TlSpSave)
        ld      a, (ZFn)
        add     a, a
        ld      l, a
        ld      h, 0
        ld      de, ZDkTab
        add     hl, de
        ld      e, (hl)
        inc     hl
        ld      d, (hl)
        ex      de, hl
        ld      a, (hl)                 ; first row
        inc     hl
        ld      (TlRmin), a
        ld      b, (hl)                 ; rows
        inc     hl
        add     a, b
        dec     a
        ld      (TlRmax), a
        ld      a, (hl)                 ; bytes a row
        inc     hl
        ld      (TlNb), a
        ld      (TlSrc), hl
        ; IX = column 2 of the first row (columns 0-4 are IX-96 .. IX+96),
        ; IY = the source row, H = the RevTab page
        push    ix
        push    iy
        ld      a, (TlRmin)
        add     a, 8
        ld      e, a
        ld      d, 0
        ld      ix, ShBuf + 96
        add     ix, de
        ld      iy, (TlSrc)
        ld      a, (TlNb)
        ld      (TlStep), a
        xor     a
        ld      (TlStep + 1), a         ; TlStep = bytes a row (the source step)
        ld      h, RevTab / 256
        ld      a, (ZFlip)
        ld      (TlK), a
        ld      a, b
        ld      (TlRows), a
        ; rows of 3 bytes (all frames but the last falls): the fast loops
        ld      a, (TlNb)
        cp      3
        jp      z, tsb3
        cp      2
        jp      z, tsb2
        cp      4
        jp      z, tsb4
tsb3:
        ld      a, (TlNsx)
        cp      5
        jr      nc, t3_left
t3_rrow:
        ld      a, (ZFlip)
        or      a
        jr      nz, t3_rm
        ld      c, (iy + 0)
        ld      d, (iy + 1)
        ld      e, (iy + 2)
        jr      t3_rl
t3_rm:
        ld      h, RevTab / 256
        ld      l, (iy + 2)
        ld      c, (hl)
        ld      l, (iy + 1)
        ld      d, (hl)
        ld      l, (iy + 0)
        ld      e, (hl)
t3_rl:
        ld      a, (TlNsx)
        or      a
        jr      z, t3_rst
        ld      h, a
        xor     a
t3_rs:
        srl     c
        rr      d
        rr      e
        rra
        dec     h
        jr      nz, t3_rs
t3_rst:
        ld      (ix - 96), c
        ld      (ix - 48), d
        ld      (ix + 0), e
        ld      (ix + 48), a
        inc     ix
        inc     iy
        inc     iy
        inc     iy
        djnz    t3_rrow
        pop     iy
        pop     ix
        ret
t3_left:
        neg
        add     a, 8
        ld      (TlK), a                ; bits to the left
t3_lrow:
        ld      a, (ZFlip)
        or      a
        jr      nz, t3_lm
        ld      c, (iy + 0)
        ld      d, (iy + 1)
        ld      e, (iy + 2)
        jr      t3_ll
t3_lm:
        ld      h, RevTab / 256
        ld      l, (iy + 2)
        ld      c, (hl)
        ld      l, (iy + 1)
        ld      d, (hl)
        ld      l, (iy + 0)
        ld      e, (hl)
t3_ll:
        ld      a, (TlK)
        ld      h, a
        ld      l, 0
t3_ls:
        sla     e
        rl      d
        rl      c
        rl      l
        dec     h
        jr      nz, t3_ls
        ld      (ix - 96), l
        ld      (ix - 48), c
        ld      (ix + 0), d
        ld      (ix + 48), e
        inc     ix
        inc     iy
        inc     iy
        inc     iy
        djnz    t3_lrow
        pop     iy
        pop     ix
        ret

; rows of 4 bytes (the last falls): the same, five columns
tsb4:
        ld      a, (TlNsx)
        cp      5
        jr      nc, t4_left
t4_rrow:
        ld      a, (ZFlip)
        or      a
        jr      nz, t4_rm
        ld      c, (iy + 0)
        ld      d, (iy + 1)
        ld      e, (iy + 2)
        ld      l, (iy + 3)
        jr      t4_rl
t4_rm:
        ld      h, RevTab / 256
        ld      l, (iy + 3)
        ld      c, (hl)
        ld      l, (iy + 2)
        ld      d, (hl)
        ld      l, (iy + 1)
        ld      e, (hl)
        ld      l, (iy + 0)
        ld      l, (hl)
t4_rl:
        xor     a
        ld      b, a
        ld      a, (TlNsx)
        or      a
        ld      h, a
        ld      a, b
        jr      z, t4_rst
t4_rs:
        srl     c
        rr      d
        rr      e
        rr      l
        rra
        dec     h
        jr      nz, t4_rs
t4_rst:
        ld      (ix - 96), c
        ld      (ix - 48), d
        ld      (ix + 0), e
        ld      (ix + 48), l
        ld      (ix + 96), a
        inc     ix
        ld      de, 4
        add     iy, de
        ld      hl, TlRows
        dec     (hl)
        jr      nz, t4_rrow
        pop     iy
        pop     ix
        ret
t4_left:
        neg
        add     a, 8
        ld      (TlK), a                ; bits to the left
t4_lrow:
        ld      a, (ZFlip)
        or      a
        jr      nz, t4_lm
        ld      c, (iy + 0)
        ld      d, (iy + 1)
        ld      e, (iy + 2)
        ld      l, (iy + 3)
        jr      t4_ll
t4_lm:
        ld      h, RevTab / 256
        ld      l, (iy + 3)
        ld      c, (hl)
        ld      l, (iy + 2)
        ld      d, (hl)
        ld      l, (iy + 1)
        ld      e, (hl)
        ld      l, (iy + 0)
        ld      l, (hl)
t4_ll:
        ld      a, (TlK)
        ld      h, a
        xor     a
t4_ls:
        sla     l
        rl      e
        rl      d
        rl      c
        rla
        dec     h
        jr      nz, t4_ls
        ld      (ix - 96), a
        ld      (ix - 48), c
        ld      (ix + 0), d
        ld      (ix + 48), e
        ld      (ix + 96), l
        inc     ix
        ld      de, 4
        add     iy, de
        ld      hl, TlRows
        dec     (hl)
        jr      nz, t4_lrow
        pop     iy
        pop     ix
        ret

; rows of 2 bytes: the same, three columns
tsb2:
        ld      a, (TlNsx)
        cp      5
        jr      nc, t2_left
t2_rrow:
        ld      a, (ZFlip)
        or      a
        jr      nz, t2_rm
        ld      c, (iy + 0)
        ld      d, (iy + 1)
        jr      t2_rl
t2_rm:
        ld      h, RevTab / 256
        ld      l, (iy + 1)
        ld      c, (hl)
        ld      l, (iy + 0)
        ld      d, (hl)
t2_rl:
        ld      a, (TlNsx)
        or      a
        jr      z, t2_rst
        ld      h, a
        xor     a
t2_rs:
        srl     c
        rr      d
        rra
        dec     h
        jr      nz, t2_rs
t2_rst:
        ld      (ix - 96), c
        ld      (ix - 48), d
        ld      (ix + 0), a
        inc     ix
        inc     iy
        inc     iy
        djnz    t2_rrow
        pop     iy
        pop     ix
        ret
t2_left:
        neg
        add     a, 8
        ld      (TlK), a
t2_lrow:
        ld      a, (ZFlip)
        or      a
        jr      nz, t2_lm
        ld      c, (iy + 0)
        ld      d, (iy + 1)
        jr      t2_ll
t2_lm:
        ld      h, RevTab / 256
        ld      l, (iy + 1)
        ld      c, (hl)
        ld      l, (iy + 0)
        ld      d, (hl)
t2_ll:
        ld      a, (TlK)
        ld      h, a
        ld      l, 0
t2_ls:
        sla     d
        rl      c
        rl      l
        dec     h
        jr      nz, t2_ls
        ld      (ix - 96), l
        ld      (ix - 48), c
        ld      (ix + 0), d
        inc     ix
        inc     iy
        inc     iy
        djnz    t2_lrow
        pop     iy
        pop     ix
        ret

; ShBuf one bit to the right (TlDir = 1) or to the left (TlDir = 0), rows TlRmin-TlRmax
tl_shift1:
        ; (IX-indexed: ADD HL,DE would clobber the carry between the columns)
        ld      a, (TlRmin)
        ld      c, a
        ld      a, (TlRmax)
        sub     c
        ret     c
        inc     a
        ld      b, a
        push    ix
        ld      a, c
        add     a, 8
        ld      e, a
        ld      d, 0
        ld      ix, ShBuf + 96
        add     ix, de
        ld      a, (TlDir)
        or      a
        jr      z, ts1_l
ts1_r:
        srl     (ix - 96)
        rr      (ix - 48)
        rr      (ix + 0)
        rr      (ix + 48)
        rr      (ix + 96)
        inc     ix
        djnz    ts1_r
        pop     ix
        ret
ts1_l:
        sla     (ix + 96)
        rl      (ix + 48)
        rl      (ix + 0)
        rl      (ix - 48)
        rl      (ix - 96)
        inc     ix
        djnz    ts1_l
        pop     ix
        ret

; into the next cell column by one pixel: right (TlDir = 1): one bit right,
; then the columns move one to the left; left: the columns move one to the
; right, then one bit left
tl_cross:
        ld      a, (TlDir)
        or      a
        jr      z, tc_left
        call    tl_shift1
        ld      hl, ShBuf + 48
        ld      de, ShBuf
        ld      bc, 192
        ldir
        ld      hl, ShBuf + 192
        ld      b, 48
        xor     a
tc_z:
        ld      (hl), a
        inc     hl
        djnz    tc_z
        ret
tc_left:
        ld      hl, ShBuf + 191
        ld      de, ShBuf + 239
        ld      bc, 192
        lddr
        ld      hl, ShBuf
        ld      b, 48
        xor     a
tc_z2:
        ld      (hl), a
        inc     hl
        djnz    tc_z2
        jp      tl_shift1

; ------------------------------------------------------------ the 25 patterns in one stream
; per block row: one address, 5 tiles of 8 bytes (ShBuf column bc, rows br*8 - sy ..)
tl_stream:
        ; columns to write: the data and its spill byte (TlNb + 1), or more if
        ; the last stream wrote more (those tiles must be cleared once)
        ld      a, (TlNb)
        inc     a
        ld      b, a
        ld      a, (TlScol)
        cp      b
        jr      nc, ts_c1
        ld      a, b
ts_c1:
        cp      6
        jr      c, ts_c2
        ld      a, 5
ts_c2:
        ld      (TlScnt), a
        ld      a, b
        ld      (TlScol), a
        xor     a
        ld      (TlBr), a
ts_row:
        ld      a, (TlBr)
        ld      b, a
        ld      a, (TlNcy)
        add     a, b
        cp      8
        jr      c, ts_next
        cp      22
        jr      nc, ts_next
        rlca
        rlca
        rlca
        rlca
        rlca
        and     3                       ; the third
        add     a, a
        add     a, a
        add     a, a
        ld      d, a
        ld      a, (TlBr)
        ld      b, a
        add     a, a
        add     a, a
        add     a, b                    ; idx of the row's first cell
        ld      hl, TlSBase
        add     a, (hl)                 ; + the tile set written (206 or 231)
        ld      l, a
        ld      h, 0
        add     hl, hl
        add     hl, hl
        add     hl, hl
        ld      a, h
        add     a, d
        ld      h, a
        call    tl_wr
        ; source: ShBuf + 8 + br * 8 - sy (column 0)
        ld      a, (TlBr)
        add     a, a
        add     a, a
        add     a, a
        add     a, 8
        ld      b, a
        ld      a, (TlNsy)
        ld      c, a
        ld      a, b
        sub     c
        ld      e, a
        ld      d, 0
        ld      hl, ShBuf
        add     hl, de
        ld      a, (TlScnt)
        ld      c, a
        ld      de, 40                  ; to the next column, 8 rows on
ts_cell:
        ld      a, (hl)                 ; 7 + 1
        out     ($be), a                ; 11 + 1
        inc     hl                      ; 6 + 1
        nop                             ; 4 + 1 -> 31 T a byte
        ld      a, (hl)                 ; 7 + 1
        out     ($be), a                ; 11 + 1
        inc     hl                      ; 6 + 1
        nop                             ; 4 + 1 -> 31 T a byte
        ld      a, (hl)                 ; 7 + 1
        out     ($be), a                ; 11 + 1
        inc     hl                      ; 6 + 1
        nop                             ; 4 + 1 -> 31 T a byte
        ld      a, (hl)                 ; 7 + 1
        out     ($be), a                ; 11 + 1
        inc     hl                      ; 6 + 1
        nop                             ; 4 + 1 -> 31 T a byte
        ld      a, (hl)                 ; 7 + 1
        out     ($be), a                ; 11 + 1
        inc     hl                      ; 6 + 1
        nop                             ; 4 + 1 -> 31 T a byte
        ld      a, (hl)                 ; 7 + 1
        out     ($be), a                ; 11 + 1
        inc     hl                      ; 6 + 1
        nop                             ; 4 + 1 -> 31 T a byte
        ld      a, (hl)                 ; 7 + 1
        out     ($be), a                ; 11 + 1
        inc     hl                      ; 6 + 1
        nop                             ; 4 + 1 -> 31 T a byte
        ld      a, (hl)                 ; 7 + 1
        out     ($be), a                ; 11 + 1
        inc     hl                      ; 6 + 1
        nop                             ; 4 + 1 -> 31 T a byte
        add     hl, de
        dec     c
        jr      nz, ts_cell
ts_next:
        ld      hl, TlBr
        inc     (hl)
        ld      a, (hl)
        cp      5
        jr      c, ts_row
        ret

; ------------------------------------------------------------ the block's cells
; the block arrives at (TlCx, TlCy): each row of its cells is read in one burst
; (their own names into CellOrig), then written in one burst: lawn cells get
; their outline tile (206 + the cell's index in the block), the others keep
; their names (TlNl counts them)
tl_place:
        ld      a, 5
        ld      (TlScol), a             ; the next stream writes all 5 columns
        xor     a
        ld      (TlBr), a
        ld      (TlIdx), a
        ld      (TlNl), a
tp_row:
        call    tl_rowcells             ; B = cells, HL = name address; ret z: none
        jr      z, tp_next
        push    bc
        push    hl
        call    tl_rd
        ld      hl, CellOrig
        ld      a, (TlIdx)
        ld      e, a
        ld      d, 0
        add     hl, de
tp_rd:
        in      a, ($be)                ; 11
        ld      (hl), a                 ; 7
        inc     hl                      ; 6
        djnz    tp_rd                   ; 13 -> 37 T
        pop     hl
        pop     bc
        call    tl_wr
        ld      hl, CellOrig
        ld      a, (TlIdx)
        ld      e, a
        ld      d, 0
        add     hl, de
        ld      c, a
        ld      a, (TlPBase)            ; the tile set placed (206 or 231)
        add     a, c
        ld      c, a                    ; C = this cell's outline tile
tp_wr:
        ld      a, (hl)                 ; 7
        cp      TL_LAWN                 ; 7
        jr      nz, tp_own              ; 7/12
        ld      a, c                    ; 4
        jr      tp_out
tp_own:
        push    hl                      ; one more cell that is not lawn
        ld      hl, TlNl
        inc     (hl)
        pop     hl
tp_out:
        out     ($be), a                ; 11
        inc     hl                      ; 6
        inc     c                       ; 4
        djnz    tp_wr                   ; 13
tp_next:
        ld      hl, TlIdx
        ld      a, (hl)
        add     a, 5
        ld      (hl), a
        ld      hl, TlBr
        inc     (hl)
        ld      a, (hl)
        cp      5
        jr      c, tp_row
        ret

; block row TlBr: B = its cells on the play area (columns TlCx.. up to 31),
; HL = the name address of its first cell; Z set when the row is off the area
; (its CellOrig entries are set to 0)
tl_rowcells:
        ld      a, (TlBr)
        ld      b, a
        ld      a, (TlCy)
        add     a, b
        ld      (TlRow), a
        cp      8
        jr      c, trc_off
        cp      22
        jr      nc, trc_off
        ld      a, (TlCx)
        ld      (TlCol), a
        cp      32
        jr      nc, trc_off
        ld      b, a
        ld      a, 32
        sub     b
        cp      5
        jr      c, trc_n
        ld      a, 5
trc_n:
        ld      b, a
        call    tr_nameaddr
        ld      a, b
        or      a                       ; NZ (B = cells > 0)
        ret
trc_off:
        ld      hl, CellOrig
        ld      a, (TlIdx)
        ld      e, a
        ld      d, 0
        add     hl, de
        ld      b, 5
trc_z:
        ld      (hl), 0
        inc     hl
        djnz    trc_z
        xor     a                       ; Z
        ret

; the block's cells get their own names back (one burst a row)
tl_unplace:
        xor     a
        ld      (TlBr), a
        ld      (TlIdx), a
tu_row:
        call    tl_rowcells
        jr      z, tu_next
        call    tl_wr
        ld      hl, CellOrig
        ld      a, (TlIdx)
        ld      e, a
        ld      d, 0
        add     hl, de
tu_wr:
        ld      a, (hl)                 ; 7
        out     ($be), a                ; 11
        inc     hl                      ; 6
        djnz    tu_wr                   ; 13 -> 37 T
tu_next:
        ld      hl, TlIdx
        ld      a, (hl)
        add     a, 5
        ld      (hl), a
        ld      hl, TlBr
        inc     (hl)
        ld      a, (hl)
        cp      5
        jr      c, tu_row
        ret

; which halves of him are over cells that are not plain lawn where his outline
; has black: those halves show their outline as a sprite (TlTop: block rows
; 0-1; TlBot: rows 2-4; row 2 also counts for the top when it reaches above
; canvas row 16), because a tile there would clash with the cell's colours
tl_flags:
        xor     a
        ld      (TlTop), a
        ld      (TlBot), a
        ld      a, (TlNl)
        or      a
        ret     z                       ; all lawn
        ld      hl, CellOrig
        xor     a
        ld      (TlBr), a
tf_row:
        xor     a
        ld      (TlBc), a
tf_cell:
        ld      a, (hl)
        inc     hl
        or      a
        jr      z, tf_next
        cp      TL_LAWN
        jr      z, tf_next
        push    hl
        ld      a, (TlBc)
        ld      e, a
        ld      d, 0
        ld      hl, tf_mul48
        add     hl, de
        ld      e, (hl)                 ; bc * 48
        ld      a, (TlBr)
        add     a, a
        add     a, a
        add     a, a
        add     a, 8
        ld      hl, TlNsy
        sub     (hl)
        add     a, e
        ld      e, a
        ld      d, 0
        jr      nc, tf_nc
        inc     d
tf_nc:
        ld      hl, ShBuf
        add     hl, de
        ld      a, (hl)
        inc     hl
        or      (hl)
        inc     hl
        or      (hl)
        inc     hl
        or      (hl)
        inc     hl
        or      (hl)
        inc     hl
        or      (hl)
        inc     hl
        or      (hl)
        inc     hl
        or      (hl)
        pop     hl
        jr      z, tf_next
        ld      a, (TlBr)
        cp      2
        jr      c, tf_top
        ld      a, 1
        ld      (TlBot), a
        ld      a, (TlTop)              ; both set: done
        or      a
        ret     nz
        ld      a, (TlBr)
        cp      2
        jr      nz, tf_next
        ld      a, (TlNsy)
        or      a
        jr      z, tf_next
tf_top:
        ld      a, 1
        ld      (TlTop), a
        ld      a, (TlBot)
        or      a
        ret     nz
tf_next:
        ld      a, (TlBc)
        inc     a
        ld      (TlBc), a
        cp      5
        jr      c, tf_cell
        ld      a, (TlBr)
        inc     a
        ld      (TlBr), a
        cp      5
        jr      c, tf_row
        ret
tf_mul48:
        db      0, 48, 96, 144, 192

; ------------------------------------------------------------ small helpers
tr_name:                                ; A = the name for cell (TlRow, TlCol)
        push    af
        call    tr_nameaddr
        call    tl_wr
        pop     af
        out     ($be), a
        ret
tr_nameaddr:
        ld      a, (TlRow)
        ld      l, a
        ld      h, 0
        add     hl, hl
        add     hl, hl
        add     hl, hl
        add     hl, hl
        add     hl, hl
        ld      a, (TlCol)
        ld      e, a
        ld      d, $18
        add     hl, de
        ret

; ------------------------------------------------------------ the halves' outline sprites
; tl_halfr: canvas rows TlHrow..+15 of ShBuf from bit TlOff (0-23 from the
; block's left edge) into RAM at TlHdst: 16 left-column bytes, 16 right
; (made once per pose, in the frame that rebuilds ShBuf)
tl_halfr:
        push    ix
        push    iy
        ld      a, (TlOff)
        srl     a
        srl     a
        srl     a
        ld      e, a
        ld      d, 0
        ld      hl, tf_mul48
        add     hl, de
        ld      e, (hl)
        ld      a, (TlHrow)
        add     a, 8
        add     a, e
        ld      e, a
        ld      d, 0
        ld      ix, ShBuf
        add     ix, de
        ld      iy, (TlHdst)
        ld      b, 16
        ld      a, (TlOff)
        and     7
        cp      5
        jr      nc, th_right
        ld      (TlK), a                ; 0-4 bits to the left
th_lrow:
        ld      c, (ix + 0)
        ld      d, (ix + 48)
        ld      e, (ix + 96)
        ld      a, (TlK)
        or      a
        jr      z, th_lst
        ld      h, a
th_ls:
        sla     e
        rl      d
        rl      c
        dec     h
        jr      nz, th_ls
th_lst:
        ld      (iy + 0), c             ; left column byte
        ld      (iy + 16), d            ; right column byte
        inc     ix
        inc     iy
        djnz    th_lrow
        pop     iy
        pop     ix
        ret
th_right:                               ; 5-7 bits left = 3-1 bits right, one byte on
        neg
        add     a, 8
        ld      (TlK), a
th_rrow:
        ld      c, (ix + 0)
        ld      d, (ix + 48)
        ld      e, (ix + 96)
        ld      a, (TlK)
        ld      h, a
th_rs:
        srl     c
        rr      d
        rr      e
        dec     h
        jr      nz, th_rs
        ld      (iy + 0), d
        ld      (iy + 16), e
        inc     ix
        inc     iy
        djnz    th_rrow
        pop     iy
        pop     ix
        ret

; tl_hcopy: 32 bytes from RAM (HL) to the sprite pattern at DE
tl_hcopy:
        ex      de, hl
        call    tl_wr
        ex      de, hl
        ld      b, 32
thc:
        ld      a, (hl)                 ; 7
        out     ($be), a                ; 11
        inc     hl                      ; 6
        djnz    thc                     ; 13 -> 37 T
        ret

; ------------------------------------------------------------ OnGrave (game logic, here for speed)
; FRes = 1 when (GPx, GPy) is on one of the NGv gravestones: x in [GvX*8,
; GvX*8+15], y in [GvY*8+4, GvY*8+16]
og_test:
        xor     a
        ld      (FRes), a
        ld      a, (NGv)
        or      a
        ret     z
        ld      b, a
        ld      hl, GvX
        ld      de, GvY
og_l:
        ld      a, (hl)
        add     a, a
        add     a, a
        add     a, a
        ld      c, a                    ; left edge
        ld      a, (GPx)
        sub     c
        cp      16
        jr      nc, og_n
        ld      a, (de)
        add     a, a
        add     a, a
        add     a, a
        add     a, 4
        ld      c, a                    ; top edge
        ld      a, (GPy)
        sub     c
        cp      13
        jr      nc, og_n
        ld      a, 1
        ld      (FRes), a
        ret
og_n:
        inc     hl
        inc     de
        djnz    og_l
        ret

; FRes = 1 when (GPx, GPy) is on the sprinkler's wet grass: x in [SpX*8-8,
; SpX*8+24], y in [SpY*8-4, SpY*8+24]
sp_test:
        xor     a
        ld      (FRes), a
        ld      a, (SpX)
        add     a, a
        add     a, a
        add     a, a
        sub     8
        ld      c, a
        ld      a, (GPx)
        sub     c
        cp      33
        ret     nc
        ld      a, (SpY)
        add     a, a
        add     a, a
        add     a, a
        sub     4
        ld      c, a
        ld      a, (GPy)
        sub     c
        cp      29
        ret     nc
        ld      a, 1
        ld      (FRes), a
        ret

; ------------------------------------------------------------ r5.2: full power and the near miss
; Kick, after a hit: a charge of 42..47 (the last 6 frames before he loses his
; balance) is a full-power kick: PMode = 1, 4 low hops all round the yard at
; 30..45/16 px a frame (the direction pad picks up or down, else at random)
pw_kick:
        xor     a
        ld      (PMode), a
        ld      a, (ZCharge)
        cp      42
        ret     c
        ld      a, 1
        ld      (PMode), a
        ld      a, 4
        ld      (PHops), a
        ld      a, 20
        ld      (CVz), a
        call    AMY_UPROC_Rnd
        ld      a, (R2)
        and     15
        add     a, 30
        ld      c, a
        ld      a, (ZFace)
        or      a
        ld      a, 128
        jr      nz, pk_l
        add     a, c
        jr      pk_x
pk_l:
        sub     c
pk_x:
        ld      (CVx), a
        call    AMY_UPROC_Rnd
        ld      a, (R2)
        ld      b, a
        and     15
        add     a, 14
        ld      c, a
        ld      a, (IDn)
        or      a
        jr      nz, pk_d
        ld      a, (IU)
        or      a
        jr      nz, pk_u
        bit     4, b
        jr      nz, pk_d
pk_u:
        ld      a, 128
        sub     c
        jr      pk_y
pk_d:
        ld      a, 128
        add     a, c
pk_y:
        ld      (CVy), a
        ret

; one frame of a flight with PMode <> 0 (CState = 1). D8 tells the game:
; 1 a thud, 2 a cluck, 3 no empty basket (land), 4 in basket PBk
pw_step:
        xor     a
        ld      (D8), a
        ld      a, 60
        ld      (KVisT), a              ; ninja: seen all the way, and 1 s after
        ld      a, (PMode)
        cp      1
        jr      nz, pw_home
        ld      a, (CVx)
        ld      c, a
        ld      a, (CVy)
        ld      b, a
        push    bc
        call    pw_mv
        call    pw_fence
        jr      pf4

; the fence and the lawn edges throw it back (the speed reversed)
pw_fence:
        ld      hl, (CX)
        ld      de, 16*16
        or      a
        sbc     hl, de
        jr      nc, pf1
        ld      (CX), de
        call    pw_nx
pf1:
        ld      hl, 236*16
        ld      de, (CX)
        or      a
        sbc     hl, de
        jr      nc, pf2
        ld      hl, 236*16
        ld      (CX), hl
        call    pw_nx
pf2:
        ld      hl, (CY)
        ld      de, 104*16
        or      a
        sbc     hl, de
        jr      nc, pf3
        ld      (CY), de
        call    pw_ny
pf3:
        ld      hl, 170*16
        ld      de, (CY)
        or      a
        sbc     hl, de
        jr      nc, pf3r
        ld      hl, 170*16
        ld      (CY), hl
        jp      pw_ny
pf3r:
        ret
pf4:
        ; the obstacles (it is always low): back off, full speed back
        ld      hl, RicoT
        ld      a, (hl)
        or      a
        jr      z, pw_o
        dec     (hl)
        jr      pw_o2
pw_o:
        call    pw_pix
        call    og_test
        ld      a, (FRes)
        or      a
        jr      z, pw_o2
        call    pw_nx
        call    pw_ny
        call    pw_mv
        ld      a, 8
        ld      (RicoT), a
pw_o2:
        pop     bc
        ld      a, (CVx)
        cp      c
        jr      nz, pw_t
        ld      a, (CVy)
        cp      b
        jr      z, pw_z
pw_t:
        ld      a, 1
        ld      (D8), a
pw_z:
        call    pw_hopz
        ret     nc
        ld      hl, PHops
        dec     (hl)
        jr      z, pw_bk
        ld      a, 20
        ld      (CVz), a
        ld      a, 1
        ld      (CUp), a
        ld      a, 2
        ld      (D8), a
        ret
pw_bk:
        ; the last hop: to the nearest empty basket, in 32 frames
        call    pw_pix
        ld      a, 255
        ld      (HRes), a
        ld      a, (NBk)
        or      a
        jr      z, pw_none
        ld      b, a
        ld      c, 0
pb_l:
        call    pw_bd
        or      a
        jr      nz, pb_n
        ld      a, d
        srl     a
        ld      d, a
        ld      a, e
        srl     a
        add     a, d
        ld      hl, HRes
        cp      (hl)
        jr      nc, pb_n
        ld      (hl), a
        ld      a, c
        ld      (PBk), a
pb_n:
        inc     c
        djnz    pb_l
        ld      a, (HRes)
        inc     a
        jr      z, pw_none
        ld      a, 2
        ld      (PMode), a
        ld      a, 32
        ld      (PN), a
        jr      pw_hset
pw_none:
        ld      a, 3
        ld      (D8), a
        ret

; the hop into basket PBk: a straight line and an arc, PN frames
pw_home:
        ld      hl, (CX)
        ld      de, (PSx)
        ld      a, (PXn)
        call    pw_add
        ld      (CX), hl
        ld      hl, (CY)
        ld      de, (PSy)
        ld      a, (PYn)
        call    pw_add
        ld      (CY), hl
        call    pw_hopz
        ld      hl, PN
        dec     (hl)
        ret     nz
        call    pw_tgt
        ld      (CX), hl
        ld      (CY), de
        ld      hl, 0
        ld      (CH), hl
        call    pw_pix
        ld      a, 4
        ld      (D8), a
        ret

; Fly (a plain kick), the Amy code of r5.1 in asm (same physics): the fence,
; a ricochet off a gravestone when low (slower: half speed, Ric = 1), the
; height; D8 bit 0: the thud, bit 1: on the ground (Land)
pw_fly:
        xor     a
        ld      (D8), a
        call    pw_mv
        call    pw_fence
        ld      hl, RicoT
        ld      a, (hl)
        or      a
        jr      z, pf_r
        dec     (hl)
        jr      nz, pf_h
pf_r:
        ld      hl, (CH)
        ld      de, 160
        or      a
        sbc     hl, de
        jr      nc, pf_h
        call    pw_pix
        call    og_test
        ld      a, (FRes)
        or      a
        jr      z, pf_h
        call    pw_nx
        call    pw_ny
        call    pw_mv
        ld      a, (CVx)
        call    pw_half
        ld      (CVx), a
        ld      a, (CVy)
        call    pw_half
        ld      (CVy), a
        ld      a, 10
        ld      (RicoT), a
        ld      a, 1
        ld      (Ric), a
        ld      (D8), a
pf_h:
        call    pw_hopz
        ret     nc
        ld      hl, D8
        set     1, (hl)
        ret

; a biased speed (128 = still) halved, towards 0 (as Half)
pw_half:
        sub     128
        jr      nc, phf_p
        neg
        srl     a
        neg
        jr      phf_e
phf_p:
        srl     a
phf_e:
        add     a, 128
        ret

; Land: the first empty basket within 10 x 9 px of its middle: FRes = 1, PBk;
; else the near miss (pw_near)
pw_land:
        xor     a
        ld      (FRes), a
        ld      a, (NBk)
        or      a
        ret     z
        ld      b, a
        ld      c, 0
pl_l:
        call    pw_bd
        or      a
        jr      nz, pl_n
        ld      a, d
        cp      10
        jr      nc, pl_n
        ld      a, e
        cp      9
        jr      nc, pl_n
        ld      a, c
        ld      (PBk), a
        ld      a, 1
        ld      (FRes), a
        ret
pl_n:
        inc     c
        djnz    pl_l

; Land, no basket under it: within 20 x 16 px of an empty basket's middle,
; PMode = 3 and a 16-frame hop into it (Cpx, Cpy set)
pw_near:
        ld      a, (NBk)
        or      a
        ret     z
        ld      b, a
        ld      c, 0
pn_l:
        call    pw_bd
        or      a
        jr      nz, pn_n
        ld      a, d
        cp      20
        jr      nc, pn_n
        ld      a, e
        cp      16
        jr      nc, pn_n
        ld      a, c
        ld      (PBk), a
        ld      a, 3
        ld      (PMode), a
        ld      a, 16
        ld      (PN), a
        jr      pw_hset
pn_n:
        inc     c
        djnz    pn_l
        ret

; the hop's step (PSx, PSy: the distance / PN, signs PXn, PYn) and its arc
pw_hset:
        call    pw_tgt
        push    de
        ld      de, (CX)
        call    pw_d
        ld      (PXn), a
        ld      (PSx), hl
        pop     hl
        ld      de, (CY)
        call    pw_d
        ld      (PYn), a
        ex      de, hl
        ld      hl, (PSx)
        ld      a, (PN)
        ld      b, 4
        cp      32
        jr      nz, ps_l
        inc     b
ps_l:
        srl     h
        rr      l
        srl     d
        rr      e
        djnz    ps_l
        ld      (PSx), hl
        ld      (PSy), de
        ld      (CVz), a                ; an arc of about PN frames
        ld      a, (PXn)
        ld      b, a
        ld      a, 129
        sub     b
        sub     b
        ld      (CVx), a                ; for the side it faces
        ld      a, 1
        ld      (CUp), a
        ld      hl, 0
        ld      (CH), hl
        ret

; HL = |HL - DE|, A = 1 when HL < DE
pw_d:
        xor     a
        sbc     hl, de
        ret     nc
        ld      a, h
        cpl
        ld      h, a
        ld      a, l
        cpl
        ld      l, a
        inc     hl
        ld      a, 1
        ret

; HL += DE (A = 0) or HL -= DE
pw_add:
        or      a
        jr      nz, pa_s
        add     hl, de
        ret
pa_s:
        sbc     hl, de
        ret

; HL, DE: basket PBk's middle (feet) in 1/16 px: BkX*128+128, BkY*128+160
pw_tgt:
        ld      a, (PBk)
        ld      c, a
        ld      hl, BkY
        call    pw_ix
        ld      d, a
        ld      e, 0
        srl     d
        rr      e
        ld      hl, 160
        add     hl, de
        push    hl
        ld      hl, BkX
        call    pw_ix
        inc     a
        ld      h, a
        ld      l, 0
        srl     h
        rr      l
        pop     de
        ret

; basket C: D = |Cpx - its middle x|, E = |Cpy - its middle y|, A = BkFull[C]
pw_bd:
        ld      hl, BkX
        call    pw_ix
        add     a, a
        add     a, a
        add     a, a
        add     a, 8
        ld      d, a
        ld      a, (Cpx)
        sub     d
        jr      nc, pb1
        neg
pb1:
        ld      d, a
        ld      hl, BkY
        call    pw_ix
        add     a, a
        add     a, a
        add     a, a
        add     a, 10
        ld      e, a
        ld      a, (Cpy)
        sub     e
        jr      nc, pb2
        neg
pb2:
        ld      e, a
        ld      hl, BkFull
pw_ix:
        ld      a, c
        add     a, l
        ld      l, a
        ld      a, 0
        adc     a, h
        ld      h, a
        ld      a, (hl)
        ret

; CX += CVx - 128, CY += CVy - 128
pw_mv:
        ld      a, (CVx)
        ld      hl, (CX)
        call    pw_v
        ld      (CX), hl
        ld      a, (CVy)
        ld      hl, (CY)
        call    pw_v
        ld      (CY), hl
        ret
pw_v:
        sub     128
        ld      e, a
        sbc     a, a
        ld      d, a
        add     hl, de
        ret

pw_nx:
        ld      a, (CVx)
        neg
        ld      (CVx), a
        ret
pw_ny:
        ld      a, (CVy)
        neg
        ld      (CVy), a
        ret

; Cpx, GPx = CX / 16; Cpy, GPy = CY / 16
pw_pix:
        ld      hl, (CX)
        call    pw_s4
        ld      (Cpx), a
        ld      (GPx), a
        ld      hl, (CY)
        call    pw_s4
        ld      (Cpy), a
        ld      (GPy), a
        ret
pw_s4:
        ld      b, 4
p4_l:
        srl     h
        rr      l
        djnz    p4_l
        ld      a, l
        ret

; the flight's height, as Fly: up while CVz lasts, then down (gravity 2);
; carry set on the ground
pw_hopz:
        ld      hl, (CH)
        ld      a, (CUp)
        or      a
        jr      z, ph_dn
        ld      a, (CVz)
        ld      e, a
        ld      d, 0
        add     hl, de
        ld      (CH), hl
        cp      3
        jr      c, ph_top
        sub     2
        ld      (CVz), a
        ret
ph_top:
        xor     a
        ld      (CUp), a
        ld      (CVz), a
        ret
ph_dn:
        ld      a, (CVz)
        add     a, 2
        ld      (CVz), a
        ld      e, a
        ld      d, 0
        or      a
        sbc     hl, de
        jr      z, ph_gr
        jr      c, ph_gr
        ld      (CH), hl
        ret
ph_gr:
        ld      hl, 0
        ld      (CH), hl
        scf
        ret
