# build.py - ZOMBIE BOTTE POULET r5: art, packing, sound table, texts, the program,
# then the 128 KB MegaCart image.
#   AMY_TOOLCHAIN=<Amy Studio r12.11 toolchain> python3 build.py [outdir]
# Writes <outdir>/zombie-botte-poulet.alexis, .rom (128 KB MegaCart), .asm, .sym,
# and banks.txt (what each bank holds).
#
# MegaCart layout (8 banks of 16 KB; bank 7 is the fixed one at $8000):
#   bank 7  fixed, $8000-$BFFF: the first 16 KB of the Amy program: the runtime,
#           the NMI handler, most of the game's code. (Amy places the asm block
#           - zombie frames, RevTab, tiles.asm, zup_upload, the sound table, the
#           AMYZ decoder, the bank routines - after the code and the data, in
#           the home bank: the play loop reads the fixed and the home bank,
#           which are both mapped during play.)
#   banks 6, 5, 4 "home" (acts I, II, III), $C000-$FFBF: the rest of the Amy
#           program, each with its act's music, egg tune and level tables at
#           the same addresses (act III: also the sunglasses tables). Selected
#           at boot and all the time, except inside bk_unpack / bk_page (fixed
#           bank code, NMI off) while they read a data bank
#   banks 0-3  data: AMYZ picture streams of the three acts, text pages; only
#           read at screen set-up (and the name table reload of LawnBand)
# The Amy program is compiled as an ordinary cartridge ($8000-$FFBF, at most
# 32704 bytes) and cut in two (see RAPPORT.md: why not Amy's own MegaCart
# project build).
import os, sys, shutil, subprocess, re
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.path.join(HERE, 'build')
TC = os.environ.get('AMY_TOOLCHAIN') or os.path.abspath(os.path.join(HERE, '../../cxt2'))
AMYC = os.path.join(TC, 'tools', 'amyc.mjs')
if not os.path.exists(AMYC):
    sys.exit(f"build.py: no amyc at {AMYC}; set AMY_TOOLCHAIN to the r12.11 toolchain folder")
os.makedirs(OUT, exist_ok=True)
for d in ('packin', 'pagein'):
    shutil.rmtree(os.path.join(OUT, d), ignore_errors=True)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
def run(*a):
    subprocess.run(list(a), check=True, cwd=HERE, env=env)
HOME_BANK, FIXED_BANK, NBANKS = 2, 3, 4
# r5.1, 64 KB: bank 3 fixed; bank 2 home of act I, the title and the menus;
# bank 1 home of acts II and III (the same program, with act II's music, egg
# tune and levels at act I's addresses, and act III's in room that is dead
# in that bank: the title tune's place and the menu screens' code); bank 0 data
HOME_B = 1
ACT_HOME = {1: HOME_BANK, 2: HOME_B, 3: HOME_B}
NDATA = 1
BANK = 16384
# 1. art (gfx.amy + streams), 2. AMYZ packing
run(sys.executable, 'art.py', OUT)
run('node', 'pack.mjs', OUT)
pin = os.path.join(OUT, 'packin')
# 3. sound table, 4. text pages (pagein/*.bin)
run(sys.executable, os.path.join('common', 'tools', 'os7music.py'), 'music/title.txt', 'music/game.txt', 'music/egg1.txt',
    '--inc', os.path.join(OUT, 'sounds.asm'), '--consts', os.path.join(OUT, 'sndconst.txt'))
def song_blocks(asm_text):
    """label -> bytes of an os7music include"""
    out, cur = {}, None
    for line in asm_text.split('\n'):
        m = re.match(r'^(\w+):\s*$', line)
        if m:
            cur = m.group(1); out[cur] = bytearray(); continue
        if cur and re.match(r'^\s+db ', line):
            out[cur] += bytes(int(v.strip().replace('$', ''), 16) for v in line.split('db', 1)[1].split(','))
        elif cur and line.strip() and not line.strip().startswith(';'):
            cur = None
    return out
VARIANTS = {2: ['music/winter.txt', 'music/egg2.txt'], 3: ['music/summer.txt', 'music/egg3.txt']}
vsong = {}
for act, files in VARIANTS.items():
    vsong[act] = {}
    for f in files:
        tmp = os.path.join(OUT, 'song-' + os.path.basename(f).replace('.txt', '.asm'))
        run(sys.executable, os.path.join('common', 'tools', 'os7music.py'), f, '--inc', tmp)
        vsong[act].update({k: v for k, v in song_blocks(open(tmp).read()).items() if k.startswith(('Mg', 'Eg'))})
main_snd = open(os.path.join(OUT, 'sounds.asm')).read()
base_song = song_blocks(main_snd)
SLOTS = [f'{p}{v}' for p in ('Mg', 'Eg') for v in ('Lead', 'Two', 'Noise', 'Pitch')]
slot_len = {k: max(len(base_song[k]), len(vsong[2][k])) for k in SLOTS}
# each slot padded to the longer of act I's and act II's version
lines, cur = [], None
for line in main_snd.split('\n'):
    m = re.match(r'^(\w+):\s*$', line)
    if cur and not re.match(r'^\s+db ', line):
        if slot_len[cur] > len(base_song[cur]):
            lines.append(f'    ds {slot_len[cur] - len(base_song[cur])}, 0   ; r5: room for the other acts\' version')
        cur = None
    if m and m.group(1) in SLOTS:
        cur = m.group(1)
    lines.append(line)
main_snd = '\n'.join(lines)
# act III in the acts II-III bank: its tune in the title tune's voices (the
# same table entries SndMt*), its egg tune and its level table in what is left
# of those voices; four more table entries (SndXg*) for the egg tune
MTV = ['MtLead', 'MtTwo', 'MtNoise', 'MtPitch']
mt_off, o = {}, 0
for k in MTV:
    mt_off[k] = o; o += len(base_song[k])
act3 = {}                                         # offset from MtLead -> bytes
gaps = []
for k, v in zip(MTV, ('Lead', 'Two', 'Noise', 'Pitch')):
    b = vsong[3]['Mg' + v]
    assert len(b) <= len(base_song[k]), (k, len(b))
    act3[mt_off[k]] = b
    gaps.append([mt_off[k] + len(b), mt_off[k] + len(base_song[k])])
def gap_fit(n):
    for g in sorted(gaps, key=lambda g: g[1] - g[0]):
        if g[1] - g[0] >= n:
            a = g[0]; g[0] += n
            return a
    sys.exit(f"build.py: no room for {n} bytes of act III in the title tune's place")
xg = {}
for v in ('Lead', 'Two', 'Noise', 'Pitch'):
    b = vsong[3]['Eg' + v]
    xg[v] = gap_fit(len(b)); act3[xg[v]] = b
LV3 = gap_fit(132)
AREAS = {'Lead': '$702B', 'Two': '$7035', 'Noise': '$703F', 'Pitch': '$7049'}
nconst = max(int(x) for x in re.findall(r'^const Snd\w+ = (\d+)', open(os.path.join(OUT, 'sndconst.txt')).read(), re.M))
ins = ''.join(f"    dw MtLead + {xg[v]},{AREAS[v]}   ; r5.1: act III's egg tune (acts II-III bank)\n" for v in AREAS)
assert '    dw 0\n' in main_snd
main_snd = main_snd.replace('    dw 0\n', ins + '    dw 0\n', 1)
open(os.path.join(OUT, 'sndconst.txt'), 'a').write(''.join(f"const SndXg{v} = {nconst + 1 + i}\n" for i, v in enumerate(AREAS)))
main_snd += f"\nLvAll3 equ MtLead + {LV3}\n"
open(os.path.join(OUT, 'sounds.asm'), 'w').write(main_snd)
run(sys.executable, 'texts.py', 'pages.txt', os.path.join(OUT, 'pages.amy'))
rd = lambda f: open(f).read().rstrip('\n')

# ---- the data streams: AMYZ blocks from packed.asm, raw page streams
packed = rd(os.path.join(OUT, 'packed.asm'))
streams, head, cur = {}, [], None
for line in packed.split('\n'):
    m = re.match(r'^Pk(\w+):', line)
    if m:
        cur = m.group(1); streams[cur] = bytearray(); continue
    if cur and 'db' in line:
        streams[cur] += bytes(int(v.strip().replace('$', ''), 16) for v in line.split('db', 1)[1].split(','))
    elif not cur:
        head.append(line)
pgdir = os.path.join(OUT, 'pagein')
for f in sorted(os.listdir(pgdir)):
    nm = f[:-4]
    streams[nm[0].upper() + nm[1:]] = bytearray(open(os.path.join(pgdir, f), 'rb').read())
names = sorted(streams)
def allocate(res):
    """first fit, biggest first, into data banks 0-5, around the reserved range
    res = (lo, hi) of $C000 addresses (the mirrored bank routines); the last 64
    bytes of a bank are the mapper"""
    used = [[] for _ in range(NDATA)]          # (start, end) $C000 addresses
    place = {}
    for nm in sorted(names, key=lambda n: (-len(streams[n]), n)):
        ln = len(streams[nm])
        for bk in range(NDATA):
            a = 0xC000
            busy = sorted(used[bk] + ([res] if res else []))
            for lo, hi in busy:
                if a + ln <= lo:
                    break
                a = max(a, hi)
            if a + ln <= 0x10000 - 64:
                place[nm] = (bk, a)
                used[bk].append((a, a + ln))
                break
        else:
            sys.exit(f"build.py: no room for stream {nm}")
    return place
def pktab_of(place):
    return 'PkTab:\n' + '\n'.join(f'    db ${0xC0 + place[n][0]:02X}\n    dw ${place[n][1]:04X}   ; {n}, bank {place[n][0]}, {len(streams[n])} bytes' for n in names)
pkconst = '\n'.join(f'const Pki{n} = {i}' for i, n in enumerate(names))
# lantern colours (game tiles 140-143 of act I), bright and dim, for the glow
gtcol = open(os.path.join(pin, 'gtcol.bin'), 'rb').read()
import importlib.util
gt0 = int(re.search(r'const GtLant00 = (\d+)', rd(os.path.join(OUT, 'gfx.amy'))).group(1))
gtbase = int(re.search(r'const GtFirst = (\d+)', rd(os.path.join(OUT, 'gfx.amy'))).group(1))
lc = gtcol[(gt0 - gtbase) * 8:(gt0 - gtbase + 4) * 8]
dim = bytes(((10 << 4) | (b & 15)) if (b >> 4) == 11 else b for b in lc)
fmt = lambda b: ','.join(f'${v:02X}' for v in b)
pkconst += f'\ndata LantCol bytes {fmt(lc)}\ndata LantDim bytes {fmt(dim)}'
pkconst += f'\nconst GtLantVram = {gt0 * 8}'

LVN = ['LvNBk', 'LvBk', 'LvNGv', 'LvGv', 'LvSp']
LVLEN = [6, 48, 6, 60, 12]
_mtxt = open(os.path.join(HERE, 'main.alexis')).read()
def lv_all(act):
    out = bytearray()
    for n, ln in zip(LVN, LVLEN):
        m = re.search(rf"^' @act{act} {n} (.*)$", _mtxt, re.M)
        v = bytes(int(x) for x in m.group(1).replace(' ', '').split(','))
        assert len(v) == ln, (act, n, len(v))
        out += v
    return out
LVALL = {a: lv_all(a) for a in (1, 2, 3)}
import json as _js
_sh = _js.load(open(os.path.join(OUT, 'shades.json')))
SHGP = 2 * len(_sh['gp']) + sum(len(l[0]) for l in _sh['gp'])
# ---- the program (twice: the first compile finds where the bank routines
# land, the streams are placed around that range, the second has the table)
zfr = rd(os.path.join(OUT, 'zframes.asm'))
alexis = os.path.join(OUT, 'zombie-botte-poulet.alexis')
prog = os.path.join(OUT, 'program.bin')
opt = os.environ.get('AMY_OPT', 'balanced')
def compile_with(place):
    src = open(os.path.join(HERE, 'main.alexis')).read()
    parts = {'@@GFX@@': rd(os.path.join(OUT, 'gfx.amy')), '@@SNDCONST@@': rd(os.path.join(OUT, 'sndconst.txt')),
             '@@CORE@@': rd(os.path.join(HERE, 'common', 'amy', 'core.alexis')), '@@PAGES@@': rd(os.path.join(OUT, 'pages.amy')),
             '@@PKCONST@@': pkconst, '@@SOUNDS@@': rd(os.path.join(OUT, 'sounds.asm')),
             '@@TILES@@': rd(os.path.join(HERE, 'tiles.asm')), '@@ZFRAMES@@': zfr,
             '@@DECODER@@': rd(os.path.join(HERE, 'amyzf_vram.asm')), '@@PKTAB@@': '\n'.join(head) + '\n' + pktab_of(place),
             '@@HOME@@': f'${0xC0 + HOME_BANK:02X}', '@@HOMEA@@': f'${0xC0 + HOME_BANK:02X}', '@@HOMEB@@': f'${0xC0 + HOME_B:02X}',
             '@@LVALL@@': 'LvAll:\n    db ' + ','.join(str(v) for v in LVALL[1]),
             '@@SHADES@@': f'GpTab equ AMY_UPROC_TextScreen\nGlTab equ AMY_UPROC_TextScreen + {SHGP}'}
    for k, v in parts.items():
        assert k in src, k
        src = src.replace(k, v)
    open(alexis, 'w').write(src)
    if os.path.exists(prog):
        os.remove(prog)
    r = subprocess.run(['node', AMYC, alexis, '--rom', prog, '--asm', os.path.join(OUT, 'zombie-botte-poulet.asm'),
                        '--symbols', os.path.join(OUT, 'zombie-botte-poulet.sym'), '--opt', opt],
                       cwd=HERE, env=env, capture_output=True, text=True)
    if r.returncode or not os.path.exists(prog):
        sys.stdout.write(r.stdout[-3000:]); sys.stderr.write(r.stderr)
        sys.exit("build.py: the compile failed")
    sym = rd(os.path.join(OUT, 'zombie-botte-poulet.sym'))
    ad = lambda lab: int(re.search(rf'^{lab}: equ \$([0-9A-F]+)', sym, re.M).group(1), 16)
    return r, open(prog, 'rb').read(), ad
r, pb, ad = compile_with({n: (0, 0xC000) for n in names})
lo, hi = ad('bk_find'), ad('bk_mirror_end')
res = (max(lo, 0xC000), hi) if hi > 0xC000 else None
place = allocate(res)
r, pb, ad = compile_with(place)
assert (ad('bk_find'), ad('bk_mirror_end')) == (lo, hi), "the bank routines moved between the two compiles"
sys.stdout.write('\n'.join(l for l in r.stdout.split('\n') if l.startswith(('RAM', 'ROM'))) + '\n')
assert len(pb) <= 32704, f"program is {len(pb)} bytes: more than $8000-$FFBF"
fxend = ad('fx_end')
# ---- the MegaCart image
img = bytearray(b'\xFF' * (NBANKS * BANK))
for nm in names:
    bk, a = place[nm]
    o = bk * BANK + a - 0xC000
    img[o:o + len(streams[nm])] = streams[nm]
if res:
    for bk in range(NDATA):
        img[bk * BANK + res[0] - 0xC000:bk * BANK + res[1] - 0xC000] = pb[res[0] - 0x8000:res[1] - 0x8000]
img[FIXED_BANK * BANK:FIXED_BANK * BANK + min(BANK, len(pb))] = pb[:BANK]
# act III's sunglasses tables (GpTab, GlTab) over the menu screens' code
# (TextScreen .. TitleScreen, which only ever runs with act I's home bank)
import json
sh = json.load(open(os.path.join(OUT, 'shades.json')))
gp_at, gl_at = ad('GpTab'), ad('GlTab')
def shades_bin(lists, base):
    n = len(lists)
    body, ptr = bytearray(), []
    for l in lists:
        ptr.append(base + 2 * n + len(body))
        body += bytes(l[0])
    return bytes(b for a in ptr for b in (a & 255, a >> 8)) + bytes(body)
gpb = shades_bin(sh['gp'], gp_at)
glb = shades_bin(sh['gl'], gl_at)
menu_lo, menu_hi = ad('AMY_UPROC_TextScreen'), ad('AMY_INIT_RAM_DATA_0')
assert gp_at == menu_lo and gl_at == gp_at + len(gpb) and menu_lo >= 0xC000
assert gl_at + len(glb) <= menu_hi, ("the sunglasses do not fit over the menu code", gl_at + len(glb) - menu_hi)
assert ad('AMY_UPROC_TitleScreen') < menu_hi and ad('AMY_UPROC_SetAct') < menu_lo
mt0 = ad('MtLead')
for hb in sorted(set(ACT_HOME.values())):
    hp = bytearray(pb[BANK:])
    if hb == HOME_B:
        for k in SLOTS:
            a = ad(k)
            assert a >= 0xC000, k
            hp[a - 0xC000:a - 0xC000 + len(vsong[2][k])] = vsong[2][k]
        a = ad('LvAll')
        assert a >= 0xC000
        hp[a - 0xC000:a - 0xC000 + 132] = LVALL[2]
        for off, bb in act3.items():
            hp[mt0 + off - 0xC000:mt0 + off - 0xC000 + len(bb)] = bb
        hp[mt0 + LV3 - 0xC000:mt0 + LV3 - 0xC000 + 132] = LVALL[3]
        hp[gp_at - 0xC000:gp_at - 0xC000 + len(gpb)] = gpb
        hp[gl_at - 0xC000:gl_at - 0xC000 + len(glb)] = glb
    img[hb * BANK:hb * BANK + len(hp)] = hp
# the power-on bank is not known: the cartridge entry (header $800A) goes to a
# stub in the unused RST $28/$30 slots that selects the home bank first, so
# the Amy start-up code (it copies AMY_INIT_RAM_DATA, in the home bank) reads it
fx = FIXED_BANK * BANK
start = img[fx + 0x0A] | img[fx + 0x0B] << 8
assert bytes(img[fx + 0x18:fx + 0x1E]) == bytes([0xC9, 0, 0, 0xC9, 0, 0]), bytes(img[fx + 0x18:fx + 0x1E]).hex()
img[fx + 0x18:fx + 0x1E] = bytes([0x3A, 0xC0 + HOME_BANK, 0xFF, 0xC3, start & 255, start >> 8])
img[fx + 0x0A:fx + 0x0C] = bytes([0x18, 0x80])
assert img[0:2] not in (b'\xAA\x55', b'\x55\xAA')
rom = os.path.join(OUT, 'zombie-botte-poulet.rom')
open(rom, 'wb').write(img)
with open(os.path.join(OUT, 'banks.txt'), 'w') as f:
    f.write(f"fixed bank {FIXED_BANK}: {min(BANK, len(pb))} bytes of 16384 (the asm block ends at ${fxend:04X})\n")
    f.write(f"home bank {HOME_BANK} (act I, title, menus) and {HOME_B} (acts II, III): {max(0, len(pb) - BANK)} bytes of 16320\n")
    f.write(f"bank {HOME_B}: act III tune and egg tune in the title tune's place (${mt0:04X}), its levels at ${mt0 + LV3:04X}; sunglasses over the menu code ${menu_lo:04X}-${gl_at + len(glb):04X} (room to ${menu_hi:04X})\n")
    f.write(f"bank routines bk_find-bk_mirror_end: ${lo:04X}-${hi:04X} (copied into data bank 0 at the same addresses)\n")
    for b in range(NDATA):
        f.write(f"data bank {b}: {sum(len(streams[n]) for n in names if place[n][0] == b)} bytes: " + ', '.join(n for n in names if place[n][0] == b) + '\n')
print(open(os.path.join(OUT, 'banks.txt')).read().rstrip())
print(f"build.py: {rom} ({len(img)} bytes, program {len(pb)} bytes)")
