#!/bin/bash
# rebuild.sh <port folder> <rom name> - empty-folder rebuild check.
# Copies the port's sources and ../_common into a fresh temporary folder,
# runs build.py there, and compares the new ROM's SHA-256 with the one in
# <port>/build. Prints both hashes and IDENTICAL or DIFFERENT (exit 1).
set -e
PORT=$(cd "$1" && pwd); ROM=$2
COMMON=$(cd "$(dirname "$0")/.." && pwd)
T=$(mktemp -d)
mkdir -p "$T/ports"
cp -r "$COMMON" "$T/ports/_common"
mkdir "$T/ports/$(basename "$PORT")"
( cd "$PORT" && tar cf - --exclude=build --exclude='tests/out*' --exclude='*.zip' --exclude=dist --exclude=__pycache__ . ) | ( cd "$T/ports/$(basename "$PORT")" && tar xf - )
find "$T" -name __pycache__ -prune -exec rm -rf {} +
TC=${AMY_TOOLCHAIN:-$(cd "$COMMON/../../../../cx2/r12.10/toolchain" && pwd)}
( cd "$T/ports/$(basename "$PORT")" && AMY_TOOLCHAIN="$TC" python3 build.py > "$T/build.log" 2>&1 ) || { cat "$T/build.log"; exit 1; }
A=$(sha256sum "$PORT/build/$ROM" | cut -d' ' -f1)
B=$(sha256sum "$T/ports/$(basename "$PORT")/build/$ROM" | cut -d' ' -f1)
echo "original  $A  $PORT/build/$ROM"
echo "rebuilt   $B  (empty folder $T)"
grep -E "^ROM  [0-9]|^RAM" "$T/build.log" || true
if [ "$A" = "$B" ]; then echo IDENTICAL; rm -rf "$T"; else echo DIFFERENT; exit 1; fi
