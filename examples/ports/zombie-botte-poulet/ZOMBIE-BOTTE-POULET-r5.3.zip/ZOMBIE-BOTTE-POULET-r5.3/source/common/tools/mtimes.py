"""mtimes.py <folder> [out.txt] - every file's real modification time, America/Toronto."""
import os, sys
from datetime import datetime
from zoneinfo import ZoneInfo
root = sys.argv[1]; tz = ZoneInfo('America/Toronto'); rows = []
for d, _, fs in os.walk(root):
    for f in fs:
        p = os.path.join(d, f)
        if '__pycache__' in p:
            continue
        t = datetime.fromtimestamp(os.path.getmtime(p), tz)
        rows.append((os.path.relpath(p, root), t.strftime('%Y-%m-%d %H:%M:%S %Z'), os.path.getsize(p)))
out = ["Last modification times (America/Toronto)", ""] + [f"{t}  {s:>8}  {n}" for n, t, s in sorted(rows)]
txt = "\n".join(out) + "\n"
if len(sys.argv) > 2:
    open(sys.argv[2], 'w').write(txt)
else:
    print(txt)
