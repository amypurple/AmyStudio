// wavgrab: records a ROM's sound to a WAV file, with a loudness line per
// frame, to hear and check tunes and effects without a ColecoVision.
//   node test/wavgrab.mjs game.rom game.asm out.wav [frames] [press-at-frame]
import { writeFileSync } from "node:fs";
import { findBios } from "./portlib.mjs";   // first: sets AMY_STUDIO for the harness
import { openGame } from "./harness.mjs";
const [rom, asm, out, nf = "600", pressAt = "-1"] = process.argv.slice(2);
const g = await openGame(rom, asm, { bios: findBios() });
const chunks = [], rms = [];
let rate = 44100;
for (let f = 0; f < +nf; f++) {
  if (f === +pressAt) g.press();
  g.run(1);
  const a = g.core.getAudioFrame();
  rate = a.sampleRate;
  const mono = new Int16Array(a.frameCount);
  let s = 0;
  for (let i = 0; i < a.frameCount; i++) { mono[i] = (a.samples[2 * i] + a.samples[2 * i + 1]) >> 1; s += mono[i] * mono[i]; }
  chunks.push(mono);
  rms.push(Math.sqrt(s / Math.max(1, a.frameCount)));
}
const n = chunks.reduce((t, c) => t + c.length, 0);
const buf = Buffer.alloc(44 + n * 2);
buf.write("RIFF", 0); buf.writeUInt32LE(36 + n * 2, 4); buf.write("WAVEfmt ", 8);
buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
buf.writeUInt32LE(rate, 24); buf.writeUInt32LE(rate * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34);
buf.write("data", 36); buf.writeUInt32LE(n * 2, 40);
let o = 44; for (const c of chunks) for (const v of c) { buf.writeInt16LE(v, o); o += 2; }
writeFileSync(out, buf);
console.log(out, (n / rate).toFixed(1) + " s", "peak rms", Math.max(...rms).toFixed(0));
console.log(rms.map(v => " .:-=+*#%@"[Math.min(9, Math.floor(v / 400))]).join(""));
