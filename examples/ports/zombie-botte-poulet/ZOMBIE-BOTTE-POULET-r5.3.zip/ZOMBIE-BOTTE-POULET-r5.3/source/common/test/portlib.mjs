// portlib.mjs - shared test helpers for the Oric -> ColecoVision ports.
//
//   import { openPort, IN, dirMask } from "../_common/test/portlib.mjs";
//   const p = await openPort("build/game");           // game.rom + game.asm (+ .sym)
//   p.boot();                                         // OS7 logo, until the cartridge runs
//   p.frameWatch("Phase", 1, "Tick");                 // lost-frame counter for the play loop
//   p.step(mask)                                      // one frame with that controller input
//   p.shot("name") / p.sheet([...], "name")          // PNGs (in p.outDir)
//   p.vdp = attachVdpCheck(...) is done by openPort({ vdp: true }); p.vdpReport()
//
// Paths: AMY_STUDIO (the r12.10 toolchain folder, which holds studio/core)
// defaults to scratchpad/cx2/r12.10/toolchain; COLECO_BIOS defaults to the
// toolbox's test/bios2.rom (the real OS7, md5 2c66f591...). Neither is shipped.
import { existsSync, mkdirSync, readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createHash } from "node:crypto";

const here = path.dirname(fileURLToPath(import.meta.url));
const scratch = path.resolve(here, "../../../..");
// the r12.10 compiler package has no emulator; the GearColeco test core comes
// from the newest Amy Studio package that ships it (r12.6)
if (!process.env.AMY_STUDIO) process.env.AMY_STUDIO = path.join(scratch, "cx2/r12.6/toolchain");
const BIOS_CANDIDATES = [process.env.COLECO_BIOS, "/root/.openMSX/share/systemroms/COLECO.ROM", path.join(scratch, "work/kit3/run/test/bios2.rom"),
  path.join(scratch, "os7m/orig/test/bios2.rom")].filter(Boolean);
const OS7_MD5 = "2c66f5911e5b42b8ebe113403548eee7";
export function findBios() {
  for (const b of BIOS_CANDIDATES) {
    if (existsSync(b) && createHash("md5").update(readFileSync(b)).digest("hex") === OS7_MD5) return b;
  }
  throw new Error("no real OS7 BIOS found: set COLECO_BIOS");
}
const { openGame, IN } = await import("./harness.mjs");
const { attachVdpCheck } = await import("./vdpcheck.mjs");
export { IN };

// 8-way direction (dx, dy in -1..1) -> controller bits
export function dirMask(dx, dy) {
  let m = 0;
  if (dx < 0) m |= IN.LEFT; if (dx > 0) m |= IN.RIGHT;
  if (dy < 0) m |= IN.UP; if (dy > 0) m |= IN.DOWN;
  return m;
}

export async function openPort(base, { outDir = ".", vdp = false, seed = 4 } = {}) {
  const bios = findBios();
  const rom = base + ".rom", asm = base + ".asm", sym = base + ".sym";
  mkdirSync(outDir, { recursive: true });
  const g = await openGame(rom, asm, { bios, seed });
  const chk = vdp ? attachVdpCheck(g, { rom, bios, sym: existsSync(sym) ? sym : undefined }) : null;
  const cwd = process.cwd();
  const p = {
    g, IN, chk,
    get frame() { return g.frame; },
    get: n => g.get(n), get16: n => g.get16(n), arr: (n, k) => g.getArray(n, k),
    watch: null,
    // lost frames: frames where the play loop is running (var = value) and
    // the loop's own frame counter did not move
    frameWatch(phaseVar, value, tickVar) {
      p.watch = { phaseVar, value, tickVar, last: g.get(tickVar), frames: 0, lost: 0, lostAt: [] };
    },
    step(mask = 0, n = 1) {
      for (let i = 0; i < n; i++) {
        g.run(1, mask);
        const w = p.watch;
        if (w) {
          const t = g.get(w.tickVar), ph = g.get(w.phaseVar);
          if (ph === w.value) {
            w.frames++;
            if (t === w.last) { w.lost++; if (w.lostAt.length < 50) w.lostAt.push(g.frame); }
            else if (((t - w.last) & 255) > 1) { w.dbl = (w.dbl || 0) + 1; }
          }
          w.last = t;
        }
      }
    },
    press(mask = IN.FIRE_LEFT) { p.step(mask, 8); p.step(0, 8); },
    // run until cond() or max frames; returns true when cond() held
    until(cond, max = 3000, mask = 0) { for (let i = 0; i < max; i++) { if (cond()) return true; p.step(mask); } return cond(); },
    boot() { p.step(0, 900); },
    shot(name) { process.chdir(outDir); try { return g.shot(name); } finally { process.chdir(cwd); } },
    sheet(names, out, perRow = 3) { process.chdir(outDir); try { return g.sheet(names, out, perRow); } finally { process.chdir(cwd); } },
    vdpReport() { return chk ? chk.report() : null; },
    lost() { return p.watch ? { frames: p.watch.frames, lost: p.watch.lost, double: p.watch.dbl || 0, lostAt: p.watch.lostAt } : null; },
  };
  return p;
}
