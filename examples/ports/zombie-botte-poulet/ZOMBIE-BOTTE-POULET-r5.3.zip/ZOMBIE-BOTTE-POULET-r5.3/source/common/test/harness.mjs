// harness.mjs: play an Amy ROM in the GearColeco test core from a script.
//
//   import { openGame, IN } from "../../test/harness.mjs";
//   const g = await openGame("mygame.rom", "mygame.asm");   // asm from amyc --asm
//   g.run(60);                       // 60 frames, no input
//   g.press(IN.FIRE_LEFT);           // tap a button (8 frames down, 8 up)
//   g.hold(IN.RIGHT, 30);            // hold the stick for 30 frames
//   g.get("Px"); g.getArray("MoX", 6); g.get16("Score");
//   g.shot("title");                 // writes title.png (256 x 192)
//   g.loopRate("Tick", 120)          // game-loop passes in 120 frames
//   g.sheet(["a", "b", "c"], "sheet") // the shots side by side, sheet.png
//
// The ROM runs on test/bios2.rom, the real OS7 BIOS that setup.sh copies
// from $COLECO_BIOS (md5 2c66f5911e5b42b8ebe113403548eee7; not shipped),
// so the COLECOVISION logo screen runs first: the cartridge starts about
// 780-820 frames after power-on. test/mkbios.py can write a small stand-in
// BIOS without OS7's sound and logo code, for tests only.
// Input bits: IN.UP, IN.DOWN, IN.LEFT, IN.RIGHT, IN.FIRE_LEFT, IN.FIRE_RIGHT
// (combine with |). Controller 1 is used.
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { deflateSync } from "node:zlib";
import { fileURLToPath } from "node:url";
import path from "node:path";

const here = path.dirname(fileURLToPath(import.meta.url));
const studio = process.env.AMY_STUDIO || path.join(here, "../amy");
if (!existsSync(path.join(studio, "studio/core/gearcolecoTestCore.js")))
  throw new Error(`no Amy Studio at ${studio}: run setup.sh with AMY_STUDIO=<compiler dir>, or set AMY_STUDIO`);
const core = await import(path.join(studio, "studio/core/gearcolecoTestCore.js"));
export const IN = core.GEARCOLECO_TEST_INPUT;

function crc32(buf) {
  let c, crc = 0xffffffff;
  for (let n = 0; n < buf.length; n++) {
    c = (crc ^ buf[n]) & 0xff;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    crc = (crc >>> 8) ^ c;
  }
  return (crc ^ 0xffffffff) >>> 0;
}
function png(w, h, rgb) {
  const chunk = (type, data) => {
    const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
    const td = Buffer.concat([Buffer.from(type), data]);
    const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td));
    return Buffer.concat([len, td, crc]);
  };
  const raw = Buffer.alloc((w * 3 + 1) * h);
  for (let y = 0; y < h; y++) { raw[y * (w * 3 + 1)] = 0; rgb.copy(raw, y * (w * 3 + 1) + 1, y * w * 3, (y + 1) * w * 3); }
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk("IHDR", ihdr), chunk("IDAT", deflateSync(raw)), chunk("IEND", Buffer.alloc(0))]);
}

export async function openGame(romPath, asmPath, { bios = path.join(here, "bios2.rom"), seed = 4 } = {}) {
  if (!existsSync(bios)) throw new Error(`no ${bios}: run setup.sh with COLECO_BIOS=<real OS7 BIOS>, or pass { bios } (python3 test/mkbios.py writes a stand-in)`);
  const asm = asmPath ? readFileSync(asmPath, "utf8") : "";
  const c = await core.GearcolecoTestCore.create({ seed });
  c.loadBios(readFileSync(bios));
  c.loadRom(readFileSync(romPath), { region: core.GEARCOLECO_TEST_REGION.NTSC });
  const addrCache = new Map();   // one regex search per variable, not per read
  const addr = name => {
    if (addrCache.has(name)) return addrCache.get(name);
    const v = addrFind(name);
    addrCache.set(name, v);
    return v;
  };
  const addrFind = name => {
    const m = asm.match(new RegExp(`^AMY_UVAR_${name}\\s+EQU\\s+\\$([0-9A-Fa-f]{4})`, "m"));
    if (!m) throw new Error(`variable ${name} not found in ${asmPath}`);
    return parseInt(m[1], 16);
  };
  const frames = {};
  const g = {
    core: c,
    frame: 0,
    run(n = 1, mask = 0) { c.setControllerMask(0, mask); for (let i = 0; i < n; i++) { c.runFrame(); g.frame++; } c.setControllerMask(0, 0); },
    hold(mask, n) { g.run(n, mask); },
    press(mask = IN.FIRE_LEFT, down = 8, up = 8) { g.run(down, mask); g.run(up); },
    get: name => c.readRam(addr(name), 1)[0],
    get16: name => { const b = c.readRam(addr(name), 2); return b[0] + 256 * b[1]; },
    getArray: (name, n) => Array.from(c.readRam(addr(name), n)),
    rgb() {
      const fb = c.getFramebuffer(), w = fb.width || 256, h = fb.height || 192;
      const px = new Uint16Array(fb.pixels.buffer, fb.pixels.byteOffset, w * h);
      const out = Buffer.alloc(w * h * 3);
      for (let i = 0; i < w * h; i++) { const p = px[i]; out[i * 3] = (p >> 11) << 3; out[i * 3 + 1] = ((p >> 5) & 63) << 2; out[i * 3 + 2] = (p & 31) << 3; }
      return { w, h, out };
    },
    // frame budget: run n frames and count how often the game's own frame
    // counter (a variable the loop increments, like Tick) moved; a result
    // under n means the loop missed frames
    loopRate(counter, n = 120, mask = 0) {
      let moves = 0, last = g.get(counter);
      for (let i = 0; i < n; i++) { g.run(1, mask); const v = g.get(counter); moves += (v - last + 256) & 255; last = v; }
      return { frames: n, passes: moves };
    },
    shot(name) { const f = g.rgb(); frames[name] = f; writeFileSync(`${name}.png`, png(f.w, f.h, f.out)); return `${name}.png`; },
    sheet(names, out = "sheet", perRow = 3) {
      const fs_ = names.map(n => frames[n]).filter(Boolean); if (!fs_.length) return;
      const w = fs_[0].w, h = fs_[0].h, cols = Math.min(perRow, fs_.length), rows = Math.ceil(fs_.length / cols);
      const big = Buffer.alloc(w * cols * h * rows * 3);
      fs_.forEach((f, k) => { const ox = (k % cols) * w, oy = Math.floor(k / cols) * h;
        for (let y = 0; y < h; y++) f.out.copy(big, ((oy + y) * w * cols + ox) * 3, y * w * 3, (y + 1) * w * 3); });
      writeFileSync(`${out}.png`, png(w * cols, h * rows, big)); return `${out}.png`;
    },
  };
  return g;
}
