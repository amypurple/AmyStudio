# art.py - POULET CONTRE ZOMBIE, act I graphics (Amy & Claude 2026).
# Run: python3 art.py OUTDIR  -> OUTDIR/gfx.amy, OUTDIR/packin/*.bin (streams to pack
# with AMYZ), OUTDIR/preview-*.png.
#
# VRAM code map (graphics mode 2, the same in the three thirds unless noted):
#   32-107  the game's own font (font.py), 108-111 free
#   112-159 game tiles (baskets, gravestone, sprinkler, lanterns, HUD icons)
#   160-255 the pictures: backyard (game), sky with the logo (title, top third),
#           act menu; the stumble close-up uses 112-255 (game tiles reloaded after)
import os, sys, math
import numpy as np
from PIL import Image, ImageDraw
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, 'common', 'tools'))
import font, m2
from artlib import SpriteSet, CL as ACL, _spr16

OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'build')
os.makedirs(os.path.join(OUT, 'packin'), exist_ok=True)
C = m2.CL
k, n, M, b, r, y, Y, G, m, g, a, w, R, p, c = (C[x] for x in 'knMbryYGmgawRpc')


def canvas(fill=k):
    im = Image.new('P', (256, 192), fill)
    return im, ImageDraw.Draw(im)


def arr(im):
    return np.array(im, dtype=int)


rng = np.random.default_rng(20261031)

# ====================================================================== game tiles
# r5: one set per act (the same codes from GT_BASE in every act; the ground
# colour and some objects differ). The ninja footprint and landing puff are
# codes 203-204 of thirds 1-2 (FOOTP, loaded with the yard).
GT_BASE = 112
GT = {}            # name -> code
GTP = []           # (pat, col) of the set being built
GTSETS = {}        # act -> GTP
FOOTP = {}         # act -> (patterns, colours) of the footprint and the puff


def gtile(name, rows, fg=None):
    """8 rows of 8 colour letters (artlib letters)"""
    cell = np.array([[C[ch] for ch in row] for row in rows])
    pat, col = m2.cell_bytes(cell)
    if fg is not None:   # force the foreground colour (tiles whose colours change at run time)
        f = C[fg]
        pat, col = list(pat), list(col)
        for i in range(8):
            fgc, bgc = col[i] >> 4, col[i] & 15
            if fgc != f and bgc == f:
                pat[i] ^= 0xFF
                col[i] = (f << 4) | fgc
            elif fgc == f and bgc == f:
                pat[i] = 0xFF
        pat, col = tuple(pat), tuple(col)
    code = GT_BASE + len(GTP)
    if name in GT:
        assert GT[name] == code, (name, GT[name], code)
    GT[name] = code
    GTP.append((pat, col))
    return code


def gbig(name, rows, fg=None):
    h, wd = len(rows) // 8, len(rows[0]) // 8
    for ty in range(h):
        for tx in range(wd):
            gtile(f'{name}{ty}{tx}', [rows[ty * 8 + j][tx * 8:tx * 8 + 8] for j in range(8)], fg)


def on(rows, ground):
    return [row.replace('.', ground) for row in rows]


# pumpkin basket, empty (on the lawn, G): handle a, rim k, body y
BASKET = [
    "GGGGGaaaaaaGGGGG",
    "GGGGaGGGGGGaGGGG",
    "GGGaGGGGGGGGaGGG",
    "GGakkkkkkkkkkaGG",
    "GykkkkkkkkkkkkyG",
    "GyyykkkkkkkkyyyG",
    "yyyyyyyyyyyyyyyy",
    "yyyrrryyyyrrryyy",
    "yyyyyyyyyyyyyyyy",
    "yyyrryyyyyyrryyy",
    "yyyyyyyyyyyyyyyy",
    "yyyyyyyyyyyyyyyy",
    "Gyyyyyyyyyyyyyyy",
    "GyyyyyyyyyyyyyyG",
    "GGyyyyyyyyyyyyGG",
    "GGGkkkkkkkkkkGGG"]
# filled: the chicken's tail and comb stick out, the face glows (Y)
BASKETF = [
    "GGGGGaaRRaaGGGGG",
    "GGGGaGRRRRGaGGGG",
    "GGGaGGwwwwGGaGGG",
    "GGawwwwwwwwwwaGG",
    "GywwwwwwwwwwwwyG",
    "GyyywwwwwwwwyyyG",
    "yyyyyyyyyyyyyyyy",
    "yyyYYYyyyyYYYyyy",
    "yyyyYyyyyyyYyyyy",
    "yyyyyyyyyyyyyyyy",
    "yyyYYYYYYYYYYyyy",
    "yyyyYyYyyYyYyyyy",
    "Gyyyyyyyyyyyyyyy",
    "GyyyyyyyyyyyyyyG",
    "GGyyyyyyyyyyyyGG",
    "GGGkkkkkkkkkkGGG"]
GRAVE = [
    "GGGGGaaaaaaGGGGG",
    "GGGaaaaaaaaaaGGG",
    "GGaaaaaaaaaaaaGG",
    "kaaaaaakkaaaaaak",
    "kaaaaaakkaaaaaak",
    "kaaaakkkkkkaaaak",
    "kaaaakkkkkkaaaak",
    "kaaaaaakkaaaaaak",
    "kaaaaaakkaaaaaak",
    "kaaaaaakkaaaaaak",
    "kaaaaaaaaaaaaaak",
    "kaaaaaaaaaaaaaak",
    "kaaaaaaaaaaaaaak",
    "kaaaaaaaaaaaaaak",
    "GkkkkkkkkkkkkkkG",
    "GGGGGGGGGGGGGGGG"]
# jack-o'-lantern (2x2), its face tiles take the glow colour from the colour table
LANT = [
    "kkkkkkkGGkkkkkkk",
    "kkkkkkkGGkkkkkkk",
    "kkkkrrrrrrrrkkkk",
    "kkrrrrrrrrrrrrkk",
    "krrrrrrrrrrrrrrk",
    "rrrYYrrrrrrYYrrr",
    "rrYYYYrrrrYYYYrr",
    "rrrrrrrYYrrrrrrr",
    "rrrrrrrYYrrrrrrr",
    "rrYrYrYrrYrYrYrr",
    "rrYYYYYYYYYYYYrr",
    "rrrYrYrYYrYrYrrr",
    "krrrrrrrrrrrrrrk",
    "kkrrrrrrrrrrrrkk",
    "kkkkrrrrrrrrkkkk",
    "kkkkkkkkkkkkkkkk"]


def sprinkler(fr, ground):
    gi = C[ground]
    im = np.full((16, 16), gi)
    ang0 = fr * math.pi / 2
    for t in range(40):
        ang = ang0 + t * 0.15
        rad = 2 + t * 0.17
        x = int(round(8 + math.cos(ang) * rad))
        yy = int(round(8 + math.sin(ang) * rad * 0.7))
        if 0 <= x < 16 and 0 <= yy < 16 and t % 3 != 2:
            im[yy, x] = c
    im[7:10, 7:9] = a
    im[10, 6:10] = a
    lk = {gi: ground, a: 'a', c: 'c'}
    return [''.join(lk[v] for v in row) for row in im]


# act II: the snowman (2x2 on the snow; full-width rows where he has a face,
# two colours an 8-pixel row), his lost carrot, hat and eyes, the sled, ice
def snowman(nose=True, hat=True, eyes=True):
    rows = [
        "....kkkkkkkk....",
        "....kkkkkkkk....",
        "..kkkkkkkkkkkk..",
        ".wwwwwwwwwwwwww.",
        "wwwkkwwwwwwkkwww",
        "wwwwwwwrrrrrrwww",
        ".wwwwwwwwwwwwww.",
        "..wwwwwwwwwwww..",
        ".wwwwwwwwwwwwww.",
        "wwwwwwwkwwwwwwww",
        "wwwwwwwwwwwwwwww",
        "wwwwwwwkwwwwwwww",
        "wwwwwwwwwwwwwwww",
        ".wwwwwwwwwwwwww.",
        "..wwwwwwwwwwww..",
        "...kkkkkkkkkk..."]
    if not hat:
        rows[0] = rows[1] = rows[2] = "................"
    if not eyes:
        rows[4] = "wwwwwwwwwwwwwwww"
    if not nose:
        rows[5] = "wwwwwwwwwwwwwwww"
    return rows


SLED = [
    "................",
    "................",
    "................",
    "..rrrrrrrrrrrr..",
    "..r..r..r..r.r..",
    "..rrrrrrrrrrrr..",
    "..r..r..r..r.r..",
    "..rrrrrrrrrrrr..",
    "...k........k...",
    "...k........k...",
    ".kkkkkkkkkkkkkk.",
    "k...............",
    "................",
    "................",
    "................",
    "................"]
CARROT = ["........", "......r.", ".....rr.", "....rr..", "...rr...", "..rr....", ".r......", "........"]
HAT = ["........", "..kkkk..", "..kkkk..", "..kkkk..", "kkkkkkkk", "........", "........", "........"]
EYES = ["........", "........", "..k..k..", ".kk..kk.", "........", "........", "........", "........"]
ICE = ["cccccccc", "cwwccccc", "cccccccc", "ccccwwwc", "cccccccc", "ccwccccc", "cccccccc", "cccccwwc"]
# act III: the plastic pink flamingo (standing, knocked over, dancing in shades)
FLAMINGO = [
    "........ppp.....",
    ".......ppppp....",
    ".......pp.ppp...",
    "..........pp....",
    "..........pp....",
    ".........pp.....",
    "...pppppppp.....",
    ".ppppppppppp....",
    "pppppppppppp....",
    ".pppppppppp.....",
    "...pppppp.......",
    ".......k........",
    ".......k........",
    ".......k........",
    "......kkk.......",
    "................"]
FLAMINGO_DOWN = [
    "................",
    "................",
    "................",
    "................",
    "................",
    "................",
    "................",
    "....pppppp......",
    "..pppppppppp....",
    ".pppppppppppp...",
    ".ppppppppppppp..",
    "..pppppppppp.ppp",
    "....pppppp...pp.",
    "kkkkkk......pp..",
    "................",
    "................"]


def flamingo_shades(step):
    """dancing on one leg in sunglasses (a black bar across the head's row)"""
    rows = list(FLAMINGO)
    rows[1] = ".......pppppkkkk" if step else "......pppppkkkk."
    rows[0] = "........ppp....." if step else ".......ppp......"
    rows[2] = ".......pp.ppp..." if step else "......pp.ppp...."
    if step:
        rows[11:15] = [".......k........", "........k.......", ".........k......", ".........kkk...."]
    else:
        rows[11:15] = [".......k........", "......k.........", ".....k..........", "...kkk.........."]
    return rows


def build_gt(act):
    """the game tiles of an act (codes GT_BASE...): GT names are the same in all acts"""
    global GTP
    GTP = []
    gnd = {1: 'G', 2: 'a', 3: 'G'}[act]
    # ninja: a faint footprint, the landing puff (on the ground colour), kept
    # apart (codes 203-204 of the lawn's thirds)
    dim = {1: 'm', 2: 'w', 3: 'm'}[act]
    fp = [m2.cell_bytes(np.array([[C[ch] for ch in row] for row in rws])) for rws in (
        on([r.replace('x', dim) for r in ["........", ".x......", "xxx.....", ".x...x..", "....xxx.", ".....x..", "........", "........"]], gnd),
        on([r.replace('x', 'w' if act != 2 else 'k') for r in ["........", "..x..x..", ".x.xx.x.", "x......x", ".x....x.", "..xxxx..", "........", "........"]], gnd))]
    FOOTP[act] = (bytes(fp[0][0] + fp[1][0]), bytes(fp[0][1] + fp[1][1]))
    bsk, bskf = BASKET, BASKETF
    if act == 2:
        bsk = [r.replace('a', 'h') for r in bsk]
        bskf = [r.replace('a', 'h') for r in bskf]
        bsk = [r.replace('G', 'a').replace('h', 'k') for r in bsk]
        bskf = [r.replace('G', 'a').replace('h', 'k') for r in bskf]
    if act == 3:
        # a straw basket: light yellow weave, dark yellow bands
        sw = lambda r: r.replace('y', 'q').replace('r', 'y').replace('q', 'Y').replace('YYY', 'YyY')
        bsk = [sw(r) for r in bsk]
        bskf = [r.replace('y', 'q').replace('q', 'Y') for r in bskf]
    gbig('bsk', bsk)
    gbig('bskf', bskf)
    if act == 1:
        gbig('grv', GRAVE)
        for fr in range(4):
            gbig(f'spr{fr}', sprinkler(fr, 'G'))
        gbig('lant', LANT, fg='Y')
    elif act == 2:
        gbig('grv', on(snowman(), 'a'))
        gbig('spr0', on(snowman(nose=False), 'a'))
        gbig('spr1', on(snowman(nose=False, hat=False), 'a'))
        gbig('spr2', on(snowman(nose=False, hat=False, eyes=False), 'a'))
        gtile('spr300', on(CARROT, 'a'))
        gtile('spr301', on(HAT, 'a'))
        gtile('spr310', on(EYES, 'a'))
        gtile('spr311', ICE)
        gbig('lant', on(SLED, 'a'))
    else:
        gbig('grv', on(FLAMINGO, 'G'))
        for fr in range(2):
            gbig(f'spr{fr}', sprinkler(fr * 2, 'G'))
        gbig('spr2', on(FLAMINGO_DOWN, 'G'))
        gbig('spr3', on(flamingo_shades(0), 'G'))
        gbig('lant', on(flamingo_shades(1), 'G'))
    # HUD icons (on black), the same in every act
    gtile('zhead', ["k.wwww.k".replace('.', 'k'), "kwggggwk", "wgkggkgw", "wggggggw", "kgkkkkgk", "kgwkwkgk", "kkggggkk", "kkkkkkkk"])
    gtile('pump', ["kkkGkkkk", "kyyGyykk", "yyyyyyyk", "yYyyYyyk", "yyyyyyyk", "yYYYYyyk", "kyyyyykk", "kkkkkkkk"])
    for nm, colr in (('bar1', 'g'), ('bar2', 'Y'), ('bar3', 'R'), ('bar0', 'n')):
        gtile(nm, ["kkkkkkkk", colr * 7 + 'k', colr * 7 + 'k', colr * 7 + 'k', colr * 7 + 'k', colr * 7 + 'k', colr * 7 + 'k', "kkkkkkkk"])
    gtile('swirl', ["kkkkkkkk", "kkaaaakk", "kakkkkak", "kakaakak", "kakkaaak", "kaakkkkk", "kkaaaaak", "kkkkkkkk"])
    gtile('panelt', ["kkkkkkkk", "yyyyyyyy", "kkkkkkkk", "MMMMMMMM", "kkkkkkkk", "kkkkkkkk", "kkkkkkkk", "kkkkkkkk"])
    gtile('panelb', ["kkkkkkkk", "kkkkkkkk", "kkkkkkkk", "kkkkkkkk", "MMMMMMMM", "kkkkkkkk", "yyyyyyyy", "kkkkkkkk"])
    gtile('lock', ["kkaaakkk", "kakkkakk", "kakkkakk", "yyyyyyyk", "yyykyyyk", "yyykyyyk", "yyyyyyyk", "kkkkkkkk"])
    gtile('star', ["kkkkkkkk", "kkkYkkkk", "kkkYkkkk", "kYYYYYkk", "kkYYYkkk", "kkYkYkkk", "kYkkkYkk", "kkkkkkkk"])
    gtile('stard', ["kkkkkkkk", "kkknkkkk", "kkknkkkk", "knnnnnkk", "kknnnkkk", "kknknkkk", "knkkknkk", "kkkkkkkk"])
    assert GT_BASE + len(GTP) <= 157, len(GTP)
    GTSETS[act] = GTP
    return GTP


for _act in (1, 2, 3):
    build_gt(_act)
GTP = GTSETS[1]

# ====================================================================== the backyard (game)
def backyard(title=False):
    im, d = canvas(k)
    # sky: deep blue, purple towards the horizon (whole-line stripes: few tiles)
    for yy in range(16, 72):
        col = n
        if yy >= 48 and (yy - 48) % max(1, 6 - (yy - 48) // 4) == 0:
            col = M
        if yy >= 66:
            col = M if yy % 2 == 0 else n
        d.line([(0, yy), (255, yy)], fill=col)
    # stars
    for (sx, sy) in [(44, 20), (70, 30), (98, 18), (120, 34), (150, 22), (176, 30), (90, 44), (140, 46), (60, 50), (196, 48)]:
        d.point((sx, sy), fill=w)
    # moon
    d.ellipse([196, 20, 220, 44], fill=Y)
    d.ellipse([202, 26, 206, 30], fill=y)
    d.ellipse([210, 34, 214, 37], fill=y)
    # the big bare tree (left), a black silhouette
    d.polygon([(14, 104), (36, 104), (31, 70), (29, 40), (21, 40), (19, 70)], fill=k)
    def branch(x0, y0, ang, ln, wd, depth):
        x1 = x0 + math.cos(ang) * ln
        y1 = y0 - math.sin(ang) * ln
        d.line([(x0, y0), (x1, y1)], fill=k, width=max(1, wd))
        if depth:
            branch(x1, y1, ang + 0.45, ln * 0.68, wd - 1, depth - 1)
            branch(x1, y1, ang - 0.4, ln * 0.62, wd - 1, depth - 1)
    branch(25, 44, math.pi / 2, 14, 4, 4)
    branch(23, 60, math.pi * 0.78, 18, 3, 3)
    branch(28, 56, math.pi * 0.22, 20, 3, 3)
    # the cedar hedge across the back: pointed tops
    pts = [(0, 96)]
    xx = 0
    while xx <= 256:
        top = 52 + int(rng.integers(0, 7))
        pts += [(xx, 64), (xx + 7, top), (xx + 14, 64)]
        xx += 14
    pts += [(256, 96)]
    d.polygon(pts, fill=G)
    hed = np.array(im)
    for yy in range(48, 96):
        for xx in range(256):
            if hed[yy, xx] == G and (xx + yy) % 2 == 0 and yy >= 60:
                hed[yy, xx] = k
            elif hed[yy, xx] == G and yy >= 80 and (xx + yy) % 2 == 1 and xx % 4 == 1:
                hed[yy, xx] = k
    im.paste(Image.fromarray(hed.astype(np.uint8), 'P'))
    d = ImageDraw.Draw(im)
    # the white birch (right)
    d.rectangle([228, 30, 235, 104], fill=w)
    for yy in range(34, 104, 7):
        off = int(rng.integers(0, 4))
        d.line([(228 + off, yy), (231 + off, yy)], fill=k)
    d.line([(232, 40), (246, 22)], fill=w, width=2)
    d.line([(230, 52), (214, 36)], fill=w, width=1)
    d.line([(240, 31), (250, 26)], fill=w)
    # the fence (in front of the hedge): pointed pickets every 8 pixels
    for xx in range(0, 256, 8):
        d.rectangle([xx + 1, 76, xx + 5, 95], fill=a)
        d.polygon([(xx + 1, 76), (xx + 3, 73), (xx + 5, 76)], fill=a)
    d.rectangle([0, 80, 255, 81], fill=a)
    d.rectangle([0, 90, 255, 91], fill=a)
    # the lawn: one plain dark green (r4: the zombie's outline is drawn into
    # these cells as a software sprite layer, black on green, no clash)
    d.rectangle([0, 96, 255, 175], fill=G)
    # tree trunk and birch over the lawn top
    d.rectangle([0, 176, 255, 191], fill=k)
    d.rectangle([0, 0, 255, 15], fill=k)
    return arr(im)


BG = backyard()


def winter_yard():
    """act II: a snowy night. Only the ground is pale (light grey, colour 14);
    the sky, the pines and the fence stay dark (no big bright band on a CRT)"""
    im, d = canvas(k)
    for yy in range(16, 72):
        col = k
        if yy >= 40 and (yy - 40) % max(1, 6 - (yy - 40) // 6) == 0:
            col = n
        if yy >= 64:
            col = n
        d.line([(0, yy), (255, yy)], fill=col)
    rr = np.random.default_rng(1203)
    for _ in range(26):                                  # falling snow, a few flakes
        d.point((int(rr.integers(4, 252)), int(rr.integers(18, 60))), fill=w)
    d.ellipse([28, 22, 42, 36], fill=a)                   # a pale moon behind clouds
    d.rectangle([20, 30, 52, 32], fill=n)
    # dark pines, a little snow on their tips only
    for px0, top in ((8, 34), (40, 46), (70, 38), (176, 42), (206, 32), (240, 44)):
        pts = []
        for lvl in range(4):
            yb = top + 10 + lvl * 8
            pts += [(px0 + 8, top + lvl * 8), (px0 + 8 + 5 + lvl * 2, yb)]
        d.polygon([(px0 + 8, top)] + [(px0 + 16 + l2 * 2, top + 10 + l2 * 8) for l2 in range(4)] +
                  [(px0 - l2 * 2, top + 10 + l2 * 8) for l2 in range(3, -1, -1)], fill=G)
        d.point((px0 + 8, top), fill=w)
        d.point((px0 + 8, top + 1), fill=w)
    # the fence: dark red planks (in front of the pines)
    for xx in range(0, 256, 8):
        d.rectangle([xx + 1, 76, xx + 5, 95], fill=r)
        d.polygon([(xx + 1, 76), (xx + 3, 73), (xx + 5, 76)], fill=r)
    d.rectangle([0, 80, 255, 81], fill=r)
    d.rectangle([0, 90, 255, 91], fill=r)
    d.rectangle([0, 96, 255, 175], fill=a)               # the snow plain
    d.rectangle([0, 176, 255, 191], fill=k)
    d.rectangle([0, 0, 255, 15], fill=k)
    return arr(im)


def summer_yard():
    """act III: a summer evening. Sunset bands, the sun going down behind a
    flowering hedge, a yellow fence, the plain lawn"""
    im, d = canvas(k)
    for yy in range(16, 72):
        col = n
        if yy >= 36 and (yy - 36) % max(1, 6 - (yy - 36) // 5) == 0:
            col = M
        if yy >= 56:
            col = M if yy % 2 == 0 else r
        if yy >= 66:
            col = r
        d.line([(0, yy), (255, yy)], fill=col)
    d.ellipse([106, 42, 150, 86], fill=y)                 # the sun, half behind the hedge
    pts = [(0, 96)]
    xx = 0
    while xx <= 256:
        top = 58 + int(rng.integers(0, 5))
        pts += [(xx, 66), (xx + 8, top), (xx + 16, 66)]
        xx += 16
    pts += [(256, 96)]
    d.polygon(pts, fill=G)
    rr = np.random.default_rng(77)
    for _ in range(40):                                   # flowers in the hedge
        fx, fy = int(rr.integers(2, 254)), int(rr.integers(64, 72))
        d.point((fx, fy), fill=M if fx % 3 else Y)
    for xx in range(0, 256, 8):
        d.rectangle([xx + 1, 76, xx + 5, 95], fill=y)
        d.polygon([(xx + 1, 76), (xx + 3, 73), (xx + 5, 76)], fill=y)
    d.rectangle([0, 80, 255, 81], fill=y)
    d.rectangle([0, 90, 255, 91], fill=y)
    d.rectangle([0, 96, 255, 175], fill=G)
    d.rectangle([0, 176, 255, 191], fill=k)
    d.rectangle([0, 0, 255, 15], fill=k)
    return arr(im)


BGW = winter_yard()
BGS = summer_yard()
LANT_POS = [(5, 11), (14, 11), (23, 11)]          # 2x2 lantern tiles at these cells (on the fence line)

# ====================================================================== title logo
LOGOC = font.G


def big_text(text, scale, wob=0, seed=1):
    """the font scaled up, with a hand-drawn wobble (each letter moves a little)"""
    rr = np.random.default_rng(seed)
    cols = []
    for ch in text:
        gph = LOGOC[ch]
        g = np.array([[1 if c2 == '#' else 0 for c2 in row] for row in gph])
        g = np.kron(g, np.ones((scale, scale), int))
        dy = int(rr.integers(-wob, wob + 1)) if wob else 0
        pad = np.zeros((g.shape[0] + 2 * wob, g.shape[1] + scale), int)
        pad[wob + dy:wob + dy + g.shape[0], 0:g.shape[1]] = g
        cols.append(pad)
    return np.concatenate(cols, axis=1)


def stamp(img, mask, x0, y0, colour_by_row):
    h, wd = mask.shape
    for yy in range(h):
        for xx in range(wd):
            if mask[yy, xx] and 0 <= y0 + yy < 192 and 0 <= x0 + xx < 256:
                img[y0 + yy, x0 + xx] = colour_by_row(yy)


# ====================================================================== sprites
sp = SpriteSet('Sp')
# --- the zombie: drawn by zombie.py on an animated skeleton (36 frames of 16x32,
# each half three layers: dark outline + two colours, in its own 16-column
# window); the game copies the current frame (6 patterns) into one of two
# buffers (slots 0-5 and 6-11), mirrored for the left; ROM holds right-facing only
import zombie
for i in range(8):
    sp.one(f'zbuf{i}', ["................"] * 16)
sp.one('ztop', ["................"] * 16)      # the halves' outlines when over the fence or an object (r4)
sp.one('zbot', ["................"] * 16)
sp.one('ztop1', ["................"] * 16)
sp.one('zbot1', ["................"] * 16)
ZFR, ZSTART, ZCOUNT = zombie.build()
zbytes, zcols, zdx, zdk, zdkoff, zdknb = [], [], [], [], [], []
for fr in ZFR:
    for dx, (c1, c2), win, _lost in fr.halves[:2]:
        for ch in (c1, c2):
            zbytes += _spr16([''.join('#' if c == ch else '.' for c in row) for row in win])
        zcols += [zombie.COLV[c1], zombie.COLV[c2]]
        zdx.append((dx + 128) & 255)
    dark, _cut, c0 = fr.halves[2]
    # stored as rows top..bottom of nb bytes, from the first column with black
    orv = 0
    for row in dark:
        orv |= row
    lb = min(i for i in range(32) if orv >> (31 - i) & 1)
    rb = max(i for i in range(32) if orv >> (31 - i) & 1)
    nb = (rb - lb + 8) // 8
    rws = [i for i in range(32) if dark[i]]
    top, bot = rws[0], rws[-1]
    enc = [top, bot - top + 1, nb]
    for r in range(top, bot + 1):
        v = (dark[r] << lb) & 0xFFFFFFFF          # first black column at bit 31
        enc += [(v >> (24 - 8 * k)) & 255 for k in range(nb)]
    zdk.append(enc)
    zdkoff.append(c0 + lb)
    zdknb.append(nb)
zombie.sheets(ZFR, OUT)
def mirror(rows):
    return [row.ljust(16, '.')[::-1] for row in rows]


# --- the chicken (16x16): white body, red comb/beak/striped legs, blue pupils
CH_R = [
    "................",
    ".........RR.....",
    "........RRRR....",
    "........wwww....",
    ".......wwBBww...",
    ".......wwBBwRRR.",
    "........wwwwRR..",
    ".ww....wwwww....",
    "wwww..wwwwww....",
    "wwwwwwwwwwww....",
    ".wwwwwwwwwww....",
    "..wwwwwwwwww....",
    "....wwwwwww.....",
    ".....R...R......",
    ".....R...R......",
    "....RR..RR......"]


def ch_legs(rows, step):
    out = rows[:13]
    if step == 0:
        out += [".....R...R......", "................", "....RR..RR......"]
    else:
        out += ["......R.R.......", "................", ".....RRRR.......".replace('RRRR', 'RR.R')]
    return out


def ch_flap(rows):
    out = list(rows)
    out[6] = "ww......wwwwRR.."
    out[7] = "www....wwwww...."
    out[8] = ".www..wwwwww...."
    return out


# r5.3: the white layer has holes under the pupils (blue layer): the three
# layers never overlap, so any sprite order shows the chicken right (flicker)
def split_chicken(rows):
    white = [row.replace('B', '.') for row in rows]
    return white


def ch_bob(rows):
    """the body one pixel lower (the legs stay): the wind-up toy's bounce"""
    return ["................"] + rows[:13] + rows[14:16]


for side in ('r', 'l'):
    for st in range(4):
        rows = ch_legs(CH_R, st >> 1)
        if st & 1:
            rows = ch_bob(rows)
        if side == 'l':
            rows = mirror(rows)
        whites = split_chicken(rows)
        sp.one(f'cw{side}{st}', [''.join('#' if ch == 'w' else '.' for ch in row) for row in whites])
        sp.one(f'cr{side}{st}', [''.join('#' if ch == 'R' else '.' for ch in row) for row in rows])
    rows = ch_flap(ch_legs(CH_R, 0))
    if side == 'l':
        rows = mirror(rows)
    sp.one(f'cw{side}f', [''.join('#' if ch == 'w' else '.' for ch in row) for row in split_chicken(rows)])
    sp.one(f'cr{side}f', [''.join('#' if ch == 'R' else '.' for ch in row) for row in rows])
    for bb in range(2):
        er = CH_R if not bb else ch_bob(CH_R)
        sp.one(f'ce{side}{bb}', [''.join('#' if ch == 'B' else '.' for ch in row) for row in (er if side == 'r' else mirror(er))])
sp.one('shadow', ["................"] * 12 + ["....########....", "..############..", "....########....", "................"])
sp.one('stars', [".#......#.......", "###....###......", ".#......#....#..", ".............###", "......#.......#.", ".....###........",
                 "......#.........", "................"])
sp.one('cursor', ["................", "................", "................", "................",
                  "##..............", "####............", "######..........", "####............", "##.............."])
sp.one('drop', ["......##........", ".....####.......", ".....####.......", "......##........"])
SPR_COL = dict(white=15, red=8, blue=5, shadow=1, stars=11, cursor=11, drop=3, tan=10, face=3)

# ====================================================================== the stumble close-up
def face_frame(s, cx, cy, gameover=False):
    """the zombie's face coming at the screen: s = face height in pixels"""
    im = Image.new('P', (256, 192), n)
    d = ImageDraw.Draw(im)
    fw = s * 0.8
    # long stringy white hair behind and around the face
    d.ellipse([cx - fw * 0.66, cy - s * 0.66, cx + fw * 0.66, cy - s * 0.05], fill=w)
    for i in range(7):
        hx = cx + (i - 3) / 3 * fw * 0.6
        ln = s * (0.62 + 0.08 * ((i * 5) % 3))
        d.rectangle([hx - s * 0.045, cy - s * 0.3, hx + s * 0.045, cy + ln * 0.55], fill=w)
    # the grey-green mask, darker on one side
    d.ellipse([cx - fw / 2, cy - s / 2, cx + fw / 2, cy + s / 2], fill=g)
    d.chord([cx - fw / 2, cy - s / 2, cx + fw / 2, cy + s / 2], 110, 250, fill=m)
    # fringe
    for i in range(5):
        hx = cx + (i - 2) / 2 * fw * 0.36
        d.polygon([(hx - s * 0.07, cy - s * 0.5), (hx + s * 0.07, cy - s * 0.5), (hx + s * 0.02, cy - s * 0.22)], fill=w)
    # eye sockets, pupils looking at each other (cross-eyed)
    for ex, px in ((-0.2, 0.05), (0.2, -0.05)):
        d.ellipse([cx + ex * fw - s * 0.12, cy - s * 0.16, cx + ex * fw + s * 0.12, cy + s * 0.05], fill=k)
        d.ellipse([cx + ex * fw + px * s - s * 0.045, cy - s * 0.09, cx + ex * fw + px * s + s * 0.045, cy], fill=w)
    d.ellipse([cx - s * 0.07, cy + s * 0.07, cx - s * 0.02, cy + s * 0.12], fill=k)
    d.ellipse([cx + s * 0.02, cy + s * 0.07, cx + s * 0.07, cy + s * 0.12], fill=k)
    # wide mouth, crooked teeth (one missing)
    d.ellipse([cx - fw * 0.34, cy + s * 0.16, cx + fw * 0.34, cy + s * 0.4], fill=k)
    for tx, t0, t1 in ((-0.25, 0.19, 0.28), (-0.12, 0.17, 0.31), (0.09, 0.18, 0.27), (0.2, 0.2, 0.3)):
        d.rectangle([cx + tx * fw, cy + t0 * s, cx + (tx + 0.09) * fw, cy + t1 * s], fill=w)
    return arr(im)


def oups_card(big=False):
    im = Image.new('P', (256, 192), k)
    d = ImageDraw.Draw(im)
    # green goo splash: a blob, splats around, drips down
    cx, cy = 128, 92
    rad = 74 if big else 64
    pts = []
    for i in range(36):
        ang = i / 36 * 2 * math.pi
        rr = rad * (0.82 + 0.25 * math.sin(ang * 5 + 1) + 0.12 * math.sin(ang * 11))
        pts.append((cx + math.cos(ang) * rr * 1.75, cy + math.sin(ang) * rr * 0.85))
    d.rectangle([44, cy - 22, 212, cy + 22], fill=g)
    d.polygon(pts, fill=g)
    for i in range(9):
        ang = i / 9 * 2 * math.pi + 0.3
        dx, dy = cx + math.cos(ang) * rad * 1.9, cy + math.sin(ang) * rad * 1.15
        d.ellipse([dx - 6, dy - 5, dx + 6, dy + 5], fill=g)
    for dx in (-70, -38, 4, 44, 80):
        top = cy + rad * 0.6
        ln = 20 + (dx * 7 % 23)
        d.rectangle([cx + dx - 3, top, cx + dx + 3, top + ln], fill=g)
        d.ellipse([cx + dx - 5, top + ln - 3, cx + dx + 5, top + ln + 7], fill=g)
    # dark green speckles inside
    for i in range(60):
        px = cx + rng.integers(-80, 80); py = cy + rng.integers(-40, 40)
        if im.getpixel((int(px), int(py))) == g and abs(int(py) - cy) > 22:
            d.rectangle([int(px) // 4 * 4, int(py) // 4 * 4, int(px) // 4 * 4 + 3, int(py) // 4 * 4 + 3], fill=m)
    img = arr(im)
    sc = 4
    t = big_text("OUPS !", sc, wob=0)
    x0 = ((256 - t.shape[1]) // 2) // 4 * 4
    y0 = (cy - t.shape[0] // 2) // 4 * 4
    stamp(img, t, x0, y0, lambda yy: w)
    return img


def tri():
    return [list(range(0, 8)), list(range(8, 16)), list(range(16, 24))]


# ====================================================================== outputs
def amy_bytes(name, data):
    lines = [f"data {name} bytes"]
    for i in range(0, len(data), 16):
        lines.append("  " + ",".join(f"${v:02X}" for v in data[i:i + 16]))
    lines.append("end data")
    return "\n".join(lines)


out = []
packs = {}
# font
FP = font.font_patterns()
out.append("' font: codes 32-111 (generated by art.py from font.py)")
packs['font'] = bytes(v for code in range(32, 112) for v in FP[code])
# game tiles
out.append("' game tiles from code 112")
for nm, cd in GT.items():
    nmc = ''.join(part.capitalize() for part in nm.replace('_', ' ').split())
    out.append(f"const Gt{nmc[0].upper() + nmc[1:]} = {cd}")
out.append(f"const GtBytes = {8 * len(GTP)}\nconst GtFirst = {GT_BASE}")
for _act, _pre in ((1, ''), (2, 'w'), (3, 's')):
    packs[_pre + 'gtpat'] = bytes(v for pc in GTSETS[_act] for v in pc[0])
    packs[_pre + 'gtcol'] = bytes(v for pc in GTSETS[_act] for v in pc[1])
    packs[_pre + 'fppat'] = FOOTP[_act][0]
    packs[_pre + 'fpcol'] = FOOTP[_act][1]
out.append("const GtBlank = 32\nconst GtFoot = 203\nconst GtPuff = 204")

# backyard: thirds 0-2 rows; rows 0-1 and 22-23 are blank (code 32 = space in the font)
# r4 code map in thirds 1-2: 157-204 backyard, 205 the plain lawn, 206-255 the
# zombie's outline tiles (two buffers of 5x5); third 0 (sky) may use 157-255
LAWN_PC = ((0,) * 8, ((G << 4) | G,) * 8)
LAWN_CODE = 205
thirds, names = m2.encode_frames([BG], tri(), 157, [99, 46, 46], fixed={LAWN_PC: LAWN_CODE})
BGN = names[0]
for ty in (0, 1, 22, 23):
    BGN[ty, :] = 32
# lanterns
for (lx, ly) in LANT_POS:
    for dy in range(2):
        for dx in range(2):
            BGN[ly + dy, lx + dx] = GT[f'lant{dy}{dx}']
for t, th in enumerate(thirds):
    packs[f'bgpat{t}'] = bytes(v for pc in th.cells for v in pc[0])
    packs[f'bgcol{t}'] = bytes(v for pc in th.cells for v in pc[1])
    print(f"backyard third {t}: {len(th.cells)} tiles")
packs['bgname'] = bytes(int(v) for v in BGN.reshape(-1))
# acts II and III: their own yard (the same code ranges; the ground tile is
# code 205 in every act, black-on-ground outline tiles 206-255)
for _img, _pre, _g in ((BGW, 'w', a), (BGS, 's', G)):
    _lpc = ((0,) * 8, ((_g << 4) | _g,) * 8)
    _th, _nm = m2.encode_frames([_img], tri(), 157, [99, 46, 46], fixed={_lpc: LAWN_CODE})
    _n = _nm[0]
    for ty in (0, 1, 22, 23):
        _n[ty, :] = 32
    for t, th in enumerate(_th):
        packs[f'{_pre}bgpat{t}'] = bytes(v for pc in th.cells for v in pc[0])
        packs[f'{_pre}bgcol{t}'] = bytes(v for pc in th.cells for v in pc[1])
        print(f"yard {_pre} third {t}: {len(th.cells)} tiles")
    packs[f'{_pre}bgname'] = bytes(int(v) for v in _n.reshape(-1))
    YARDS = globals().setdefault('YARDS', {})
    YARDS[_pre] = (_th, _n)
out.append(f"const LawnTile = {LAWN_CODE}")
out.append(f"const LawnCol = ${(G << 4) | G:02X}")
out.append(f"const LawnColW = ${(a << 4) | a:02X}")

# title: night sky with the logo (rows 2-10), the backyard moved down below it;
# its own tiles from code 112 in thirds 0 and 1 (the game tiles are reloaded for play)
timg = np.full((192, 256), k)
timg[16:88, :] = n
for (sx, sy) in [(20, 22), (52, 40), (88, 18), (130, 48), (170, 20), (236, 44), (12, 60), (244, 70), (36, 80), (226, 84)]:
    timg[sy, sx] = w
mim = Image.fromarray(timg.astype(np.uint8), 'P')
dd = ImageDraw.Draw(mim)
dd.ellipse([212, 18, 236, 42], fill=Y)
dd.ellipse([218, 24, 222, 28], fill=y)
timg = np.array(mim, dtype=int)
timg[88:176, :] = BG[56:144, :]
timg[176:, :] = k
# lanterns into the picture (the game draws them as tiles)
lt = np.array([[C[ch] for ch in row] for row in LANT])
for (lx, ly) in LANT_POS:
    yy0 = (ly + 4) * 8
    timg[yy0:yy0 + 16, lx * 8:lx * 8 + 16] = lt
# the logo: ZOMBIE (big, green, dripping) / BOTTE (pink) / POULET (white and yellow)
t1 = big_text("ZOMBIE", 4, wob=1, seed=7)
zx1 = (256 - t1.shape[1]) // 2
stamp(timg, t1, zx1, 17, lambda yy: g if yy < 14 else m)
t2 = big_text("BOTTE", 2, wob=1, seed=5)
bx2 = (256 - t2.shape[1]) // 2
stamp(timg, t2, bx2, 48, lambda yy: p)
for xx in range(zx1, zx1 + t1.shape[1]):           # drips from the bottom of ZOMBIE, beside BOTTE
    if bx2 - 6 <= xx <= bx2 + t2.shape[1] + 4:
        continue
    if (xx * 7) % 23 == 0:
        bottom = max([yy for yy in range(t1.shape[0]) if t1[yy, xx - zx1]] or [0])
        if bottom > 20:
            for yy in range(17 + bottom + 1, 17 + bottom + 3 + (xx % 5)):
                timg[yy, xx:xx + 2] = m
t3 = big_text("POULET", 3, wob=1, seed=3)
stamp(timg, t3, (256 - t3.shape[1]) // 2, 65, lambda yy: w if yy < 11 else Y)
tthirds, tnames = m2.encode_frames([timg], tri(), 112, [144, 93, 93], fixed={LAWN_PC: LAWN_CODE})
TN = tnames[0]
TN[0:2, :] = 32
TN[22:24, :] = 32
for t, th in enumerate(tthirds):
    packs[f'tipat{t}'] = bytes(v for pc in th.cells for v in pc[0])
    packs[f'ticol{t}'] = bytes(v for pc in th.cells for v in pc[1])
    print(f"title third {t}: {len(th.cells)} tiles")
packs['tiname'] = bytes(int(v) for v in TN.reshape(-1))

# stumble close-up: 5 frames coming closer, then the OUPS card; game over: 6 frames + big card
FR = [face_frame(48, 120, 104), face_frame(84, 136, 100), face_frame(130, 122, 104), face_frame(200, 132, 118)]
CARD = oups_card(False)
GFR = [face_frame(300, 128, 150)]
CARDG = oups_card(True)
allf = FR + [CARD] + GFR + [CARDG]
# big tiles: each cell is one of 10 shapes in two of 6 colours (141 tiles, codes 112-252,
# the same in the three thirds); every frame is only a name table
GCOLS = [n, k, g, m, w, p]
SHAPES = []
def mask(fn):
    return np.array([[1 if fn(xx, yy) else 0 for xx in range(8)] for yy in range(8)])
SHAPES.append(mask(lambda xx, yy: False))                 # solid (bg)
SHAPES.append(mask(lambda xx, yy: yy < 4))                # top half
SHAPES.append(mask(lambda xx, yy: xx < 4))                # left half
SHAPES.append(mask(lambda xx, yy: xx < 4 and yy < 4))
SHAPES.append(mask(lambda xx, yy: xx >= 4 and yy < 4))
SHAPES.append(mask(lambda xx, yy: xx < 4 and yy >= 4))
SHAPES.append(mask(lambda xx, yy: xx >= 4 and yy >= 4))
SHAPES.append(mask(lambda xx, yy: (xx < 4) == (yy < 4)))  # chequer
SHAPES.append(mask(lambda xx, yy: xx <= yy))              # lower-left triangle
SHAPES.append(mask(lambda xx, yy: xx + yy >= 7))          # lower-right triangle
CAND = []
for ci, cc in enumerate(GCOLS):
    CAND.append((0, cc, cc))
for i in range(len(GCOLS)):
    for j in range(len(GCOLS)):
        if i != j:
            for si in range(1, len(SHAPES)):
                CAND.append((si, GCOLS[i], GCOLS[j]))
def cand_img(lst):
    return np.array([np.where(SHAPES[si] == 1, fg, bgc) for si, fg, bgc in lst])
def best_names(img, lst, rgbs):
    names = np.zeros((24, 32), int)
    rgb = m2.RGB[img]
    for ty in range(24):
        for tx in range(32):
            cell = rgb[ty * 8:ty * 8 + 8, tx * 8:tx * 8 + 8].reshape(-1)
            names[ty, tx] = int(((rgbs - cell[None, :]) ** 2).sum(axis=1).argmin())
    return names
crgb = m2.RGB[cand_img(CAND)].reshape(len(CAND), -1)
first = [best_names(f, CAND, crgb) for f in allf]
use = {}
for nm in first:
    for v in nm.reshape(-1):
        use[int(v)] = use.get(int(v), 0) + 1
keep = sorted(use, key=lambda v: -use[v])[:144]
BT = [CAND[v] for v in keep]
print(f"close-up big tiles: {len(use)} used, kept {len(BT)}")
BTimg = cand_img(BT)
BTrgb = m2.RGB[BTimg].reshape(len(BT), -1)
gnames = [best_names(f, BT, BTrgb) + 112 for f in allf]
bt_cells = [m2.cell_bytes(t) for t in BTimg]
packs['gagpat'] = bytes(v for pc in bt_cells for v in pc[0])
packs['gagcol'] = bytes(v for pc in bt_cells for v in pc[1])
for i, nm in enumerate(gnames):
    packs[f'gagname{i}'] = bytes(int(v) for v in nm.reshape(-1))
out.append(f"const GagFrames = {len(FR)}\nconst GagTiles = {len(BT)}")
gthirds = None

# act menu: a dark purple screen with three panels (font + game tiles only: no picture)
# sprites
ZSKIP = 12 * 32                                  # zbuf0-7, ztop/zbot (two pairs): not stored, filled with 0
assert sp.data[:ZSKIP] == [0] * ZSKIP
sp.data = sp.data[ZSKIP:]
import re as _re
out.append(_re.sub(r"data SpPat bytes\n.*?end data\n?", "", sp.amy(), flags=_re.S))
packs['sppat'] = bytes(sp.data)
out.append(f"const SpSkip = {ZSKIP}")
for an in zombie.ORDER:
    out.append(f"const Zf{an.capitalize()} = {ZSTART[an]}")
    out.append(f"const Zn{an.capitalize()} = {ZCOUNT[an]}")
out.append(amy_bytes("ZFCol", zcols))
out.append(amy_bytes("ZFDx", zdx))
out.append(amy_bytes("ZDkOff", zdkoff))
out.append(amy_bytes("ZDkNb", zdknb))
def zrle(raw):
    enc, i = [], 0
    while i < len(raw):
        if raw[i] == 0:
            j = i
            while j < len(raw) and raw[j] == 0 and j - i < 255:
                j += 1
            enc += [0, j - i]
            i = j
        else:
            enc.append(raw[i]); i += 1
    return enc
zl = ["; zframes.asm - the zombie's frames (art.py / zombie.py): four 16x16 patterns",
      "; each (top colour 1, top colour 2, bottom colour 1, bottom colour 2), 128",
      "; bytes, zero runs packed (0, n)", "ZFrTab:"]
nzf = len(zbytes) // 128
zl += [f"    dw ZFr{i}" for i in range(nzf)]
zpk = 0
for i in range(nzf):
    enc = zrle(zbytes[i * 128:(i + 1) * 128])
    zpk += len(enc)
    zl.append(f"ZFr{i}:")
    for k2 in range(0, len(enc), 16):
        zl.append("    db " + ",".join(f"${v:02X}" for v in enc[k2:k2 + 16]))
zl.append("; the dark layers: first row, rows, bytes a row (nb), then the rows (from the first column with black)")
zl.append("ZDkTab:")
for i in range(len(zdk)):
    zl.append(f"    dw ZDk{i}")
for i, enc in enumerate(zdk):
    zl.append(f"ZDk{i}:")
    for k2 in range(0, len(enc), 16):
        zl.append("    db " + ",".join(f"${v:02X}" for v in enc[k2:k2 + 16]))
# r5, act III: the sunglasses. The same frames drawn with shades (zombie.py,
# the same windows): the colour layers lose a few bytes' bits (GpTab: per
# frame n, then n pairs offset 0-127, new byte) and the dark layer gains the
# glasses' pixels (GlTab: per frame n, then n pairs canvas row, column from the
# dark layer's first black column). The game patches the sprite buffer after
# each upload and ORs the pixels into ShBuf after each rebuild.
ZSH, _, _ = zombie.build(shades=True, base=ZFR)
gp_lines, gl_lines = ["GpTab:"], ["GlTab:"]
gp_body, gl_body = [], []
npx = 0
for i, (fb, fs) in enumerate(zip(ZFR, ZSH)):
    raw_b = bytes(zbytes[i * 128:(i + 1) * 128])
    raw_s = []
    for hi, (dx, (c1, c2), win, _lost) in enumerate(fs.halves[:2]):
        assert (dx, (c1, c2)) == (fb.halves[hi][0], fb.halves[hi][1]), (fb.name, hi)
        for ch in (c1, c2):
            raw_s += _spr16([''.join('#' if c == ch else '.' for c in row) for row in win])
    pairs = [(o, raw_s[o]) for o in range(128) if raw_s[o] != raw_b[o]]
    assert all(raw_s[o] & ~raw_b[o] & 255 == 0 for o, _ in pairs), fb.name   # only holes
    gp_lines.append(f"    dw Gp{i}")
    gp_body.append(f"Gp{i}:\n    db {len(pairs)}" + ("".join(f",{o},{v}" for o, v in pairs)))
    dkb, _cb, c0b = fb.halves[2]
    dks, _cs, c0s = fs.halves[2]
    assert c0b == c0s
    orv = 0
    for row in dkb:
        orv |= row
    lb = min(j for j in range(32) if orv >> (31 - j) & 1)
    px = []
    for rr_ in range(32):
        add_ = dks[rr_] & ~dkb[rr_]
        assert dkb[rr_] & ~dks[rr_] == 0, fb.name
        for j in range(32):
            if add_ >> (31 - j) & 1:
                assert j >= lb
                px.append((rr_, j - lb))
    npx += len(px)
    # r5b: runs per canvas row, as 16-bit masks from the run's first column;
    # the mirrored version too (column nb*8-1-x); the game shifts them by TlNsx
    nbf = zdknb[i]
    runs = []
    for rr_ in sorted(set(a_ for a_, _ in px)):
        xs = [b_ for a_, b_ in px if a_ == rr_]
        xm = [nbf * 8 - 1 - b_ for b_ in xs]
        x0, x0m = min(xs), min(xm)
        assert max(xs) - x0 < 16 and max(xm) - x0m < 16, fb.name
        mk = sum(1 << (15 - (b_ - x0)) for b_ in xs)
        mm = sum(1 << (15 - (b_ - x0m)) for b_ in xm)
        runs += [rr_ + 8, x0, mk >> 8, mk & 255, x0m, mm >> 8, mm & 255]
    gl_body.append(f"Gl{i}:\n    db {len(runs) // 7}" + ("".join(f",{v_}" for v_ in runs)))
# (r5: these tables live in act III's home bank only, where the title music
# is in the other acts' banks: build.py places them; shades.json holds them)
import json as _json
_json.dump({'gp': [[[int(x) for x in b.split('db ', 1)[1].split(',')] ] for b in gp_body],
            'gl': [[[int(x) for x in b.split('db ', 1)[1].split(',')] ] for b in gl_body]},
           open(os.path.join(OUT, 'shades.json'), 'w'))
zombie.sheets(ZSH, OUT, tag="-shades")
print(f"art: sunglasses patches {sum(len(b) for b in gp_body)} chars, {npx} dark pixels")
zl.append("    ds (256 - ($ & 255)) & 255, 0   ; RevTab on a 256-byte page")
zl.append("RevTab:")
rev = [int(f"{v:08b}"[::-1], 2) for v in range(256)]
for i in range(0, 256, 16):
    zl.append("    db " + ",".join(f"${v:02X}" for v in rev[i:i + 16]))
open(os.path.join(OUT, 'zframes.asm'), 'w').write("\n".join(zl) + "\n")
for nm, v in SPR_COL.items():
    out.append(f"const Sc{nm.capitalize()} = {v}")
for nm, pc in packs.items():
    open(os.path.join(OUT, 'packin', nm + '.bin'), 'wb').write(pc)
open(os.path.join(OUT, 'gfx.amy'), 'w').write("\n\n".join(out) + "\n")
# previews
def cells_of(ths, gt=True):
    dd = []
    for th in ths:
        mp = {th.base + i: pc for i, pc in enumerate(th.cells)}
        if gt:
            mp.update({GT_BASE + i: pc for i, pc in enumerate(GTP)})
        dd.append(mp)
    return dd
m2.to_png(os.path.join(OUT, 'preview-backyard.png'), cells_of(thirds), BGN)
for _pre, _act in (('w', 2), ('s', 3)):
    _th, _n = YARDS[_pre]
    GTP = GTSETS[_act]
    m2.to_png(os.path.join(OUT, f'preview-yard-{_pre}.png'), cells_of(_th), _n)
GTP = GTSETS[1]
tt = cells_of(tthirds, gt=False)
m2.to_png(os.path.join(OUT, 'preview-title.png'), tt, TN)
gc = {112 + i: pc for i, pc in enumerate(bt_cells)}
for i in range(len(gnames)):
    m2.to_png(os.path.join(OUT, f'preview-gag{i}.png'), [gc, gc, gc], gnames[i], scale=1)
print(f"art: game tiles {len(GTP)}, sprites {len(sp.data) // 32} patterns, zombie frames {len(ZFR)} ({zpk} bytes packed + dark {sum(len(e) for e in zdk)} bytes), close-up frames {len(allf)}")
# r5: the game tile sheets of the three acts (4x; codes from GT_BASE, 16 a row,
# plus the ninja footprint and puff at the end)
from PIL import Image as _Im
_sh = _Im.new('RGB', (3 * (16 * 8 * 4 + 16), 4 * 8 * 4), (40, 40, 40))
for _a in (1, 2, 3):
    _cells = list(GTSETS[_a]) + [(FOOTP[_a][0][:8], FOOTP[_a][1][:8]), (FOOTP[_a][0][8:], FOOTP[_a][1][8:])]
    for _i, _pc in enumerate(_cells):
        _rgb = m2.cell_rgb(_pc).reshape(8, 8, 3).astype(np.uint8)
        _t = _Im.fromarray(_rgb).resize((32, 32), _Im.NEAREST)
        _sh.paste(_t, ((_a - 1) * (16 * 8 * 4 + 16) + (_i % 16) * 32, (_i // 16) * 32))
_sh.save(os.path.join(OUT, 'tiles-acts-4x.png'))
